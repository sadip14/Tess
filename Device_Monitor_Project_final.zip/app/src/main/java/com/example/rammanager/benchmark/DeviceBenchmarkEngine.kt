package com.example.rammanager.benchmark

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.rammanager.model.*
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.Arrays
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

/**
 * Device Monitor Benchmark v1 (DMB-v1) Execution Engine.
 *
 * Rules:
 * - Every test iteration runs for >= 200 ms (measured and deadline controlled via System.nanoTime()).
 * - Separate warm-up per test (sieve, matrix, memory copy, mixed file I/O) with identical parameters,
 *   unrecorded, storing outputs into @Volatile sinks to prevent dead code elimination by the JIT compiler.
 * - Fast mode is designated as "Tes singkat" and produces no DMB score (factor 0.625 removed).
 * - Standard mode computes DMB-v1 scores normalized against the physical anchor baseline.
 * - Storage failures are not swallowed; marked invalid if an exception occurs.
 * - Thermal statuses recorded both before and after execution from Android Thermal Service.
 * - Local results marked with isVerifiedPhysical = false, source = "LOCAL_MEASURED".
 */
class DeviceBenchmarkEngine(private val context: Context) {

    companion object {
        // Volatile sinks to prevent JIT optimizer from dead-code-eliminating benchmark loops
        @Volatile
        var sinkLong: Long = 0L

        @Volatile
        var sinkFloat: Float = 0f

        @Volatile
        var sinkByte: Byte = 0
    }

    private fun getBatteryLevel(): Int {
        return try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, ifilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            if (level >= 0 && scale > 0) (level * 100) / scale else 0
        } catch (_: Throwable) {
            0
        }
    }

    fun getBatteryTemperatureC(): Float? {
        return try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, ifilter)
            val tempTenths = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            if (tempTenths > 0) tempTenths / 10.0f else null
        } catch (_: Throwable) {
            null
        }
    }

    private suspend fun getDeviceTemp(): Float? {
        return try {
            ShizukuCommandRunner.getCpuTemperatureC()
        } catch (_: Throwable) {
            null
        }
    }

    private fun getThermalStatus(): AndroidThermalStatus {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (powerManager != null) {
                    AndroidThermalStatus.fromCode(powerManager.currentThermalStatus)
                } else {
                    AndroidThermalStatus.UNKNOWN
                }
            } else {
                AndroidThermalStatus.UNKNOWN
            }
        } catch (_: Throwable) {
            AndroidThermalStatus.UNKNOWN
        }
    }

    suspend fun runBenchmark(
        mode: BenchmarkMode,
        onProgress: (phase: String, percent: Int) -> Unit
    ): BenchmarkResultRecord = withContext(Dispatchers.Default) {
        val batBefore = getBatteryLevel()
        val batTempBefore = getBatteryTemperatureC()
        val tempBefore = getDeviceTemp()
        val thermalBefore = getThermalStatus()
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

        if (mode == BenchmarkMode.STRESS) {
            return@withContext runStressTest(cores, batBefore, tempBefore, batTempBefore, thermalBefore, onProgress)
        }

        // Iteration parameters (All iterations >= 200 ms)
        val sieveLimit = if (mode == BenchmarkMode.FAST) 1_200_000 else 2_000_000
        val sieveMinDurationNs = 250_000_000L // 250 ms minimum per iteration (>= 200 ms)

        val multiDurationMs = if (mode == BenchmarkMode.FAST) 700L else 3000L
        val ramDurationMs = if (mode == BenchmarkMode.FAST) 700L else 3000L
        val storageDurationMs = if (mode == BenchmarkMode.FAST) 700L else 3000L

        // 1. CPU Single-Core Integer Sieve
        // Separate warm-up with identical parameter, unrecorded, result to volatile sink
        onProgress("Warm-up CPU Single-Core Sieve...", 5)
        val warmSingle = measureSingleCoreTimeMs(sieveLimit, sieveMinDurationNs)
        sinkLong = warmSingle.toBits()

        onProgress("Uji CPU Single-Core (5 iterasi, median)...", 10)
        val singleRuns = mutableListOf<Double>()
        for (r in 1..5) {
            val elapsedMs = measureSingleCoreTimeMs(sieveLimit, sieveMinDurationNs)
            singleRuns.add(elapsedMs)
            onProgress("CPU Single-Core: iterasi $r/5 (${String.format("%.1f", elapsedMs)} ms)...", 10 + (r * 3))
        }
        val singleMetric = calculateVariation(singleRuns, MetricType.TIME_MS)

        // 2. CPU Multi-Core Matrix Workload (size 160)
        // Separate warm-up with identical parameter, unrecorded, result to volatile sink
        onProgress("Warm-up CPU Multi-Core Matriks...", 28)
        val warmMulti = measureMultiCoreThroughput(cores, multiDurationMs)
        sinkFloat = warmMulti.toFloat()

        onProgress("Uji CPU Multi-Core ($cores core, 5 iterasi)...", 32)
        val multiRuns = mutableListOf<Double>()
        for (r in 1..5) {
            val mops = measureMultiCoreThroughput(cores, multiDurationMs)
            multiRuns.add(mops)
            onProgress("CPU Multi-Core: iterasi $r/5 (${String.format("%.1f", mops)} MOps/s)...", 32 + (r * 3))
        }
        val multiMetric = calculateVariation(multiRuns, MetricType.THROUGHPUT_MOPS)

        // 3. Memory Copy Throughput
        // Separate warm-up with identical parameter, unrecorded, result to volatile sink
        onProgress("Warm-up Memory Copy Throughput...", 50)
        val warmRam = measureRamBandwidth(ramDurationMs)
        sinkByte = (warmRam.toLong() and 0xFF).toByte()

        onProgress("Uji Memory Copy Throughput (5 iterasi)...", 54)
        val ramRuns = mutableListOf<Double>()
        for (r in 1..5) {
            val mbSec = measureRamBandwidth(ramDurationMs)
            ramRuns.add(mbSec)
            onProgress("Memory Copy: iterasi $r/5 (${String.format("%.0f", mbSec)} MiB/s)...", 54 + (r * 3))
        }
        val ramMetric = calculateVariation(ramRuns, MetricType.THROUGHPUT_MIB_S)

        // 4. Mixed File I/O Throughput (Storage)
        // Separate warm-up with identical parameter, unrecorded
        onProgress("Warm-up Mixed File I/O...", 72)
        var storageError: String? = null
        try {
            measureStorageThroughput(storageDurationMs)
        } catch (e: Exception) {
            storageError = "Warm-up Storage I/O gagal: ${e.message}"
        }

        onProgress("Uji Mixed File I/O Throughput (5 iterasi)...", 76)
        val storageRuns = mutableListOf<Double>()
        for (r in 1..5) {
            try {
                val mbSec = measureStorageThroughput(storageDurationMs)
                storageRuns.add(mbSec)
                onProgress("Storage I/O: iterasi $r/5 (${String.format("%.0f", mbSec)} MiB/s)...", 76 + (r * 3))
            } catch (e: Exception) {
                storageError = "Iterasi $r gagal: ${e.message}"
                break
            }
        }

        val isStorageSuccess = storageError == null && storageRuns.size == 5
        val storageMetric = if (isStorageSuccess) {
            calculateVariation(storageRuns, MetricType.THROUGHPUT_MIB_S)
        } else {
            MetricVariation(0.0, 0.0, 0.0, 0.0, MetricType.THROUGHPUT_MIB_S)
        }

        onProgress("Memverifikasi dan Menyelesaikan Hasil...", 95)

        val batAfter = getBatteryLevel()
        val batTempAfter = getBatteryTemperatureC()
        val tempAfter = getDeviceTemp()
        val thermalAfter = getThermalStatus()

        // Mode Cepat tidak diberi skor DMB (hanya tes singkat tanpa skor DMB)
        // Faktor 0.625 dihapus sepenuhnya.
        val singleScore: Int
        val multiScore: Int
        val ramScore: Int
        val storageScore: Int
        val totalScore: Int

        val isValid = isStorageSuccess

        if (mode == BenchmarkMode.FAST || !isValid) {
            singleScore = 0
            multiScore = 0
            ramScore = 0
            storageScore = 0
            totalScore = 0
        } else {
            // Mode STANDARD: DMB-v2 equal weighting of 3 subscores (Single-Core, Multi-Core, Memory Copy)
            // Storage is measured and displayed separately; excluded from total score due to high inter-session variance
            singleScore = if (singleMetric.median > 0.0 && DmbV1Anchor.BASE_SINGLE_TIME_MS > 0.0) {
                ((DmbV1Anchor.BASELINE_SCORE * (DmbV1Anchor.BASE_SINGLE_TIME_MS / singleMetric.median))).toInt()
            } else 0

            multiScore = if (DmbV1Anchor.BASE_MULTI_THROUGHPUT_MOPS > 0.0) {
                ((DmbV1Anchor.BASELINE_SCORE * (multiMetric.median / DmbV1Anchor.BASE_MULTI_THROUGHPUT_MOPS))).toInt()
            } else 0

            ramScore = if (DmbV1Anchor.BASE_RAM_MB_SEC > 0.0) {
                ((DmbV1Anchor.BASELINE_SCORE * (ramMetric.median / DmbV1Anchor.BASE_RAM_MB_SEC))).toInt()
            } else 0

            storageScore = 0

            totalScore = (singleScore + multiScore + ramScore) / 3
        }

        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"

        BenchmarkResultRecord(
            id = "dmb1-${UUID.randomUUID().toString().substring(0, 8)}",
            timestamp = System.currentTimeMillis(),
            mode = mode,
            deviceModel = deviceName,
            totalScore = totalScore,
            singleCoreScore = singleScore,
            multiCoreScore = multiScore,
            ramScore = ramScore,
            storageScore = storageScore,
            singleCoreOpsSec = singleMetric,
            multiCoreOpsSec = multiMetric,
            ramThroughputMbSec = ramMetric,
            storageThroughputMbSec = storageMetric,
            tempBeforeC = tempBefore,
            tempAfterC = tempAfter,
            batteryBeforePct = batBefore,
            batteryAfterPct = batAfter,
            batteryTempBeforeC = batTempBefore,
            batteryTempAfterC = batTempAfter,
            thermalStatusBefore = thermalBefore,
            thermalStatusAfter = thermalAfter,
            thermalStatus = thermalAfter,
            isVerifiedPhysical = false,
            source = "LOCAL_MEASURED",
            benchmarkVersion = DmbV1Anchor.BENCHMARK_VERSION,
            schemaVersion = DmbV1Anchor.SCHEMA_VERSION,
            isValid = isValid,
            validationError = storageError
        )
    }

    private suspend fun runStressTest(
        cores: Int,
        batBefore: Int,
        tempBefore: Float?,
        batTempBefore: Float?,
        thermalBefore: AndroidThermalStatus,
        onProgress: (phase: String, percent: Int) -> Unit
    ): BenchmarkResultRecord = withContext(Dispatchers.Default) {
        val totalIntervals = 10 // 10 intervals of 5 seconds = 50 seconds sustained load
        val curve = mutableListOf<StressDataPoint>()

        for (i in 1..totalIntervals) {
            val progressPct = 10 + ((i.toFloat() / totalIntervals) * 85).toInt()
            onProgress("Stress Test DMB-v1: interval $i/$totalIntervals (beban penuh)...", progressPct)

            val mops = measureMultiCoreThroughput(cores, 5000L)
            val intervalScore = ((DmbV1Anchor.BASELINE_SCORE * (mops / DmbV1Anchor.BASE_MULTI_THROUGHPUT_MOPS))).toInt()
            val currentTemp = getDeviceTemp()

            curve.add(
                StressDataPoint(
                    second = i * 5,
                    score = intervalScore,
                    tempC = currentTemp
                )
            )
        }

        val firstScore = curve.firstOrNull()?.score ?: 1
        val lastScore = curve.lastOrNull()?.score ?: 1
        val dropPct = if (firstScore > 0) {
            (((firstScore - lastScore).toFloat() / firstScore.toFloat()) * 100f).coerceAtLeast(0f)
        } else 0f

        val avgScore = if (curve.isNotEmpty()) curve.map { it.score }.average().toInt() else 0
        val batAfter = getBatteryLevel()
        val batTempAfter = getBatteryTemperatureC()
        val tempAfter = getDeviceTemp()
        val thermalAfter = getThermalStatus()

        val singlePlaceholder = MetricVariation(0.0, 0.0, 0.0, 0.0, MetricType.TIME_MS)
        val multiMetric = MetricVariation(avgScore.toDouble(), firstScore.toDouble(), lastScore.toDouble(), avgScore.toDouble(), MetricType.THROUGHPUT_MOPS)
        val ramPlaceholder = MetricVariation(0.0, 0.0, 0.0, 0.0, MetricType.THROUGHPUT_MIB_S)
        val storagePlaceholder = MetricVariation(0.0, 0.0, 0.0, 0.0, MetricType.THROUGHPUT_MIB_S)

        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"

        BenchmarkResultRecord(
            id = "stress-${UUID.randomUUID().toString().substring(0, 8)}",
            timestamp = System.currentTimeMillis(),
            mode = BenchmarkMode.STRESS,
            deviceModel = deviceName,
            totalScore = avgScore,
            singleCoreScore = 0,
            multiCoreScore = avgScore,
            ramScore = 0,
            storageScore = 0,
            singleCoreOpsSec = singlePlaceholder,
            multiCoreOpsSec = multiMetric,
            ramThroughputMbSec = ramPlaceholder,
            storageThroughputMbSec = storagePlaceholder,
            tempBeforeC = tempBefore,
            tempAfterC = tempAfter,
            batteryBeforePct = batBefore,
            batteryAfterPct = batAfter,
            batteryTempBeforeC = batTempBefore,
            batteryTempAfterC = batTempAfter,
            thermalStatusBefore = thermalBefore,
            thermalStatusAfter = thermalAfter,
            thermalStatus = thermalAfter,
            isVerifiedPhysical = false,
            source = "LOCAL_MEASURED",
            throttlingDropPct = dropPct,
            stressCurve = curve,
            benchmarkVersion = DmbV1Anchor.BENCHMARK_VERSION,
            schemaVersion = DmbV1Anchor.SCHEMA_VERSION,
            isValid = true,
            validationError = null
        )
    }

    /**
     * Measures Single-Core execution time in milliseconds (latency-based test).
     * Enforces minimum execution time >= 200 ms using System.nanoTime() deadline.
     */
    private fun measureSingleCoreTimeMs(limit: Int, minDurationNs: Long): Double {
        val deadlineNs = System.nanoTime() + minDurationNs
        val isPrime = BooleanArray(limit + 1)
        val startNs = System.nanoTime()
        var completedPasses = 0L

        do {
            Arrays.fill(isPrime, true)
            var p = 2
            while (p * p <= limit) {
                if (isPrime[p]) {
                    var i = p * p
                    while (i <= limit) {
                        isPrime[i] = false
                        i += p
                    }
                }
                p++
            }

            var checksum = 0L
            var idx = 2
            while (idx <= limit) {
                if (isPrime[idx]) checksum += idx
                idx += 7
            }
            sinkLong = checksum
            completedPasses++
        } while (System.nanoTime() < deadlineNs)

        val elapsedNs = System.nanoTime() - startNs
        val totalMs = elapsedNs / 1_000_000.0
        return totalMs / completedPasses.toDouble()
    }

    /**
     * Measures Multi-Core concurrent floating point operations in MOps/sec.
     * Matrix size increased to 160 (not 120), deadline controlled via System.nanoTime().
     */
    private suspend fun measureMultiCoreThroughput(cores: Int, durationMs: Long): Double = coroutineScope {
        val totalOps = AtomicLong(0L)
        val deadlineNs = System.nanoTime() + (durationMs * 1_000_000L)
        val startNs = System.nanoTime()

        val jobs = List(cores) {
            launch(Dispatchers.Default) {
                var localOps = 0L
                val size = 160 // Increased matrix size
                val a = FloatArray(size * size) { 1.05f }
                val b = FloatArray(size * size) { 0.95f }
                val c = FloatArray(size * size)

                while (System.nanoTime() < deadlineNs) {
                    for (i in 0 until size) {
                        for (k in 0 until size) {
                            val r = a[i * size + k]
                            for (j in 0 until size) {
                                c[i * size + j] += r * b[k * size + j]
                            }
                        }
                    }
                    localOps += (2L * size * size * size)
                    sinkFloat = c[0]
                }
                totalOps.addAndGet(localOps)
            }
        }
        jobs.joinAll()
        val elapsedSec = (System.nanoTime() - startNs) / 1_000_000_000.0
        if (elapsedSec > 0.0) (totalOps.get().toDouble() / 1_000_000.0) / elapsedSec else 0.0
    }

    /**
     * Measures Memory Copy Throughput in MiB/s using System.nanoTime() deadline.
     */
    private fun measureRamBandwidth(durationMs: Long): Double {
        val deadlineNs = System.nanoTime() + (durationMs * 1_000_000L)
        val bufferSize = 8 * 1024 * 1024 // 8 MiB buffer
        val src = ByteArray(bufferSize)
        val dst = ByteArray(bufferSize)
        Random.nextBytes(src)

        var totalBytesCopied = 0L
        val startNs = System.nanoTime()

        while (System.nanoTime() < deadlineNs) {
            System.arraycopy(src, 0, dst, 0, bufferSize)
            totalBytesCopied += bufferSize
            sinkByte = dst[0]
        }

        val elapsedSec = (System.nanoTime() - startNs) / 1_000_000_000.0
        val totalMib = totalBytesCopied / (1024.0 * 1024.0)
        return if (elapsedSec > 0.0) totalMib / elapsedSec else 0.0
    }

    /**
     * Measures Mixed File I/O Throughput in MiB/s.
     * Does NOT swallow exceptions; propagates errors to indicate invalid results.
     */
    @Throws(IOException::class)
    private fun measureStorageThroughput(durationMs: Long): Double {
        val ts = System.nanoTime()
        val writeFile = File(context.cacheDir, "bench_io_w_$ts.tmp")
        val readFile = File(context.cacheDir, "bench_io_r_$ts.tmp")
        val chunkSize = 4 * 1024 * 1024 // 4 MiB chunk
        val writeBuffer = ByteArray(chunkSize)
        val readBuffer = ByteArray(chunkSize)
        Random.nextBytes(writeBuffer)

        var totalBytes = 0L
        var startNs = 0L

        try {
            FileOutputStream(readFile).use { fos ->
                fos.write(writeBuffer)
                fos.flush()
                fos.fd.sync()
            }

            val deadlineNs = System.nanoTime() + (durationMs * 1_000_000L)
            startNs = System.nanoTime()

            while (System.nanoTime() < deadlineNs) {
                FileOutputStream(writeFile).use { fos ->
                    fos.write(writeBuffer)
                    fos.flush()
                    fos.fd.sync()
                }
                FileInputStream(readFile).use { fis ->
                    var offset = 0
                    while (offset < chunkSize) {
                        val read = fis.read(readBuffer, offset, chunkSize - offset)
                        if (read <= 0) break
                        offset += read
                    }
                }
                totalBytes += (chunkSize * 2)
                sinkByte = readBuffer[0]
            }
        } finally {
            if (writeFile.exists()) writeFile.delete()
            if (readFile.exists()) readFile.delete()
        }

        val elapsedSec = if (startNs > 0L) (System.nanoTime() - startNs) / 1_000_000_000.0 else 0.0
        val totalMib = totalBytes / (1024.0 * 1024.0)
        return if (elapsedSec > 0.0) totalMib / elapsedSec else 0.0
    }

    private fun calculateVariation(runs: List<Double>, metricType: MetricType): MetricVariation {
        if (runs.isEmpty()) return MetricVariation(0.0, 0.0, 0.0, 0.0, metricType)
        val sorted = runs.sorted()
        val median = sorted[sorted.size / 2] // Exact median of 5 iterations (index 2)
        val min = sorted.first()
        val max = sorted.last()
        val avg = runs.average()
        return MetricVariation(median = median, min = min, max = max, avg = avg, metricType = metricType)
    }
}
