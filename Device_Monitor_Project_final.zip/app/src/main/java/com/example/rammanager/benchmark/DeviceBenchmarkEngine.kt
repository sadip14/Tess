package com.example.rammanager.benchmark

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import com.example.rammanager.model.BenchmarkMode
import com.example.rammanager.model.BenchmarkResultRecord
import com.example.rammanager.model.MetricVariation
import com.example.rammanager.model.StressDataPoint
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

class DeviceBenchmarkEngine(private val context: Context) {

    private fun getBatteryLevel(): Int {
        return try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, ifilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            if (level >= 0 && scale > 0) (level * 100) / scale else 0
        } catch (_: Throwable) {
            0
        }
    }

    private suspend fun getDeviceTemp(): Float? {
        return try {
            ShizukuCommandRunner.getCpuTemperatureC()
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Executes real hardware benchmark (Fast, Standard, or Stress mode).
     * No artificial ranges or coerceIn (Rule E.3).
     */
    suspend fun runBenchmark(
        mode: BenchmarkMode,
        onProgress: (phase: String, percent: Int) -> Unit
    ): BenchmarkResultRecord = withContext(Dispatchers.Default) {
        val batBefore = getBatteryLevel()
        val tempBefore = getDeviceTemp()

        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

        // Warm-up phase: 5 seconds (Rule E.1)
        onProgress("Pemanasan CPU (5 detik) untuk governor clock...", 5)
        val warmUpEnd = System.currentTimeMillis() + 5000L
        while (System.currentTimeMillis() < warmUpEnd) {
            var sum = 0.0
            for (i in 0 until 100_000) {
                sum += Math.sin(i.toDouble()) * Math.cos(i.toDouble())
            }
        }

        if (mode == BenchmarkMode.STRESS) {
            return@withContext runStressTest(cores, batBefore, tempBefore, onProgress)
        }

        val testDurationMs = if (mode == BenchmarkMode.FAST) 1000L else 3500L

        // 1. Single-Core CPU Integer Sieve (3 runs, time-based ops/sec)
        onProgress("Uji CPU Single-Core (3 putaran)...", 20)
        val singleRuns = mutableListOf<Double>()
        for (r in 1..3) {
            val ops = measureSingleCore(testDurationMs)
            singleRuns.add(ops)
        }
        val singleMetric = calculateVariation(singleRuns)

        // 2. Multi-Core CPU Floating Point (Real concurrent threads = availableProcessors)
        onProgress("Uji CPU Multi-Core ($cores thread, 3 putaran)...", 45)
        val multiRuns = mutableListOf<Double>()
        for (r in 1..3) {
            val ops = measureMultiCore(cores, testDurationMs)
            multiRuns.add(ops)
        }
        val multiMetric = calculateVariation(multiRuns)

        // 3. RAM Memory Bandwidth (Arraycopy memory buffer)
        onProgress("Uji Bandwidth Memori RAM (3 putaran)...", 70)
        val ramRuns = mutableListOf<Double>()
        for (r in 1..3) {
            val mbSec = measureRamBandwidth(testDurationMs)
            ramRuns.add(mbSec)
        }
        val ramMetric = calculateVariation(ramRuns)

        // 4. Storage I/O Throughput
        onProgress("Uji I/O Penyimpanan Internal (3 putaran)...", 90)
        val storageRuns = mutableListOf<Double>()
        for (r in 1..3) {
            val mbSec = measureStorageThroughput(testDurationMs)
            storageRuns.add(mbSec)
        }
        val storageMetric = calculateVariation(storageRuns)

        onProgress("Menghitung Skor Akhir...", 100)

        val batAfter = getBatteryLevel()
        val tempAfter = getDeviceTemp()

        // Constant multipliers (No coerceIn - Rule E.3)
        val singleScore = (singleMetric.median * 0.005).toInt()
        val multiScore = (multiMetric.median * 0.002).toInt()
        val ramScore = (ramMetric.median * 2.5).toInt()
        val storageScore = (storageMetric.median * 6.0).toInt()
        val totalScore = singleScore + multiScore + ramScore + storageScore

        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"

        BenchmarkResultRecord(
            id = "bench-${UUID.randomUUID().toString().substring(0, 8)}",
            timestamp = System.currentTimeMillis(),
            mode = mode,
            deviceModel = deviceName,
            totalScore = totalScore,
            singleCoreScore = singleScore,
            multiCoreScore = multiScore,
            ramScore = ramScore,
            storageScore = storageScore,
            singleCoreOpsSec = singleMetric,
            multiCoreOpsSec = multiMetric,
            ramThroughputMbSec = ramMetric,
            storageThroughputMbSec = storageMetric,
            tempBeforeC = tempBefore,
            tempAfterC = tempAfter,
            batteryBeforePct = batBefore,
            batteryAfterPct = batAfter
        )
    }

    private suspend fun runStressTest(
        cores: Int,
        batBefore: Int,
        tempBefore: Float?,
        onProgress: (phase: String, percent: Int) -> Unit
    ): BenchmarkResultRecord = withContext(Dispatchers.Default) {
        val totalIntervals = 6 // 30 seconds total (6 intervals x 5s)
        val curve = mutableListOf<StressDataPoint>()

        for (i in 1..totalIntervals) {
            val progressPct = 15 + ((i.toFloat() / totalIntervals) * 80).toInt()
            onProgress("Stress Test Berjalan: interval $i/$totalIntervals (5s beban penuh)...", progressPct)

            val ops = measureMultiCore(cores, 5000L)
            val intervalScore = (ops * 0.002).toInt()
            val currentTemp = getDeviceTemp()

            curve.add(
                StressDataPoint(
                    second = i * 5,
                    score = intervalScore,
                    tempC = currentTemp
                )
            )
        }

        val firstScore = curve.firstOrNull()?.score ?: 1
        val lastScore = curve.lastOrNull()?.score ?: 1
        val dropPct = if (firstScore > 0) {
            (((firstScore - lastScore).toFloat() / firstScore.toFloat()) * 100f).coerceAtLeast(0f)
        } else 0f

        onProgress("Menguji Single-Core, RAM & Storage...", 92)
        val singleOps = measureSingleCore(1200L)
        val ramMbSec = measureRamBandwidth(1200L)
        val storageMbSec = measureStorageThroughput(1200L)

        val singleMetric = calculateVariation(listOf(singleOps))
        val multiMetric = calculateVariation(curve.map { it.score / 0.002 })
        val ramMetric = calculateVariation(listOf(ramMbSec))
        val storageMetric = calculateVariation(listOf(storageMbSec))

        val singleScore = (singleMetric.median * 0.005).toInt()
        val multiScore = curve.map { it.score }.average().toInt()
        val ramScore = (ramMetric.median * 2.5).toInt()
        val storageScore = (storageMetric.median * 6.0).toInt()
        val totalScore = singleScore + multiScore + ramScore + storageScore

        val batAfter = getBatteryLevel()
        val tempAfter = getDeviceTemp()

        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"

        BenchmarkResultRecord(
            id = "stress-${UUID.randomUUID().toString().substring(0, 8)}",
            timestamp = System.currentTimeMillis(),
            mode = BenchmarkMode.STRESS,
            deviceModel = deviceName,
            totalScore = totalScore,
            singleCoreScore = singleScore,
            multiCoreScore = multiScore,
            ramScore = ramScore,
            storageScore = storageScore,
            singleCoreOpsSec = singleMetric,
            multiCoreOpsSec = multiMetric,
            ramThroughputMbSec = ramMetric,
            storageThroughputMbSec = storageMetric,
            tempBeforeC = tempBefore,
            tempAfterC = tempAfter,
            batteryBeforePct = batBefore,
            batteryAfterPct = batAfter,
            throttlingDropPct = dropPct,
            stressCurve = curve
        )
    }

    private fun measureSingleCore(durationMs: Long): Double {
        val deadline = System.currentTimeMillis() + durationMs
        var count = 0L
        val limit = 100_000
        val isPrime = BooleanArray(limit + 1) { true }

        val startNs = System.nanoTime()
        while (System.currentTimeMillis() < deadline) {
            // Sieve of Eratosthenes segment
            var p = 2
            while (p * p <= limit) {
                if (isPrime[p]) {
                    var i = p * p
                    while (i <= limit) {
                        isPrime[i] = false
                        i += p
                    }
                }
                p++
            }
            count += limit
        }
        val elapsedSec = (System.nanoTime() - startNs) / 1_000_000_000.0
        return if (elapsedSec > 0) count / elapsedSec else 0.0
    }

    private suspend fun measureMultiCore(cores: Int, durationMs: Long): Double = coroutineScope {
        val totalOps = AtomicLong(0L)
        val deadline = System.currentTimeMillis() + durationMs
        val startNs = System.nanoTime()

        val jobs = List(cores) {
            launch(Dispatchers.Default) {
                var localOps = 0L
                val size = 120
                val a = FloatArray(size * size) { 1.05f }
                val b = FloatArray(size * size) { 0.95f }
                val c = FloatArray(size * size)

                while (System.currentTimeMillis() < deadline) {
                    for (i in 0 until size) {
                        for (k in 0 until size) {
                            val r = a[i * size + k]
                            for (j in 0 until size) {
                                c[i * size + j] += r * b[k * size + j]
                            }
                        }
                    }
                    localOps += (2L * size * size * size)
                }
                totalOps.addAndGet(localOps)
            }
        }
        jobs.joinAll()
        val elapsedSec = (System.nanoTime() - startNs) / 1_000_000_000.0
        if (elapsedSec > 0) totalOps.get().toDouble() / elapsedSec else 0.0
    }

    private fun measureRamBandwidth(durationMs: Long): Double {
        val deadline = System.currentTimeMillis() + durationMs
        val bufferSize = 8 * 1024 * 1024 // 8 MB
        val src = ByteArray(bufferSize)
        val dst = ByteArray(bufferSize)
        Random.nextBytes(src)

        var totalBytesCopied = 0L
        val startNs = System.nanoTime()

        while (System.currentTimeMillis() < deadline) {
            System.arraycopy(src, 0, dst, 0, bufferSize)
            totalBytesCopied += bufferSize
        }

        val elapsedSec = (System.nanoTime() - startNs) / 1_000_000_000.0
        val totalMb = totalBytesCopied / (1024.0 * 1024.0)
        return if (elapsedSec > 0) totalMb / elapsedSec else 0.0
    }

    private fun measureStorageThroughput(durationMs: Long): Double {
        val ts = System.currentTimeMillis()
        val writeFile = File(context.cacheDir, "bench_io_w_$ts.tmp")
        val readFile = File(context.cacheDir, "bench_io_r_$ts.tmp")
        val chunkSize = 4 * 1024 * 1024 // 4 MB
        val writeBuffer = ByteArray(chunkSize)
        val readBuffer = ByteArray(chunkSize)
        Random.nextBytes(writeBuffer)

        var totalBytes = 0L
        var startNs = 0L

        try {
            // Pre-populate and sync separate read file before timing
            FileOutputStream(readFile).use { fos ->
                fos.write(writeBuffer)
                fos.flush()
                fos.fd.sync()
            }

            val deadline = System.currentTimeMillis() + durationMs
            startNs = System.nanoTime()

            while (System.currentTimeMillis() < deadline) {
                FileOutputStream(writeFile).use { fos ->
                    fos.write(writeBuffer)
                    fos.flush()
                    fos.fd.sync()
                }
                FileInputStream(readFile).use { fis ->
                    var offset = 0
                    while (offset < chunkSize) {
                        val read = fis.read(readBuffer, offset, chunkSize - offset)
                        if (read <= 0) break
                        offset += read
                    }
                }
                totalBytes += (chunkSize * 2)
            }
        } catch (_: Exception) {
        } finally {
            writeFile.delete()
            readFile.delete()
        }

        val elapsedSec = if (startNs > 0L) (System.nanoTime() - startNs) / 1_000_000_000.0 else 0.0
        val totalMb = totalBytes / (1024.0 * 1024.0)
        return if (elapsedSec > 0) totalMb / elapsedSec else 0.0
    }

    private fun calculateVariation(runs: List<Double>): MetricVariation {
        if (runs.isEmpty()) return MetricVariation(0.0, 0.0, 0.0, 0.0)
        val sorted = runs.sorted()
        val median = sorted[sorted.size / 2]
        val min = sorted.first()
        val max = sorted.last()
        val avg = runs.average()
        return MetricVariation(median = median, min = min, max = max, avg = avg)
    }
}
