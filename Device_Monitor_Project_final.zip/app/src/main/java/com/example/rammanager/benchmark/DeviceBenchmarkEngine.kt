package com.example.rammanager.benchmark

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.rammanager.model.*
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

/**
 * Device Monitor Benchmark v1 (DMB-v1) Execution Engine.
 *
 * Anchor Baseline: Galaxy S21 FE 5G (SM-G990E, Exynos 2100, 8GB LPDDR5, Android 14) -> 10,000 pts.
 * - Single-Core: Time-based Sieve of Eratosthenes. Score = 10,000 * (T_base / T_device)
 * - Multi-Core: Throughput-based Matrix Floats. Score = 10,000 * (X_device / X_base)
 * - RAM: Throughput-based Buffer Copy. Score = 10,000 * (X_device / X_base)
 * - Storage: Throughput-based Read/Write. Score = 10,000 * (X_device / X_base)
 * - Equal Weighting: Total = (Single + Multi + RAM + Storage) / 4
 * - Warm-up: 2 unmeasured rounds
 * - Measurement: 5 iterations, taking the exact Median
 * - Thermal: Read from Android PowerManager Thermal Service
 */
class DeviceBenchmarkEngine(private val context: Context) {

    private fun getBatteryLevel(): Int {
        return try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, ifilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            if (level >= 0 && scale > 0) (level * 100) / scale else 0
        } catch (_: Throwable) {
            0
        }
    }

    private suspend fun getDeviceTemp(): Float? {
        return try {
            ShizukuCommandRunner.getCpuTemperatureC()
        } catch (_: Throwable) {
            null
        }
    }

    private fun getThermalStatus(): AndroidThermalStatus {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (powerManager != null) {
                    AndroidThermalStatus.fromCode(powerManager.currentThermalStatus)
                } else {
                    AndroidThermalStatus.UNKNOWN
                }
            } else {
                AndroidThermalStatus.UNKNOWN
            }
        } catch (_: Throwable) {
            AndroidThermalStatus.UNKNOWN
        }
    }

    suspend fun runBenchmark(
        mode: BenchmarkMode,
        onProgress: (phase: String, percent: Int) -> Unit
    ): BenchmarkResultRecord = withContext(Dispatchers.Default) {
        val batBefore = getBatteryLevel()
        val tempBefore = getDeviceTemp()
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

        // 1. Warm-up Phase: 2 unrecorded rounds to ramp up CPU governor clocks
        onProgress("Pemanasan CPU (2 putaran warm-up) untuk governor clock...", 5)
        for (w in 1..2) {
            var sum = 0.0
            for (i in 0 until 120_000) {
                sum += Math.sin(i.toDouble()) * Math.cos(i.toDouble())
            }
        }

        if (mode == BenchmarkMode.STRESS) {
            return@withContext runStressTest(cores, batBefore, tempBefore, onProgress)
        }

        // Iteration target workload scaling (Fast: lighter iterations, Standard: full depth)
        val sieveLimit = if (mode == BenchmarkMode.FAST) 250_000 else 400_000
        val multiDurationMs = if (mode == BenchmarkMode.FAST) 1200L else 3000L
        val ramDurationMs = if (mode == BenchmarkMode.FAST) 1000L else 2500L
        val storageDurationMs = if (mode == BenchmarkMode.FAST) 1000L else 2500L

        // 2. Single-Core CPU Integer Sieve (5 iterations -> Median time in milliseconds)
        onProgress("Uji CPU Single-Core (5 iterasi, pembacaan median)...", 15)
        val singleRuns = mutableListOf<Double>()
        for (r in 1..5) {
            val elapsedMs = measureSingleCoreTimeMs(sieveLimit)
            singleRuns.add(elapsedMs)
            onProgress("Uji CPU Single-Core: iterasi $r/5 selesai (${String.format("%.1f", elapsedMs)} ms)...", 15 + (r * 3))
        }
        val singleMetric = calculateVariation(singleRuns, MetricType.TIME_MS)

        // 3. Multi-Core CPU Concurrent Workload (5 iterations -> Median throughput MOps/s)
        onProgress("Uji CPU Multi-Core ($cores thread, 5 iterasi)...", 35)
        val multiRuns = mutableListOf<Double>()
        for (r in 1..5) {
            val mops = measureMultiCoreThroughput(cores, multiDurationMs)
            multiRuns.add(mops)
            onProgress("Uji CPU Multi-Core: iterasi $r/5 selesai (${String.format("%.1f", mops)} MOps/s)...", 35 + (r * 3))
        }
        val multiMetric = calculateVariation(multiRuns, MetricType.THROUGHPUT_MOPS)

        // 4. RAM Memory Bandwidth (5 iterations -> Median throughput MB/s)
        onProgress("Uji Bandwidth Memori RAM (5 iterasi)...", 55)
        val ramRuns = mutableListOf<Double>()
        for (r in 1..5) {
            val mbSec = measureRamBandwidth(ramDurationMs)
            ramRuns.add(mbSec)
            onProgress("Uji Memori RAM: iterasi $r/5 selesai (${String.format("%.0f", mbSec)} MB/s)...", 55 + (r * 3))
        }
        val ramMetric = calculateVariation(ramRuns, MetricType.THROUGHPUT_MB_S)

        // 5. Storage I/O Speed (5 iterations -> Median throughput MB/s)
        onProgress("Uji I/O Penyimpanan Internal (5 iterasi)...", 75)
        val storageRuns = mutableListOf<Double>()
        for (r in 1..5) {
            val mbSec = measureStorageThroughput(storageDurationMs)
            storageRuns.add(mbSec)
            onProgress("Uji Penyimpanan: iterasi $r/5 selesai (${String.format("%.0f", mbSec)} MB/s)...", 75 + (r * 3))
        }
        val storageMetric = calculateVariation(storageRuns, MetricType.THROUGHPUT_MB_S)

        onProgress("Normalisasi Skor DMB-v1 (Baseline: S21 FE Exynos 2100)...", 95)

        val batAfter = getBatteryLevel()
        val tempAfter = getDeviceTemp()
        val thermalStatus = getThermalStatus()

        // Formula DMB-v1:
        // Single-Core (Time based, lower is faster): 10,000 * (T_base / T_device)
        val singleScore = if (singleMetric.median > 0.0) {
            val baselineMs = if (mode == BenchmarkMode.FAST) (DmbV1Anchor.BASE_SINGLE_TIME_MS * 0.625) else DmbV1Anchor.BASE_SINGLE_TIME_MS
            ((DmbV1Anchor.BASELINE_SCORE * (baselineMs / singleMetric.median))).toInt()
        } else 0

        // Multi-Core (Throughput based, higher is faster): 10,000 * (X_device / X_base)
        val multiScore = if (DmbV1Anchor.BASE_MULTI_THROUGHPUT_MOPS > 0.0) {
            ((DmbV1Anchor.BASELINE_SCORE * (multiMetric.median / DmbV1Anchor.BASE_MULTI_THROUGHPUT_MOPS))).toInt()
        } else 0

        // RAM Bandwidth (Throughput based): 10,000 * (X_device / X_base)
        val ramScore = if (DmbV1Anchor.BASE_RAM_MB_SEC > 0.0) {
            ((DmbV1Anchor.BASELINE_SCORE * (ramMetric.median / DmbV1Anchor.BASE_RAM_MB_SEC))).toInt()
        } else 0

        // Storage Throughput (Throughput based): 10,000 * (X_device / X_base)
        val storageScore = if (DmbV1Anchor.BASE_STORAGE_MB_SEC > 0.0) {
            ((DmbV1Anchor.BASELINE_SCORE * (storageMetric.median / DmbV1Anchor.BASE_STORAGE_MB_SEC))).toInt()
        } else 0

        // Equal Weight 25% each: Total = (Single + Multi + RAM + Storage) / 4
        val totalScore = (singleScore + multiScore + ramScore + storageScore) / 4

        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"

        BenchmarkResultRecord(
            id = "dmb1-${UUID.randomUUID().toString().substring(0, 8)}",
            timestamp = System.currentTimeMillis(),
            mode = mode,
            deviceModel = deviceName,
            totalScore = totalScore,
            singleCoreScore = singleScore,
            multiCoreScore = multiScore,
            ramScore = ramScore,
            storageScore = storageScore,
            singleCoreOpsSec = singleMetric,
            multiCoreOpsSec = multiMetric,
            ramThroughputMbSec = ramMetric,
            storageThroughputMbSec = storageMetric,
            tempBeforeC = tempBefore,
            tempAfterC = tempAfter,
            batteryBeforePct = batBefore,
            batteryAfterPct = batAfter,
            thermalStatus = thermalStatus,
            isVerifiedPhysical = true,
            source = "LOCAL_DEVICE",
            benchmarkVersion = DmbV1Anchor.BENCHMARK_VERSION,
            schemaVersion = DmbV1Anchor.SCHEMA_VERSION
        )
    }

    private suspend fun runStressTest(
        cores: Int,
        batBefore: Int,
        tempBefore: Float?,
        onProgress: (phase: String, percent: Int) -> Unit
    ): BenchmarkResultRecord = withContext(Dispatchers.Default) {
        val totalIntervals = 10 // 10 intervals of 5 seconds = 50 seconds sustained load
        val curve = mutableListOf<StressDataPoint>()

        for (i in 1..totalIntervals) {
            val progressPct = 10 + ((i.toFloat() / totalIntervals) * 85).toInt()
            onProgress("Stress Test DMB-v1: interval $i/$totalIntervals (beban penuh)...", progressPct)

            val mops = measureMultiCoreThroughput(cores, 5000L)
            // Normalized interval score against Multi-Core baseline 10,000
            val intervalScore = ((DmbV1Anchor.BASELINE_SCORE * (mops / DmbV1Anchor.BASE_MULTI_THROUGHPUT_MOPS))).toInt()
            val currentTemp = getDeviceTemp()

            curve.add(
                StressDataPoint(
                    second = i * 5,
                    score = intervalScore,
                    tempC = currentTemp
                )
            )
        }

        val firstScore = curve.firstOrNull()?.score ?: 1
        val lastScore = curve.lastOrNull()?.score ?: 1
        val dropPct = if (firstScore > 0) {
            (((firstScore - lastScore).toFloat() / firstScore.toFloat()) * 100f).coerceAtLeast(0f)
        } else 0f

        val avgScore = if (curve.isNotEmpty()) curve.map { it.score }.average().toInt() else 0
        val batAfter = getBatteryLevel()
        val tempAfter = getDeviceTemp()
        val thermalStatus = getThermalStatus()

        val singlePlaceholder = MetricVariation(0.0, 0.0, 0.0, 0.0, MetricType.TIME_MS)
        val multiMetric = MetricVariation(avgScore.toDouble(), firstScore.toDouble(), lastScore.toDouble(), avgScore.toDouble(), MetricType.THROUGHPUT_MOPS)
        val ramPlaceholder = MetricVariation(0.0, 0.0, 0.0, 0.0, MetricType.THROUGHPUT_MB_S)
        val storagePlaceholder = MetricVariation(0.0, 0.0, 0.0, 0.0, MetricType.THROUGHPUT_MB_S)

        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"

        BenchmarkResultRecord(
            id = "stress-${UUID.randomUUID().toString().substring(0, 8)}",
            timestamp = System.currentTimeMillis(),
            mode = BenchmarkMode.STRESS,
            deviceModel = deviceName,
            totalScore = avgScore,
            singleCoreScore = 0,
            multiCoreScore = avgScore,
            ramScore = 0,
            storageScore = 0,
            singleCoreOpsSec = singlePlaceholder,
            multiCoreOpsSec = multiMetric,
            ramThroughputMbSec = ramPlaceholder,
            storageThroughputMbSec = storagePlaceholder,
            tempBeforeC = tempBefore,
            tempAfterC = tempAfter,
            batteryBeforePct = batBefore,
            batteryAfterPct = batAfter,
            thermalStatus = thermalStatus,
            isVerifiedPhysical = true,
            source = "LOCAL_DEVICE",
            throttlingDropPct = dropPct,
            stressCurve = curve,
            benchmarkVersion = DmbV1Anchor.BENCHMARK_VERSION,
            schemaVersion = DmbV1Anchor.SCHEMA_VERSION
        )
    }

    /**
     * Measures Single-Core execution time in milliseconds (latency-based test).
     */
    private fun measureSingleCoreTimeMs(limit: Int): Double {
        val isPrime = BooleanArray(limit + 1) { true }
        val startNs = System.nanoTime()

        // Sieve of Eratosthenes segment execution
        var p = 2
        while (p * p <= limit) {
            if (isPrime[p]) {
                var i = p * p
                while (i <= limit) {
                    isPrime[i] = false
                    i += p
                }
            }
            p++
        }

        // Additional integer calculation to ensure minimum runtime
        var checksum = 0L
        for (i in 2..limit) {
            if (isPrime[i]) checksum += i
        }

        val elapsedNs = System.nanoTime() - startNs
        return elapsedNs / 1_000_000.0 // return in milliseconds (ms)
    }

    /**
     * Measures Multi-Core concurrent floating point operations in MOps/sec (throughput-based test).
     */
    private suspend fun measureMultiCoreThroughput(cores: Int, durationMs: Long): Double = coroutineScope {
        val totalOps = AtomicLong(0L)
        val deadline = System.currentTimeMillis() + durationMs
        val startNs = System.nanoTime()

        val jobs = List(cores) {
            launch(Dispatchers.Default) {
                var localOps = 0L
                val size = 120
                val a = FloatArray(size * size) { 1.05f }
                val b = FloatArray(size * size) { 0.95f }
                val c = FloatArray(size * size)

                while (System.currentTimeMillis() < deadline) {
                    for (i in 0 until size) {
                        for (k in 0 until size) {
                            val r = a[i * size + k]
                            for (j in 0 until size) {
                                c[i * size + j] += r * b[k * size + j]
                            }
                        }
                    }
                    localOps += (2L * size * size * size)
                }
                totalOps.addAndGet(localOps)
            }
        }
        jobs.joinAll()
        val elapsedSec = (System.nanoTime() - startNs) / 1_000_000_000.0
        if (elapsedSec > 0) (totalOps.get().toDouble() / 1_000_000.0) / elapsedSec else 0.0
    }

    /**
     * Measures RAM LPDDR memory bandwidth in MB/s (throughput-based test).
     */
    private fun measureRamBandwidth(durationMs: Long): Double {
        val deadline = System.currentTimeMillis() + durationMs
        val bufferSize = 8 * 1024 * 1024 // 8 MB buffer
        val src = ByteArray(bufferSize)
        val dst = ByteArray(bufferSize)
        Random.nextBytes(src)

        var totalBytesCopied = 0L
        val startNs = System.nanoTime()

        while (System.currentTimeMillis() < deadline) {
            System.arraycopy(src, 0, dst, 0, bufferSize)
            totalBytesCopied += bufferSize
        }

        val elapsedSec = (System.nanoTime() - startNs) / 1_000_000_000.0
        val totalMb = totalBytesCopied / (1024.0 * 1024.0)
        return if (elapsedSec > 0) totalMb / elapsedSec else 0.0
    }

    /**
     * Measures internal storage I/O speed in MB/s (throughput-based test).
     */
    private fun measureStorageThroughput(durationMs: Long): Double {
        val ts = System.currentTimeMillis()
        val writeFile = File(context.cacheDir, "bench_io_w_$ts.tmp")
        val readFile = File(context.cacheDir, "bench_io_r_$ts.tmp")
        val chunkSize = 4 * 1024 * 1024 // 4 MB chunk
        val writeBuffer = ByteArray(chunkSize)
        val readBuffer = ByteArray(chunkSize)
        Random.nextBytes(writeBuffer)

        var totalBytes = 0L
        var startNs = 0L

        try {
            FileOutputStream(readFile).use { fos ->
                fos.write(writeBuffer)
                fos.flush()
                fos.fd.sync()
            }

            val deadline = System.currentTimeMillis() + durationMs
            startNs = System.nanoTime()

            while (System.currentTimeMillis() < deadline) {
                FileOutputStream(writeFile).use { fos ->
                    fos.write(writeBuffer)
                    fos.flush()
                    fos.fd.sync()
                }
                FileInputStream(readFile).use { fis ->
                    var offset = 0
                    while (offset < chunkSize) {
                        val read = fis.read(readBuffer, offset, chunkSize - offset)
                        if (read <= 0) break
                        offset += read
                    }
                }
                totalBytes += (chunkSize * 2)
            }
        } catch (_: Exception) {
        } finally {
            writeFile.delete()
            readFile.delete()
        }

        val elapsedSec = if (startNs > 0L) (System.nanoTime() - startNs) / 1_000_000_000.0 else 0.0
        val totalMb = totalBytes / (1024.0 * 1024.0)
        return if (elapsedSec > 0) totalMb / elapsedSec else 0.0
    }

    private fun calculateVariation(runs: List<Double>, metricType: MetricType): MetricVariation {
        if (runs.isEmpty()) return MetricVariation(0.0, 0.0, 0.0, 0.0, metricType)
        val sorted = runs.sorted()
        val median = sorted[sorted.size / 2] // Exact median (index 2 for 5 iterations)
        val min = sorted.first()
        val max = sorted.last()
        val avg = runs.average()
        return MetricVariation(median = median, min = min, max = max, avg = avg, metricType = metricType)
    }
}
