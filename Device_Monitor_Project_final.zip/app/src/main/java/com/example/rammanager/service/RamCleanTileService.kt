package com.example.rammanager.service

import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.rammanager.R
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@RequiresApi(Build.VERSION_CODES.N)
class RamCleanTileService : TileService() {

    private val tileScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onStartListening() {
        super.onStartListening()
        try {
            val tile = qsTile ?: return
            val hasPerm = ShizukuCommandRunner.hasPermission()
            tile.label = getString(R.string.tile_clean_ram_label)
            tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_ram)
            tile.state = if (hasPerm) Tile.STATE_INACTIVE else Tile.STATE_UNAVAILABLE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                tile.subtitle = if (hasPerm) null else getString(R.string.shizuku_not_active)
            }
            tile.updateTile()
        } catch (_: Throwable) {}
    }

    override fun onClick() {
        super.onClick()
        if (!ShizukuCommandRunner.hasPermission()) {
            Toast.makeText(this, getString(R.string.shizuku_not_active), Toast.LENGTH_SHORT).show()
            return
        }

        try {
            qsTile?.let { tile ->
                tile.state = Tile.STATE_ACTIVE
                tile.updateTile()
            }
        } catch (_: Throwable) {}

        tileScope.launch {
            val result = withContext(Dispatchers.IO) {
                ShizukuCommandRunner.runQuickClean(applicationContext)
            }
            Toast.makeText(
                applicationContext,
                "${getString(R.string.tile_clean_ram_label)}: ${result.stoppedCount} app (~${result.freedMb} MB)",
                Toast.LENGTH_SHORT
            ).show()
            try {
                qsTile?.let { tile ->
                    tile.state = Tile.STATE_INACTIVE
                    tile.updateTile()
                }
            } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tileScope.cancel()
    }
}
