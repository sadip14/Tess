package com.example.rammanager

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.example.rammanager.battery.BatteryAnalyticsEngine
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.BatteryCurrentFlow
import com.example.rammanager.model.BatteryHealthReport
import com.example.rammanager.model.BatterySessionRecord
import com.example.rammanager.model.BatterySessionType
import com.example.rammanager.model.BatterySmartEstimates
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.service.BatteryMonitorForegroundService
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class BatteryTrendPointNative(
    val timeLabel: String,
    val timestamp: Long,
    val level: Int,
    val currentMa: Int?,
    val tempC: Float?,
    val isCharging: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatteryScreen(
    hasShizukuPermission: Boolean,
    pollingIntervalSec: Int = 5,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val engine = remember { BatteryAnalyticsEngine(context) }
    val historyRepo = remember { BatteryHistoryRepository.getInstance(context) }
    val actionHistoryRepo = remember { HistoryRepository.getInstance(context) }
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedSubTab by remember { mutableStateOf("LIVE") } // LIVE, TREND, POWER, DRAIN, HEALTH, HISTORY

    var currentFlow by remember { mutableStateOf<BatteryCurrentFlow?>(null) }
    var smartEstimates by remember { mutableStateOf<BatterySmartEstimates?>(null) }
    var healthReport by remember { mutableStateOf<BatteryHealthReport?>(null) }
    var sessions by remember { mutableStateOf<List<BatterySessionRecord>>(emptyList()) }
    var wakelockApps by remember { mutableStateOf<List<ShizukuCommandRunner.WakelockAppInfo>>(emptyList()) }
    var drainApps by remember { mutableStateOf<List<AppProcessInfo>>(emptyList()) }
    var confirmActionTarget by remember { mutableStateOf<Triple<String, String, Boolean>?>(null) }
    var designCapacityMah by remember { mutableStateOf<Int?>(null) }
    var isServiceActive by remember { mutableStateOf(BatteryMonitorForegroundService.isServiceEnabled(context)) }
    var is80AlarmEnabled by remember { mutableStateOf(true) }
    var powerProfileMode by remember { mutableStateOf("BALANCED") } // POWER_SAVER, BALANCED, PERFORMANCE
    var shellOutputLog by remember { mutableStateOf("") }
    var showCapacityDialog by remember { mutableStateOf(false) }
    var inputCapacityText by remember { mutableStateOf("4500") }
    var batteryPercent by remember { mutableStateOf(80) }

    var selectedTrendIndex by remember { mutableStateOf(10) }

    val handlePowerProfileChange: (String) -> Unit = { mode ->
        scope.launch {
            val res = ShizukuCommandRunner.setPowerProfile(mode)
            if (res.isSuccess) {
                powerProfileMode = mode
                Toast.makeText(
                    context,
                    res.getOrNull() ?: context.getString(R.string.power_profile_applied, mode),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    context,
                    context.getString(R.string.power_profile_failed, res.exceptionOrNull()?.message ?: ""),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    LaunchedEffect(selectedSubTab, hasShizukuPermission) {
        if (selectedSubTab == "TREND" && hasShizukuPermission) {
            wakelockApps = ShizukuCommandRunner.fetchWakelockApps(context)
        } else if (selectedSubTab == "DRAIN") {
            val (_, procs) = ShizukuCommandRunner.fetchMemoryInfo(context)
            drainApps = procs.filter { !it.isSystemApp && !it.isSuspended && it.pssKb > 0 }.take(10)
        }
    }

    fun requestAppAction(pkg: String, appName: String, isSuspend: Boolean) {
        if (ShizukuCommandRunner.getProtectedPackages(context).contains(pkg)) {
            Toast.makeText(context, context.getString(R.string.protected_app_badge), Toast.LENGTH_SHORT).show()
            return
        }
        confirmActionTarget = Triple(pkg, appName, isSuspend)
    }

    fun executeConfirmedAction(pkg: String, appName: String, isSuspend: Boolean) {
        scope.launch {
            if (isSuspend) {
                val res = ShizukuCommandRunner.suspendApp(context, pkg)
                if (res.isSuccess) {
                    actionHistoryRepo.recordAction(pkg, appName, CleaningAction.SUSPEND, 0.0)
                    if (hasShizukuPermission) {
                        wakelockApps = ShizukuCommandRunner.fetchWakelockApps(context)
                    }
                    val (_, procs) = ShizukuCommandRunner.fetchMemoryInfo(context)
                    drainApps = procs.filter { !it.isSystemApp && !it.isSuspended && it.pssKb > 0 }.take(10)
                    onRefresh()

                    snackbarHostState.currentSnackbarData?.dismiss()
                    val undoJob = launch {
                        delay(6000L)
                        snackbarHostState.currentSnackbarData?.dismiss()
                    }
                    val snackRes = snackbarHostState.showSnackbar(
                        message = context.getString(R.string.snackbar_suspended, appName),
                        actionLabel = context.getString(R.string.undo),
                        duration = SnackbarDuration.Indefinite
                    )
                    undoJob.cancel()
                    if (snackRes == SnackbarResult.ActionPerformed) {
                        val unsuspRes = ShizukuCommandRunner.unsuspendApp(pkg)
                        if (unsuspRes.isSuccess) {
                            actionHistoryRepo.recordAction(pkg, appName, CleaningAction.UNSUSPEND, 0.0)
                            if (hasShizukuPermission) {
                                wakelockApps = ShizukuCommandRunner.fetchWakelockApps(context)
                            }
                            val (_, updatedProcs) = ShizukuCommandRunner.fetchMemoryInfo(context)
                            drainApps = updatedProcs.filter { !it.isSystemApp && !it.isSuspended && it.pssKb > 0 }.take(10)
                            onRefresh()
                        }
                    }
                } else {
                    Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                }
            } else {
                val res = ShizukuCommandRunner.forceStopApp(context, pkg)
                if (res.isSuccess) {
                    actionHistoryRepo.recordAction(pkg, appName, CleaningAction.FORCE_STOP, 0.0)
                    val (_, procs) = ShizukuCommandRunner.fetchMemoryInfo(context)
                    drainApps = procs.filter { !it.isSystemApp && !it.isSuspended && it.pssKb > 0 }.take(10)
                    onRefresh()

                    snackbarHostState.currentSnackbarData?.dismiss()
                    val undoJob = launch {
                        delay(6000L)
                        snackbarHostState.currentSnackbarData?.dismiss()
                    }
                    val snackRes = snackbarHostState.showSnackbar(
                        message = context.getString(R.string.snackbar_stopped, appName),
                        actionLabel = context.getString(R.string.reopen_app),
                        duration = SnackbarDuration.Indefinite
                    )
                    undoJob.cancel()
                    if (snackRes == SnackbarResult.ActionPerformed) {
                        try {
                            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                            if (launchIntent != null) {
                                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(launchIntent)
                            }
                        } catch (_: Throwable) {}
                    }
                } else {
                    Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val loadBatteryData = rememberUpdatedState {
        scope.launch {
            val detectedCap = try {
                ShizukuCommandRunner.getBatteryDesignCapacity(context)?.toInt()
            } catch (_: Throwable) {
                null
            }
            designCapacityMah = detectedCap

            val flow = try {
                engine.getLiveCurrentFlow()
            } catch (_: Throwable) {
                null
            }
            currentFlow = flow

            // Real Battery Level from BatteryManager intent
            val pct = try {
                val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
                val bIntent = context.registerReceiver(null, ifilter)
                val level = bIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = bIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                if (level >= 0 && scale > 0) (level * 100) / scale else batteryPercent
            } catch (_: Throwable) {
                batteryPercent
            }
            batteryPercent = pct

            var detectedActual: Double? = null
            try {
                if (detectedCap != null && detectedCap > 0) {
                    detectedActual = try {
                        ShizukuCommandRunner.getBatteryActualCapacity(context)
                    } catch (_: Throwable) {
                        null
                    }
                    healthReport = historyRepo.getHealthReport(detectedCap, detectedActual)
                } else {
                    healthReport = null
                }
                sessions = historyRepo.getAllSessions()
                isServiceActive = BatteryMonitorForegroundService.isServiceEnabled(context)
            } catch (_: Throwable) {}

            val measuredCap = detectedActual ?: healthReport?.estimatedCapacityMah

            if (flow != null && detectedCap != null && detectedCap > 0) {
                try {
                    smartEstimates = engine.calculateSmartEstimates(
                        currentLevelPercent = pct,
                        designCapacityMah = detectedCap,
                        measuredCapacityMah = measuredCap,
                        isCharging = flow.isCharging,
                        currentMa = flow.currentNowMa
                    )
                } catch (_: Throwable) {}
            } else {
                smartEstimates = null
            }
        }
    }

    LaunchedEffect(lifecycleOwner, pollingIntervalSec) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                loadBatteryData.value()
                delay(pollingIntervalSec.coerceAtLeast(1) * 1000L)
            }
        }
    }

    // Build 24-hour Trend points based on real recorded sessions
    val trendPoints = remember(sessions, batteryPercent, currentFlow) {
        if (sessions.isEmpty()) {
            emptyList<BatteryTrendPointNative>()
        } else {
            val now = System.currentTimeMillis()
            val points = mutableListOf<BatteryTrendPointNative>()
            val cal = java.util.Calendar.getInstance()

            // Map sessions across 24 hours
            val sortedSessions = sessions.sortedBy { it.timestamp }
            for (i in 11 downTo 0) {
                val pastTime = now - (i * 2 * 3600 * 1000L)
                cal.timeInMillis = pastTime
                val timeLabel = String.format("%02d:00", cal.get(java.util.Calendar.HOUR_OF_DAY))

                val matched = sortedSessions.firstOrNull { s ->
                    kotlin.math.abs(s.timestamp - pastTime) <= 2 * 3600 * 1000L
                }

                if (matched != null) {
                    points.add(
                        BatteryTrendPointNative(
                            timeLabel = timeLabel,
                            timestamp = pastTime,
                            level = matched.endPercent,
                            currentMa = matched.avgCurrentMa?.toInt(),
                            tempC = matched.peakTempC?.toFloat(),
                            isCharging = matched.isCharging
                        )
                    )
                } else if (i == 0) {
                    points.add(
                        BatteryTrendPointNative(
                            timeLabel = timeLabel,
                            timestamp = pastTime,
                            level = batteryPercent,
                            currentMa = currentFlow?.currentNowMa,
                            tempC = currentFlow?.tempC,
                            isCharging = currentFlow?.isCharging == true
                        )
                    )
                }
            }
            points
        }
    }

    // Deep Sleep & Wakelock calculations using REAL Android kernel uptime & elapsedRealtime
    val elapsedRealtime = SystemClock.elapsedRealtime()
    val uptime = SystemClock.uptimeMillis()
    val deepSleepMs = (elapsedRealtime - uptime).coerceAtLeast(0L)
    val deepSleepPercent = (deepSleepMs * 100f / elapsedRealtime.coerceAtLeast(1L)).coerceIn(0f, 100f)
    val awakePercent = (100f - deepSleepPercent).coerceIn(0f, 100f)
    val screenOffHours = deepSleepMs / (1000.0 * 3600.0)

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B101B))
                .padding(horizontal = 14.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 56.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
        // Sub-Tab Switcher Pills matching web preview
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF141B27), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                    .padding(4.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val subTabs = listOf(
                    "LIVE" to stringResource(R.string.battery_subtab_live),
                    "TREND" to stringResource(R.string.battery_subtab_trend),
                    "POWER" to stringResource(R.string.battery_subtab_power),
                    "DRAIN" to stringResource(R.string.battery_subtab_drain),
                    "HEALTH" to stringResource(R.string.battery_subtab_health),
                    "HISTORY" to stringResource(R.string.battery_subtab_history)
                )

                subTabs.forEach { (key, label) ->
                    val isSelected = selectedSubTab == key
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color(0xFF0284C7) else Color.Transparent)
                            .clickable { selectedSubTab = key }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        
        when (selectedSubTab) {
            "LIVE" -> renderLiveSubTab(
                context = context,
                scope = scope,
                currentFlow = currentFlow,
                smartEstimates = smartEstimates,
                batteryPercent = batteryPercent,
                designCapacityMah = designCapacityMah,
                isServiceActive = isServiceActive,
                onToggleService = { checked ->
                    isServiceActive = checked
                    BatteryMonitorForegroundService.setServiceEnabled(context, checked)
                    if (checked) {
                        BatteryMonitorForegroundService.startService(context)
                        Toast.makeText(context, "Layanan monitor baterai diaktifkan", Toast.LENGTH_SHORT).show()
                    } else {
                        BatteryMonitorForegroundService.stopService(context)
                        Toast.makeText(context, "Layanan monitor baterai dinonaktifkan", Toast.LENGTH_SHORT).show()
                    }
                },
                is80AlarmEnabled = is80AlarmEnabled,
                onToggle80Alarm = { is80AlarmEnabled = it },
                powerProfileMode = powerProfileMode,
                onPowerProfileChange = handlePowerProfileChange,
                onOpenCapacityDialog = {
                    inputCapacityText = (designCapacityMah ?: "").toString()
                    showCapacityDialog = true
                },
                onRefresh = onRefresh
            )
            "TREND" -> renderTrendSubTab(
                context = context,
                scope = scope,
                trendPoints = trendPoints,
                selectedTrendIndex = selectedTrendIndex,
                onSelectTrendIndex = { selectedTrendIndex = it },
                sessions = sessions,
                deepSleepPercent = deepSleepPercent,
                awakePercent = awakePercent,
                screenOffHours = screenOffHours,
                batteryPercent = batteryPercent,
                smartEstimates = smartEstimates,
                wakelockApps = wakelockApps,
                onRequestSuspend = { pkg, name -> requestAppAction(pkg, name, isSuspend = true) }
            )
            "POWER" -> renderPowerSubTab(
                context = context,
                scope = scope,
                powerProfileMode = powerProfileMode,
                onPowerProfileChange = handlePowerProfileChange,
                hasShizukuPermission = hasShizukuPermission,
                shellOutputLog = shellOutputLog,
                onRunShellCommand = { cmd ->
                    scope.launch {
                        shellOutputLog = "Menjalankan: $cmd\n..."
                        val res = ShizukuCommandRunner.executeCommand(cmd)
                        shellOutputLog = if (res.isSuccess) {
                            "HASIL PERINTAH:\n${res.getOrNull() ?: "(Tidak ada output)"}"
                        } else {
                            "ERROR:\n${res.exceptionOrNull()?.message}"
                        }
                    }
                }
            )
            "DRAIN" -> renderDrainSubTab(
                drainApps = drainApps,
                onRequestSuspend = { pkg, name -> requestAppAction(pkg, name, isSuspend = true) },
                onRequestStop = { pkg, name -> requestAppAction(pkg, name, isSuspend = false) }
            )
            "HEALTH" -> renderHealthSubTab(
                healthReport = healthReport,
                designCapacityMah = designCapacityMah,
                onOpenCapacityDialog = {
                    inputCapacityText = (designCapacityMah ?: "").toString()
                    showCapacityDialog = true
                }
            )
            "HISTORY" -> renderHistorySubTab(
                context = context,
                scope = scope,
                historyRepo = historyRepo,
                sessions = sessions,
                onSessionsCleared = {
                    sessions = emptyList()
                    loadBatteryData.value()
                }
            )
        }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }

    confirmActionTarget?.let { (pkg, appName, isSuspend) ->
        AlertDialog(
            onDismissRequest = { confirmActionTarget = null },
            containerColor = Color(0xFF141B27),
            title = {
                Text(
                    text = stringResource(if (isSuspend) R.string.confirm_suspend_title else R.string.confirm_stop_title),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isSuspend) {
                        stringResource(R.string.confirm_suspend_msg, appName, pkg)
                    } else {
                        stringResource(R.string.confirm_stop_msg, appName)
                    },
                    color = Color(0xFFCBD5E1),
                    fontSize = 12.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmActionTarget = null
                        executeConfirmedAction(pkg, appName, isSuspend)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSuspend) Color(0xFF7C3AED) else Color(0xFFDC2626)
                    )
                ) {
                    Text(stringResource(R.string.confirm), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmActionTarget = null }) {
                    Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8))
                }
            }
        )
    }

    if (showCapacityDialog) {
        BatteryCapacityDialog(
            context = context,
            inputCapacityText = inputCapacityText,
            onInputTextChange = { inputCapacityText = it },
            onDismiss = { showCapacityDialog = false },
            onSave = { num ->
                designCapacityMah = num
                val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                prefs.edit().putFloat("user_battery_design_capacity", num.toFloat()).apply()
                showCapacityDialog = false
                loadBatteryData.value()
                Toast.makeText(context, "Kapasitas tersimpan: $num mAh", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

private fun LazyListScope.renderLiveSubTab(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    currentFlow: BatteryCurrentFlow?,
    smartEstimates: BatterySmartEstimates?,
    batteryPercent: Int,
    designCapacityMah: Int?,
    isServiceActive: Boolean,
    onToggleService: (Boolean) -> Unit,
    is80AlarmEnabled: Boolean,
    onToggle80Alarm: (Boolean) -> Unit,
    powerProfileMode: String,
    onPowerProfileChange: (String) -> Unit,
    onOpenCapacityDialog: () -> Unit,
    onRefresh: () -> Unit
) {
// Hero Electric Current Flow Card
            item {
                val flow = currentFlow
                val isCharging = flow?.isCharging == true
                val flowMa = flow?.currentNowMa ?: 0

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.linearGradient(
                            listOf(
                                if (isCharging) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF0284C7).copy(alpha = 0.4f),
                                Color(0xFF1E293B)
                            )
                        )
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                if (isCharging) listOf(Color(0xFF0D281E), Color(0xFF121927))
                                else listOf(Color(0xFF11223A), Color(0xFF121722))
                            ),
                            RoundedCornerShape(16.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f, fill = false),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isCharging) Color(0xFF10B981) else Color(0xFF38BDF8))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isCharging) "ARUS PENGISIAN (CHARGING)" else "ARUS PENGURASAN (DISCHARGING)",
                                    color = Color(0xFFCBD5E1),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = flow?.chargeSpeedType ?: if (isCharging) "Charging" else "Layar Nyala",
                                color = Color(0xFF94A3B8),
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                val notAvail = stringResource(R.string.not_available)
                                val hasCurrent = flow?.currentNowMa != null
                                val sign = if (hasCurrent && isCharging && flowMa > 0) "+$flowMa" else "$flowMa"
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = if (hasCurrent) sign else notAvail,
                                        color = if (!hasCurrent) Color(0xFF94A3B8) else if (isCharging) Color(0xFF34D399) else Color(0xFF7DD3FC),
                                        fontSize = if (hasCurrent) 32.sp else 18.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    if (hasCurrent) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "mA",
                                            color = if (isCharging) Color(0xFF34D399) else Color(0xFF7DD3FC),
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(bottom = 4.dp)
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(top = 2.dp)
                                ) {
                                    Text(
                                        text = "Daya: ${flow?.formattedPower ?: notAvail}",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 10.sp
                                    )
                                    Text(text = "•", color = Color(0xFF64748B), fontSize = 10.sp)
                                    Text(
                                        text = "Tegangan: ${flow?.formattedVoltage ?: notAvail}",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$batteryPercent%",
                                    color = Color.White,
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = if (isCharging) "Mengisi Daya" else "Kapasitas Tersisa",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 9.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Visual battery level progress bar
                        LinearProgressIndicator(
                            progress = { (batteryPercent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (isCharging) Color(0xFF10B981) else if (batteryPercent > 20) Color(0xFF0284C7) else Color(0xFFEF4444),
                            trackColor = Color(0xFF1E293B)
                        )
                    }
                }
            }

            // Quick Power Profile Switcher
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Mode Daya Aktif:", color = Color(0xFFCBD5E1), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(
                                "POWER_SAVER" to "🌿 Hemat",
                                "BALANCED" to "⚖️ Standar",
                                "PERFORMANCE" to "⚡ Performa"
                            ).forEach { (mode, label) ->
                                val isSelected = powerProfileMode == mode
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            if (isSelected) {
                                                if (mode == "POWER_SAVER") Color(0xFF059669)
                                                else if (mode == "PERFORMANCE") Color(0xFFE11D48)
                                                else Color(0xFF0284C7)
                                            } else Color(0xFF1E293B)
                                        )
                                        .clickable {
                                            onPowerProfileChange(mode)
                                        }
                                        .padding(horizontal = 7.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) Color.White else Color(0xFF94A3B8),
                                        fontSize = 9.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Primary Time Estimate Card
            item {
                val est = smartEstimates
                val isCharging = currentFlow?.isCharging == true

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isCharging) "Perkiraan Waktu Hingga Penuh" else "Perkiraan Waktu Habis",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (isCharging) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("Hingga 100% Penuh:", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                                if (est?.isChargingCapacityEstimated == true) {
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "(${stringResource(R.string.estimated_capacity_label)})",
                                                        color = Color(0xFF64748B),
                                                        fontSize = 8.5.sp
                                                    )
                                                }
                                            }
                                            Text(
                                                text = est?.timeToFullMinutes?.let { "~${it}m lagi" } ?: stringResource(R.string.not_available),
                                                color = if (est?.timeToFullMinutes != null) Color(0xFF10B981) else Color(0xFF94A3B8),
                                                fontSize = if (est?.timeToFullMinutes != null) 16.sp else 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            val ma = currentFlow?.currentNowMa
                                            val effectiveCap = if (est?.isChargingCapacityEstimated == false && healthReport?.estimatedCapacityMah != null) {
                                                healthReport?.estimatedCapacityMah
                                            } else {
                                                designCapacityMah?.toDouble()
                                            }
                                            val rateText = if (effectiveCap != null && effectiveCap > 0 && ma != null && ma > 50) {
                                                val ratePct = ((kotlin.math.abs(ma).toFloat() / effectiveCap) * 100).roundToInt()
                                                val capLabel = if (est?.isChargingCapacityEstimated == true) " (${stringResource(R.string.estimated_capacity_label)})" else ""
                                                "Kecepatan: +$ratePct% / jam$capLabel"
                                            } else {
                                                stringResource(R.string.not_available)
                                            }
                                            Text(rateText, color = Color(0xFF64748B), fontSize = 8.5.sp)
                                        }
                                        Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(24.dp))
                                    }
                                }

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Alarm Proteksi 80%:", color = Color(0xFFFBBF24), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                            Text(
                                                text = est?.timeTo80PercentMinutes?.let { "~${it}m lagi" } ?: stringResource(R.string.not_available),
                                                color = if (est?.timeTo80PercentMinutes != null) Color.White else Color(0xFF94A3B8),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFFF59E0B).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("Kurangi Beban Siklus", color = Color(0xFFFCD34D), fontSize = 8.5.sp)
                                        }
                                    }
                                }
                            }
                        } else {
                            val insufficientDataText = stringResource(R.string.insufficient_battery_data)
                            val hasData = est?.hasDischargeData == true

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Layar Nyala (SOT)", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                        if (hasData && est?.timeToEmptyScreenOnMinutes != null && est.timeToEmptyScreenOnMinutes > 0) {
                                            Text(
                                                text = est.formatMinutes(est.timeToEmptyScreenOnMinutes),
                                                color = Color(0xFF38BDF8),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(vertical = 2.dp)
                                            )
                                            val sotRate = est.screenOnDrainRatePerHour
                                            val sotRateText = if (sotRate != null && sotRate > 0) {
                                                String.format(Locale.US, "-%.1f%%/j", sotRate)
                                            } else {
                                                String.format(Locale.US, "-%.1f%%/j", batteryPercent.toFloat() / (est.timeToEmptyScreenOnMinutes / 60f))
                                            }
                                            Text(
                                                text = sotRateText,
                                                color = Color(0xFF64748B),
                                                fontSize = 8.sp
                                            )
                                        } else {
                                            Text(
                                                text = insufficientDataText,
                                                color = Color(0xFF94A3B8),
                                                fontSize = 7.5.sp,
                                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                                modifier = Modifier.padding(vertical = 4.dp)
                                            )
                                        }
                                    }
                                }

                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Layar Mati (Sleep)", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                        if (hasData && est?.timeToEmptyScreenOffMinutes != null && est.timeToEmptyScreenOffMinutes > 0) {
                                            Text(
                                                text = est.formatMinutes(est.timeToEmptyScreenOffMinutes),
                                                color = Color(0xFF10B981),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(vertical = 2.dp)
                                            )
                                            val sleepRate = est.screenOffDrainRatePerHour
                                            val sleepRateText = if (sleepRate != null && sleepRate > 0) {
                                                String.format(Locale.US, "-%.2f%%/j", sleepRate)
                                            } else {
                                                String.format(Locale.US, "-%.2f%%/j", batteryPercent.toFloat() / (est.timeToEmptyScreenOffMinutes / 60f))
                                            }
                                            Text(
                                                text = sleepRateText,
                                                color = Color(0xFF64748B),
                                                fontSize = 8.sp
                                            )
                                        } else {
                                            Text(
                                                text = insufficientDataText,
                                                color = Color(0xFF94A3B8),
                                                fontSize = 7.5.sp,
                                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                                modifier = Modifier.padding(vertical = 4.dp)
                                            )
                                        }
                                    }
                                }

                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Campuran", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                        if (hasData && est?.timeToEmptyMixedMinutes != null && est.timeToEmptyMixedMinutes > 0) {
                                            Text(
                                                text = est.formatMinutes(est.timeToEmptyMixedMinutes),
                                                color = Color(0xFFFBBF24),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(vertical = 2.dp)
                                            )
                                            val mixedRate = est.mixedDrainRatePerHour
                                            val mixedRateText = if (mixedRate != null && mixedRate > 0) {
                                                String.format(Locale.US, "-%.1f%%/j", mixedRate)
                                            } else {
                                                "Rasio 7 hari"
                                            }
                                            Text(mixedRateText, color = Color(0xFF64748B), fontSize = 8.sp)
                                        } else {
                                            Text(
                                                text = insufficientDataText,
                                                color = Color(0xFF94A3B8),
                                                fontSize = 7.5.sp,
                                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                                modifier = Modifier.padding(vertical = 4.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Popular Activities Breakdown
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Estimasi Berdasarkan Aktivitas (Perkiraan Umum)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Baterai $batteryPercent%", color = Color(0xFF94A3B8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val activities = listOf(
                            Triple("Nonton Video / YouTube", 8.5f, (batteryPercent / 8.5f * 60).toInt()),
                            Triple("Bermain Game (FPS/3D)", 19.5f, (batteryPercent / 19.5f * 60).toInt()),
                            Triple("Sosial Media / Chatting", 10.0f, (batteryPercent / 10.0f * 60).toInt()),
                            Triple("Mendengarkan Musik / Spotify", 3.2f, (batteryPercent / 3.2f * 60).toInt())
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(activities[0].first, color = Color(0xFFCBD5E1), fontSize = 9.sp, maxLines = 1)
                                    Text("~${activities[0].second}% / jam", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${activities[0].third / 60}j ${activities[0].third % 60}m", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(activities[1].first, color = Color(0xFFCBD5E1), fontSize = 9.sp, maxLines = 1)
                                    Text("~${activities[1].second}% / jam", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${activities[1].third / 60}j ${activities[1].third % 60}m", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(activities[2].first, color = Color(0xFFCBD5E1), fontSize = 9.sp, maxLines = 1)
                                    Text("~${activities[2].second}% / jam", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${activities[2].third / 60}j ${activities[2].third % 60}m", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(activities[3].first, color = Color(0xFFCBD5E1), fontSize = 9.sp, maxLines = 1)
                                    Text("~${activities[3].second}% / jam", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${activities[3].third / 60}j ${activities[3].third % 60}m", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Foreground Service & Alarm 80% Switcher Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Notifications, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Layanan Background & Alarm Proteksi", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = if (isServiceActive) "Service Aktif" else "Service Nonaktif",
                                color = if (isServiceActive) Color(0xFF10B981) else Color(0xFF64748B),
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Switch 1: Foreground Service
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Foreground Service (Latar Belakang)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Notifikasi persisten ringan agar kernel tidak mematikan monitoring baterai", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                }
                                Switch(
                                    checked = isServiceActive,
                                    onCheckedChange = { checked ->
                                        onToggleService(checked)
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF10B981),
                                        uncheckedThumbColor = Color(0xFF94A3B8),
                                        uncheckedTrackColor = Color(0xFF1E293B)
                                    ),
                                    modifier = Modifier.height(28.dp)
                                )
                            }
                        }

                        // Switch 2: Alarm 80%
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Alarm Pengisian 80%", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Mengingatkan cabut charger untuk menjaga kesehatan sel baterai", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                }
                                Switch(
                                    checked = is80AlarmEnabled,
                                    onCheckedChange = { onToggle80Alarm(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFFF59E0B),
                                        uncheckedThumbColor = Color(0xFF94A3B8),
                                        uncheckedTrackColor = Color(0xFF1E293B)
                                    ),
                                    modifier = Modifier.height(28.dp)
                                )
                            }
                        }
                    }
                }
            }
}

private fun LazyListScope.renderTrendSubTab(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    trendPoints: List<BatteryTrendPointNative>,
    selectedTrendIndex: Int,
    onSelectTrendIndex: (Int) -> Unit,
    sessions: List<BatterySessionRecord>,
    deepSleepPercent: Float,
    awakePercent: Float,
    screenOffHours: Double,
    batteryPercent: Int,
    smartEstimates: BatterySmartEstimates?,
    wakelockApps: List<ShizukuCommandRunner.WakelockAppInfo>,
    onRequestSuspend: (String, String) -> Unit
) {
// Visual 24-Hour Battery Trend Interactive Chart
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TrendingDown, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.trend_chart_title), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(stringResource(R.string.trend_chart_tap_hint), color = Color(0xFF64748B), fontSize = 8.5.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (trendPoints.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF0A0F1A), RoundedCornerShape(10.dp))
                                    .padding(vertical = 24.dp, horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.TrendingDown, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(28.dp))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("Belum Cukup Data 24 Jam", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Aktifkan Layanan Background dan lakukan pengisian baterai untuk mencatat kurva tren riil.",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 9.sp,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        } else {
                            // Compose Canvas for Trend Graph
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .background(Color(0xFF0A0F1A), RoundedCornerShape(10.dp))
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val w = size.width
                                    val h = size.height

                                    // Draw horizontal dashed grid lines
                                    val y100 = 10f
                                    val y60 = h * 0.5f
                                    val y20 = h - 10f

                                    drawLine(Color(0xFF1E293B), Offset(0f, y100), Offset(w, y100), strokeWidth = 1f)
                                    drawLine(Color(0xFF1E293B), Offset(0f, y60), Offset(w, y60), strokeWidth = 1f)
                                    drawLine(Color(0xFF1E293B), Offset(0f, y20), Offset(w, y20), strokeWidth = 1f)

                                    val count = trendPoints.size
                                    val stepX = if (count > 1) w / (count - 1) else w

                                    val path = Path()
                                    val fillPath = Path()

                                    trendPoints.forEachIndexed { idx, p ->
                                        val x = idx * stepX
                                        val y = y100 + (1f - (p.level / 100f)) * (y20 - y100)
                                        if (idx == 0) {
                                            path.moveTo(x, y)
                                            fillPath.moveTo(x, y20)
                                            fillPath.lineTo(x, y)
                                        } else {
                                            path.lineTo(x, y)
                                            fillPath.lineTo(x, y)
                                        }
                                        if (idx == count - 1) {
                                            fillPath.lineTo(x, y20)
                                            fillPath.close()
                                        }
                                    }

                                    // Fill under curve
                                    drawPath(
                                        fillPath,
                                        brush = Brush.verticalGradient(
                                            listOf(Color(0xFF0284C7).copy(alpha = 0.35f), Color(0xFF0284C7).copy(alpha = 0.0f)),
                                            startY = y100,
                                            endY = y20
                                        )
                                    )

                                    // Stroke line
                                    drawPath(
                                        path,
                                        color = Color(0xFF38BDF8),
                                        style = Stroke(width = 4f, cap = StrokeCap.Round)
                                    )

                                    // Points
                                    trendPoints.forEachIndexed { idx, p ->
                                        val x = idx * stepX
                                        val y = y100 + (1f - (p.level / 100f)) * (y20 - y100)
                                        val isSel = idx == selectedTrendIndex.coerceIn(0, count - 1)
                                        drawCircle(
                                            color = if (p.isCharging) Color(0xFF10B981) else if (isSel) Color(0xFF38BDF8) else Color(0xFF0284C7),
                                            radius = if (isSel) 7f else if (p.isCharging) 5f else 3.5f,
                                            center = Offset(x, y)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Selected Point Detail Card
                            val selPoint = trendPoints.getOrNull(selectedTrendIndex.coerceIn(0, (trendPoints.size - 1).coerceAtLeast(0)))
                            if (selPoint != null) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(8.dp),
                                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF0284C7).copy(alpha = 0.4f), Color(0xFF0284C7).copy(alpha = 0.4f)))),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("Jam ${selPoint.timeLabel}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .background(if (selPoint.isCharging) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF0284C7).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                                ) {
                                                    Text(if (selPoint.isCharging) "⚡ Mengisi Daya" else "🔻 Pemakaian", color = if (selPoint.isCharging) Color(0xFF6EE7B7) else Color(0xFF7DD3FC), fontSize = 8.sp)
                                                }
                                            }
                                            val currentStr = selPoint.currentMa?.let { "${if (it > 0) "+$it" else it} mA" } ?: stringResource(R.string.not_available)
                                            val tempStr = selPoint.tempC?.let { "$it°C" } ?: stringResource(R.string.not_available)
                                            Text("Arus: $currentStr • Suhu: $tempStr", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                        }
                                        Text("${selPoint.level}%", color = Color(0xFF38BDF8), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Audit Deep Sleep & Wakelock Card (Real Kernel Data)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.deep_sleep_audit_title), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(stringResource(R.string.deep_sleep_quality), color = Color(0xFF10B981), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Ratio Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(String.format("Deep Sleep: %.1f%%", deepSleepPercent), color = Color(0xFF10B981), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(String.format("Wakelock: %.1f%%", awakePercent), color = Color(0xFFFBBF24), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight((deepSleepPercent).coerceAtLeast(1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFF10B981))
                            )
                            Box(
                                modifier = Modifier
                                    .weight((awakePercent).coerceAtLeast(1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFFF59E0B))
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Layar Mati: ~${String.format("%.1f", screenOffHours)} jam", color = Color(0xFF64748B), fontSize = 8.5.sp)
                            val sleepMins = smartEstimates?.timeToEmptyScreenOffMinutes
                            val drainText = if (sleepMins != null && sleepMins > 0 && batteryPercent > 0) {
                                String.format(Locale.US, "Pengurasan: ~%.2f%% / jam", batteryPercent.toFloat() / (sleepMins / 60f))
                            } else {
                                stringResource(R.string.not_available)
                            }
                            Text(drainText, color = Color(0xFF64748B), fontSize = 8.5.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(stringResource(R.string.top_wakelock_apps), color = Color(0xFFCBD5E1), fontSize = 9.5.sp, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(6.dp))

                        if (wakelockApps.isEmpty()) {
                            Text(
                                text = stringResource(R.string.not_available),
                                color = Color(0xFF94A3B8),
                                fontSize = 9.5.sp
                            )
                        } else {
                            wakelockApps.forEach { app ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(app.appName, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                            Text(
                                                text = if (app.isProtected && app.protectionReason.isNotEmpty()) {
                                                    "${app.tag} • ${app.protectionReason}"
                                                } else {
                                                    app.tag
                                                },
                                                color = Color(0xFF94A3B8),
                                                fontSize = 8.5.sp
                                            )
                                        }
                                        if (app.isProtected) {
                                            Icon(
                                                imageVector = Icons.Default.Lock,
                                                contentDescription = stringResource(R.string.protected_app_badge),
                                                tint = Color(0xFF64748B),
                                                modifier = Modifier
                                                    .padding(horizontal = 8.dp)
                                                    .size(16.dp)
                                            )
                                        } else {
                                            Button(
                                                onClick = { onRequestSuspend(app.packageName, app.appName) },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(6.dp),
                                                modifier = Modifier.height(28.dp)
                                            ) {
                                                Text("Bekukan", fontSize = 9.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
}

private fun LazyListScope.renderPowerSubTab(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    powerProfileMode: String,
    onPowerProfileChange: (String) -> Unit,
    hasShizukuPermission: Boolean,
    shellOutputLog: String,
    onRunShellCommand: (String) -> Unit
) {
item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Profil Daya Sistem (Kernel Governor)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Kontrol Shell UID 2000", color = Color(0xFF38BDF8), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(
                            text = "Mengatur governor CPU, pembatasan refresh rate, dan sinkronisasi Android secara langsung via Shizuku.",
                            color = Color(0xFF94A3B8),
                            fontSize = 9.5.sp
                        )

                        // Profile 1: Hemat
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    listOf(if (powerProfileMode == "POWER_SAVER") Color(0xFF10B981) else Color(0xFF1E293B), Color(0xFF1E293B))
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onPowerProfileChange("POWER_SAVER")
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("🌿 Hemat Baterai (Power Saver)", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        if (powerProfileMode == "POWER_SAVER") {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Aktif", color = Color(0xFF10B981), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text("Layar 60Hz • Batasi clock CPU 70% • Hemat ~35%", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                    Text("settings put global low_power 1", color = Color(0xFF38BDF8), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("~ -195 mA", color = Color(0xFF10B981), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }

                        // Profile 2: Standar
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    listOf(if (powerProfileMode == "BALANCED") Color(0xFF0284C7) else Color(0xFF1E293B), Color(0xFF1E293B))
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onPowerProfileChange("BALANCED")
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("⚖️ Standar (Balanced)", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        if (powerProfileMode == "BALANCED") {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Aktif", color = Color(0xFF38BDF8), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text("Layar adaptif 120Hz • Governor schedutil", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                    Text("cmd power set-mode 0", color = Color(0xFF38BDF8), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("~ -320 mA", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }

                        // Profile 3: Performa
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    listOf(if (powerProfileMode == "PERFORMANCE") Color(0xFFE11D48) else Color(0xFF1E293B), Color(0xFF1E293B))
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onPowerProfileChange("PERFORMANCE")
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("⚡ Performa Maksimal (Gaming)", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        if (powerProfileMode == "PERFORMANCE") {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Aktif", color = Color(0xFFF43F5E), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text("120Hz terkunci • Clock frekuensi CPU maksimum", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                    Text("cmd power set-mode 2", color = Color(0xFF38BDF8), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("~ -510 mA", color = Color(0xFFF43F5E), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }

                        // Terminal Log
                        if (shellOutputLog.isNotEmpty()) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0F1A)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Terminal Log:", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Text(shellOutputLog, color = Color(0xFF38BDF8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
}

private fun LazyListScope.renderDrainSubTab(
    drainApps: List<AppProcessInfo>,
    onRequestSuspend: (String, String) -> Unit,
    onRequestStop: (String, String) -> Unit
) {
item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pelacak Boros Baterai & Solusi Auto-Restart", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Aplikasi latar belakang aktif dengan konsumsi memori tertinggi dapat dibekukan (pm suspend) atau dihentikan agar tidak menguras daya.",
                            color = Color(0xFF94A3B8),
                            fontSize = 9.5.sp
                        )

                        if (drainApps.isEmpty()) {
                            Text(
                                text = stringResource(R.string.not_available),
                                color = Color(0xFF94A3B8),
                                fontSize = 9.5.sp
                            )
                        } else {
                            drainApps.forEach { proc ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(proc.appName, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                            Text(
                                                text = if (proc.isProtected && proc.protectionReason.isNotEmpty()) {
                                                    "${proc.pssMb} MB • ${proc.protectionReason}"
                                                } else {
                                                    "${proc.pssMb} MB • ${proc.oomCategory}"
                                                },
                                                color = Color(0xFF94A3B8),
                                                fontSize = 8.5.sp
                                            )
                                        }

                                        if (proc.isProtected) {
                                            Icon(
                                                imageVector = Icons.Default.Lock,
                                                contentDescription = stringResource(R.string.protected_app_badge),
                                                tint = Color(0xFF64748B),
                                                modifier = Modifier
                                                    .padding(horizontal = 8.dp)
                                                    .size(16.dp)
                                            )
                                        } else {
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Button(
                                                    onClick = { onRequestSuspend(proc.packageName, proc.appName) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                                    shape = RoundedCornerShape(6.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text("Bekukan", fontSize = 9.sp)
                                                }

                                                Button(
                                                    onClick = { onRequestStop(proc.packageName, proc.appName) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                                    shape = RoundedCornerShape(6.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text("Stop", fontSize = 9.sp, color = Color(0xFFF87171))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
}

private fun LazyListScope.renderHealthSubTab(
    healthReport: BatteryHealthReport?,
    designCapacityMah: Int?,
    onOpenCapacityDialog: () -> Unit
) {
item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Kesehatan Baterai (Health Monitor)", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                healthReport?.let { hr ->
                                    val isKernel = hr.methodLabel.contains("Kernel") || hr.methodLabel.contains("Pembaca")
                                    val badgeBg = when {
                                        isKernel -> Color(0xFF10B981).copy(alpha = 0.15f)
                                        hr.hasSufficientData -> Color(0xFF38BDF8).copy(alpha = 0.15f)
                                        else -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                                    }
                                    val badgeColor = when {
                                        isKernel -> Color(0xFF34D399)
                                        hr.hasSufficientData -> Color(0xFF38BDF8)
                                        else -> Color(0xFFFBBF24)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(badgeBg, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = hr.methodLabel,
                                            color = badgeColor,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                            IconButton(
                                onClick = {
                                    onOpenCapacityDialog()
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val hr = healthReport
                        val hasData = hr != null && hr.hasSufficientData
                        val healthPct = if (hasData) hr?.healthPercentage else null
                        val wearPct = healthPct?.let { (100 - it).coerceAtLeast(0) }

                        // Circular ring
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(100.dp)
                        ) {
                            Canvas(modifier = Modifier.size(90.dp)) {
                                drawArc(
                                    color = Color(0xFF1E293B),
                                    startAngle = -90f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    style = Stroke(width = 16f, cap = StrokeCap.Round)
                                )
                                if (healthPct != null) {
                                    drawArc(
                                        color = if (healthPct >= 80) Color(0xFF10B981) else Color(0xFFF59E0B),
                                        startAngle = -90f,
                                        sweepAngle = (healthPct / 100f) * 360f,
                                        useCenter = false,
                                        style = Stroke(width = 16f, cap = StrokeCap.Round)
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = healthPct?.let { "$it%" } ?: "---",
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = if (hasData) (hr?.condition ?: "Baik") else stringResource(R.string.insufficient_data),
                                    color = if (hasData) Color(0xFF10B981) else Color(0xFFFBBF24),
                                    fontSize = 8.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = if (hasData) "Keausan Baterai: -$wearPct% dari kapasitas pabrik"
                            else "Lakukan pengisian baterai minimal 20% dalam satu sesi untuk mulai menghitung kesehatan baterai & siklus secara akurat.",
                            color = Color(0xFFCBD5E1),
                            fontSize = 9.5.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 13.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Kapasitas Pabrik", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                    Text(
                                        text = designCapacityMah?.let { "$it mAh" } ?: stringResource(R.string.not_available),
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Aktual Terukur", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                    Text(
                                        text = if (hasData) (hr?.formattedEstimatedCapacity ?: stringResource(R.string.not_available)) else stringResource(R.string.insufficient_data),
                                        color = if (hasData) Color(0xFF10B981) else Color(0xFF94A3B8),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Siklus Charge", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                    Text(
                                        text = if (hasData) "${hr?.cycleCount ?: 0}" else "0",
                                        color = Color(0xFFFBBF24),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
}

private fun LazyListScope.renderHistorySubTab(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    historyRepo: BatteryHistoryRepository,
    sessions: List<BatterySessionRecord>,
    onSessionsCleared: () -> Unit
) {
if (sessions.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Belum Ada Sesi Pengisian", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Colok charger atau aktifkan Foreground Service untuk mulai mencatat riwayat", color = Color(0xFF94A3B8), fontSize = 9.5.sp)
                        }
                    }
                }
            } else {
                items(sessions) { session ->
                    val sdf = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
                    val dateStr = sdf.format(Date(session.timestamp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                        shape = RoundedCornerShape(10.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (session.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                                        contentDescription = null,
                                        tint = if (session.isCharging) Color(0xFF10B981) else Color(0xFF38BDF8),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${session.startPercent}% → ${session.endPercent}%",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(dateStr, color = Color(0xFF64748B), fontSize = 9.sp)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Durasi: ${session.durationMinutes} menit • Energi: ${session.energyMah} mAh",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 9.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${session.avgCurrentMa ?: "--"} mA",
                                    color = if (session.isCharging) Color(0xFF10B981) else Color(0xFF38BDF8),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Puncak: " + (session.peakTempC?.let { String.format(Locale.US, "%.1f", it) } ?: "--") + "°C",
                                    color = Color(0xFF64748B),
                                    fontSize = 8.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }

@Composable
private fun BatteryCapacityDialog(
    context: Context,
    inputCapacityText: String,
    onInputTextChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: (Int) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141B27),
        title = {
            Text("Kapasitas Desain Pabrik", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text("Masukkan kapasitas desain baterai asli perangkat Anda (mAh):", color = Color(0xFF94A3B8), fontSize = 10.5.sp)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = inputCapacityText,
                    onValueChange = onInputTextChange,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0F172A),
                        unfocusedContainerColor = Color(0xFF0F172A),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val num = inputCapacityText.toIntOrNull()
                    if (num != null && num > 500) {
                        onSave(num)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("Simpan", fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal", color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
        }
    )
}
