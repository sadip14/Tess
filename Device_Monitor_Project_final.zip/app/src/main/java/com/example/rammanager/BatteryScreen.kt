package com.example.rammanager

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.battery.BatteryAnalyticsEngine
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.model.*
import com.example.rammanager.service.BatteryMonitorForegroundService
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class BatteryTrendPointNative(
    val timeLabel: String,
    val timestamp: Long,
    val level: Int,
    val currentMa: Int,
    val tempC: Float,
    val isCharging: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatteryScreen(
    hasShizukuPermission: Boolean,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { BatteryAnalyticsEngine(context) }
    val historyRepo = remember { BatteryHistoryRepository.getInstance(context) }

    var selectedSubTab by remember { mutableStateOf("LIVE") } // LIVE, TREND, POWER, DRAIN, HEALTH, HISTORY

    var currentFlow by remember { mutableStateOf<BatteryCurrentFlow?>(null) }
    var smartEstimates by remember { mutableStateOf<BatterySmartEstimates?>(null) }
    var healthReport by remember { mutableStateOf<BatteryHealthReport?>(null) }
    var sessions by remember { mutableStateOf<List<BatterySessionRecord>>(emptyList()) }
    var designCapacityMah by remember { mutableStateOf(4500) }
    var isServiceActive by remember { mutableStateOf(BatteryMonitorForegroundService.isServiceEnabled(context)) }
    var is80AlarmEnabled by remember { mutableStateOf(true) }
    var powerProfileMode by remember { mutableStateOf("BALANCED") } // POWER_SAVER, BALANCED, PERFORMANCE
    var shellOutputLog by remember { mutableStateOf("") }
    var showCapacityDialog by remember { mutableStateOf(false) }
    var inputCapacityText by remember { mutableStateOf("4500") }
    var batteryPercent by remember { mutableStateOf(80) }

    var selectedTrendIndex by remember { mutableStateOf(10) }

    val loadBatteryData = rememberUpdatedState {
        scope.launch {
            val detectedCap = ShizukuCommandRunner.getBatteryDesignCapacity(context)?.toInt() ?: 4500
            designCapacityMah = detectedCap

            val flow = engine.getLiveCurrentFlow()
            currentFlow = flow

            // Real Battery Level from BatteryManager intent
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val bIntent = context.registerReceiver(null, ifilter)
            val level = bIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 80
            val scale = bIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 80
            batteryPercent = pct

            smartEstimates = engine.calculateSmartEstimates(
                currentLevelPercent = pct,
                designCapacityMah = detectedCap,
                isCharging = flow.isCharging,
                currentMa = flow.currentNowMa
            )

            healthReport = historyRepo.getHealthReport(detectedCap)
            sessions = historyRepo.getAllSessions()
            isServiceActive = BatteryMonitorForegroundService.isServiceEnabled(context)
        }
    }

    LaunchedEffect(Unit) {
        loadBatteryData.value()
    }

    // Build 24-hour Trend points based on real recorded sessions
    val trendPoints = remember(sessions, batteryPercent, currentFlow) {
        if (sessions.isEmpty()) {
            emptyList<BatteryTrendPointNative>()
        } else {
            val now = System.currentTimeMillis()
            val points = mutableListOf<BatteryTrendPointNative>()
            val cal = java.util.Calendar.getInstance()

            // Map sessions across 24 hours
            val sortedSessions = sessions.sortedBy { it.timestamp }
            for (i in 11 downTo 0) {
                val pastTime = now - (i * 2 * 3600 * 1000L)
                cal.timeInMillis = pastTime
                val timeLabel = String.format("%02d:00", cal.get(java.util.Calendar.HOUR_OF_DAY))

                val matched = sortedSessions.firstOrNull { s ->
                    kotlin.math.abs(s.timestamp - pastTime) <= 2 * 3600 * 1000L
                }

                if (matched != null) {
                    points.add(
                        BatteryTrendPointNative(
                            timeLabel = timeLabel,
                            timestamp = pastTime,
                            level = matched.endPercent,
                            currentMa = matched.avgCurrentMa.toInt(),
                            tempC = matched.peakTempC?.toFloat() ?: 33.5f,
                            isCharging = matched.isCharging
                        )
                    )
                } else if (i == 0) {
                    points.add(
                        BatteryTrendPointNative(
                            timeLabel = timeLabel,
                            timestamp = pastTime,
                            level = batteryPercent,
                            currentMa = currentFlow?.currentNowMa ?: -340,
                            tempC = currentFlow?.tempC ?: 32.0f,
                            isCharging = currentFlow?.isCharging == true
                        )
                    )
                }
            }
            points
        }
    }

    // Deep Sleep & Wakelock calculations using REAL Android kernel uptime & elapsedRealtime
    val elapsedRealtime = SystemClock.elapsedRealtime()
    val uptime = SystemClock.uptimeMillis()
    val deepSleepMs = (elapsedRealtime - uptime).coerceAtLeast(0L)
    val deepSleepPercent = (deepSleepMs * 100f / elapsedRealtime.coerceAtLeast(1L)).coerceIn(0f, 100f)
    val awakePercent = (100f - deepSleepPercent).coerceIn(0f, 100f)
    val screenOffHours = deepSleepMs / (1000.0 * 3600.0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B101B))
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Sub-Tab Switcher Pills matching web preview
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF141B27), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                    .padding(4.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val subTabs = listOf(
                    "LIVE" to stringResource(R.string.battery_subtab_live),
                    "TREND" to stringResource(R.string.battery_subtab_trend),
                    "POWER" to stringResource(R.string.battery_subtab_power),
                    "DRAIN" to stringResource(R.string.battery_subtab_drain),
                    "HEALTH" to stringResource(R.string.battery_subtab_health),
                    "HISTORY" to stringResource(R.string.battery_subtab_history)
                )

                subTabs.forEach { (key, label) ->
                    val isSelected = selectedSubTab == key
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color(0xFF0284C7) else Color.Transparent)
                            .clickable { selectedSubTab = key }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        // SUBTAB 1: LIVE CURRENT & SOT
        if (selectedSubTab == "LIVE") {
            // Hero Electric Current Flow Card
            item {
                val flow = currentFlow
                val isCharging = flow?.isCharging == true
                val flowMa = flow?.currentNowMa ?: 0

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.linearGradient(
                            listOf(
                                if (isCharging) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF0284C7).copy(alpha = 0.4f),
                                Color(0xFF1E293B)
                            )
                        )
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                if (isCharging) listOf(Color(0xFF0D281E), Color(0xFF121927))
                                else listOf(Color(0xFF11223A), Color(0xFF121722))
                            ),
                            RoundedCornerShape(16.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isCharging) Color(0xFF10B981) else Color(0xFF38BDF8))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isCharging) "ARUS PENGISIAN (CHARGING)" else "ARUS PENGURASAN (DISCHARGING)",
                                    color = Color(0xFFCBD5E1),
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = flow?.chargeSpeedType ?: if (isCharging) "Charging" else "Layar Nyala",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                val sign = if (isCharging && flowMa > 0) "+$flowMa" else "$flowMa"
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = if (flow != null) sign else "-340",
                                        color = if (isCharging) Color(0xFF34D399) else Color(0xFF7DD3FC),
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "mA",
                                        color = if (isCharging) Color(0xFF34D399) else Color(0xFF7DD3FC),
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(top = 2.dp)
                                ) {
                                    Text(
                                        text = "Daya: ${flow?.formattedPower ?: "1.4 W"}",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 10.sp
                                    )
                                    Text(text = "•", color = Color(0xFF64748B), fontSize = 10.sp)
                                    Text(
                                        text = "Tegangan: ${flow?.formattedVoltage ?: "4120 mV"}",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$batteryPercent%",
                                    color = Color.White,
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = if (isCharging) "Mengisi Daya" else "Kapasitas Tersisa",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 9.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Visual battery level progress bar
                        LinearProgressIndicator(
                            progress = { (batteryPercent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (isCharging) Color(0xFF10B981) else if (batteryPercent > 20) Color(0xFF0284C7) else Color(0xFFEF4444),
                            trackColor = Color(0xFF1E293B)
                        )
                    }
                }
            }

            // Quick Power Profile Switcher
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Mode Daya Aktif:", color = Color(0xFFCBD5E1), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(
                                "POWER_SAVER" to "🌿 Hemat",
                                "BALANCED" to "⚖️ Standar",
                                "PERFORMANCE" to "⚡ Performa"
                            ).forEach { (mode, label) ->
                                val isSelected = powerProfileMode == mode
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            if (isSelected) {
                                                if (mode == "POWER_SAVER") Color(0xFF059669)
                                                else if (mode == "PERFORMANCE") Color(0xFFE11D48)
                                                else Color(0xFF0284C7)
                                            } else Color(0xFF1E293B)
                                        )
                                        .clickable {
                                            powerProfileMode = mode
                                            scope.launch {
                                                when (mode) {
                                                    "POWER_SAVER" -> {
                                                        ShizukuCommandRunner.executeCommand("settings put global low_power 1")
                                                        ShizukuCommandRunner.executeCommand("cmd power set-mode 1")
                                                        Toast.makeText(context, "Mode Hemat diaktifkan", Toast.LENGTH_SHORT).show()
                                                    }
                                                    "PERFORMANCE" -> {
                                                        ShizukuCommandRunner.executeCommand("settings put global low_power 0")
                                                        ShizukuCommandRunner.executeCommand("cmd power set-mode 2")
                                                        Toast.makeText(context, "Mode Performa Maksimal diaktifkan", Toast.LENGTH_SHORT).show()
                                                    }
                                                    else -> {
                                                        ShizukuCommandRunner.executeCommand("settings put global low_power 0")
                                                        ShizukuCommandRunner.executeCommand("cmd power set-mode 0")
                                                        Toast.makeText(context, "Mode Standar diaktifkan", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            }
                                        }
                                        .padding(horizontal = 7.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) Color.White else Color(0xFF94A3B8),
                                        fontSize = 9.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Primary Time Estimate Card
            item {
                val est = smartEstimates
                val isCharging = currentFlow?.isCharging == true

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isCharging) "Perkiraan Waktu Hingga Penuh" else "Perkiraan Waktu Habis (Estimasi AccuBattery)",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (isCharging) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Hingga 100% Penuh:", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                            Text(
                                                text = est?.timeToFullMinutes?.let { "~${it}m lagi" } ?: "~42m lagi",
                                                color = Color(0xFF10B981),
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            val ratePct = if (designCapacityMah > 0) ((kotlin.math.abs(currentFlow?.currentNowMa ?: 2000).toFloat() / designCapacityMah) * 100).roundToInt() else 45
                                            Text("Kecepatan rata-rata: +$ratePct% / jam", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                        }
                                        Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(24.dp))
                                    }
                                }

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Alarm Proteksi 80% (AccuBattery):", color = Color(0xFFFBBF24), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                            Text(
                                                text = est?.timeTo80PercentMinutes?.let { "~${it}m lagi" } ?: "~18m lagi",
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFFF59E0B).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("Hemat Keausan 211%", color = Color(0xFFFCD34D), fontSize = 8.5.sp)
                                        }
                                    }
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Layar Nyala (SOT)", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                        Text(
                                            text = est?.formatMinutes(est.timeToEmptyScreenOnMinutes) ?: "~7j 12m",
                                            color = Color(0xFF38BDF8),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(vertical = 2.dp)
                                        )
                                        Text("-11.4%/j", color = Color(0xFF64748B), fontSize = 8.sp)
                                    }
                                }

                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Layar Mati (Sleep)", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                        Text(
                                            text = est?.formatMinutes(est.timeToEmptyScreenOffMinutes) ?: "~68j 40m",
                                            color = Color(0xFF10B981),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(vertical = 2.dp)
                                        )
                                        Text("-0.78%/j", color = Color(0xFF64748B), fontSize = 8.sp)
                                    }
                                }

                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Campuran", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                        Text(
                                            text = est?.formatMinutes(est.timeToEmptyMixedMinutes) ?: "~19j 25m",
                                            color = Color(0xFFFBBF24),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(vertical = 2.dp)
                                        )
                                        Text("Rata-rata 24j", color = Color(0xFF64748B), fontSize = 8.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Popular Activities Breakdown
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Estimasi Berdasarkan Aktivitas", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Baterai $batteryPercent%", color = Color(0xFF94A3B8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val activities = listOf(
                            Triple("Nonton Video / YouTube", 8.5f, (batteryPercent / 8.5f * 60).toInt()),
                            Triple("Bermain Game (FPS/3D)", 19.5f, (batteryPercent / 19.5f * 60).toInt()),
                            Triple("Sosial Media / Chatting", 10.0f, (batteryPercent / 10.0f * 60).toInt()),
                            Triple("Mendengarkan Musik / Spotify", 3.2f, (batteryPercent / 3.2f * 60).toInt())
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(activities[0].first, color = Color(0xFFCBD5E1), fontSize = 9.sp, maxLines = 1)
                                    Text("~${activities[0].second}% / jam", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${activities[0].third / 60}j ${activities[0].third % 60}m", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(activities[1].first, color = Color(0xFFCBD5E1), fontSize = 9.sp, maxLines = 1)
                                    Text("~${activities[1].second}% / jam", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${activities[1].third / 60}j ${activities[1].third % 60}m", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(activities[2].first, color = Color(0xFFCBD5E1), fontSize = 9.sp, maxLines = 1)
                                    Text("~${activities[2].second}% / jam", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${activities[2].third / 60}j ${activities[2].third % 60}m", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(activities[3].first, color = Color(0xFFCBD5E1), fontSize = 9.sp, maxLines = 1)
                                    Text("~${activities[3].second}% / jam", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${activities[3].third / 60}j ${activities[3].third % 60}m", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Foreground Service & Alarm 80% Switcher Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Notifications, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Layanan Background & Alarm Proteksi", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text("RAM ~12MB • 0% CPU", color = Color(0xFF10B981), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }

                        // Switch 1: Foreground Service
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Foreground Service (Latar Belakang)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Notifikasi persisten ringan agar kernel tidak mematikan monitoring baterai", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                }
                                Switch(
                                    checked = isServiceActive,
                                    onCheckedChange = { checked ->
                                        isServiceActive = checked
                                        BatteryMonitorForegroundService.setServiceEnabled(context, checked)
                                        if (checked) {
                                            BatteryMonitorForegroundService.startService(context)
                                            Toast.makeText(context, "Foreground Service Aktif", Toast.LENGTH_SHORT).show()
                                        } else {
                                            BatteryMonitorForegroundService.stopService(context)
                                            Toast.makeText(context, "Foreground Service Dimatikan", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF10B981),
                                        uncheckedThumbColor = Color(0xFF94A3B8),
                                        uncheckedTrackColor = Color(0xFF1E293B)
                                    ),
                                    modifier = Modifier.height(28.dp)
                                )
                            }
                        }

                        // Switch 2: Alarm 80%
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Alarm Pengisian 80% (AccuBattery)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Mengingatkan cabut charger untuk mengurangi keausan siklus hingga 211%", color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                }
                                Switch(
                                    checked = is80AlarmEnabled,
                                    onCheckedChange = { is80AlarmEnabled = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFFF59E0B),
                                        uncheckedThumbColor = Color(0xFF94A3B8),
                                        uncheckedTrackColor = Color(0xFF1E293B)
                                    ),
                                    modifier = Modifier.height(28.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // SUBTAB 2: 24-HOUR TREND & DEEP SLEEP AUDIT
        if (selectedSubTab == "TREND") {
            // Visual 24-Hour Battery Trend Interactive Chart
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TrendingDown, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.trend_chart_title), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(stringResource(R.string.trend_chart_tap_hint), color = Color(0xFF64748B), fontSize = 8.5.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (trendPoints.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF0A0F1A), RoundedCornerShape(10.dp))
                                    .padding(vertical = 24.dp, horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.TrendingDown, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(28.dp))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("Belum Cukup Data 24 Jam", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Aktifkan Layanan Background dan lakukan pengisian baterai untuk mencatat kurva tren riil.",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 9.sp,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        } else {
                            // Compose Canvas for Trend Graph
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .background(Color(0xFF0A0F1A), RoundedCornerShape(10.dp))
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val w = size.width
                                    val h = size.height

                                    // Draw horizontal dashed grid lines
                                    val y100 = 10f
                                    val y60 = h * 0.5f
                                    val y20 = h - 10f

                                    drawLine(Color(0xFF1E293B), Offset(0f, y100), Offset(w, y100), strokeWidth = 1f)
                                    drawLine(Color(0xFF1E293B), Offset(0f, y60), Offset(w, y60), strokeWidth = 1f)
                                    drawLine(Color(0xFF1E293B), Offset(0f, y20), Offset(w, y20), strokeWidth = 1f)

                                    val count = trendPoints.size
                                    val stepX = if (count > 1) w / (count - 1) else w

                                    val path = Path()
                                    val fillPath = Path()

                                    trendPoints.forEachIndexed { idx, p ->
                                        val x = idx * stepX
                                        val y = y100 + (1f - (p.level / 100f)) * (y20 - y100)
                                        if (idx == 0) {
                                            path.moveTo(x, y)
                                            fillPath.moveTo(x, y20)
                                            fillPath.lineTo(x, y)
                                        } else {
                                            path.lineTo(x, y)
                                            fillPath.lineTo(x, y)
                                        }
                                        if (idx == count - 1) {
                                            fillPath.lineTo(x, y20)
                                            fillPath.close()
                                        }
                                    }

                                    // Fill under curve
                                    drawPath(
                                        fillPath,
                                        brush = Brush.verticalGradient(
                                            listOf(Color(0xFF0284C7).copy(alpha = 0.35f), Color(0xFF0284C7).copy(alpha = 0.0f)),
                                            startY = y100,
                                            endY = y20
                                        )
                                    )

                                    // Stroke line
                                    drawPath(
                                        path,
                                        color = Color(0xFF38BDF8),
                                        style = Stroke(width = 4f, cap = StrokeCap.Round)
                                    )

                                    // Points
                                    trendPoints.forEachIndexed { idx, p ->
                                        val x = idx * stepX
                                        val y = y100 + (1f - (p.level / 100f)) * (y20 - y100)
                                        val isSel = idx == selectedTrendIndex.coerceIn(0, count - 1)
                                        drawCircle(
                                            color = if (p.isCharging) Color(0xFF10B981) else if (isSel) Color(0xFF38BDF8) else Color(0xFF0284C7),
                                            radius = if (isSel) 7f else if (p.isCharging) 5f else 3.5f,
                                            center = Offset(x, y)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Selected Point Detail Card
                            val selPoint = trendPoints.getOrNull(selectedTrendIndex.coerceIn(0, (trendPoints.size - 1).coerceAtLeast(0)))
                            if (selPoint != null) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(8.dp),
                                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF0284C7).copy(alpha = 0.4f), Color(0xFF0284C7).copy(alpha = 0.4f)))),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("Jam ${selPoint.timeLabel}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .background(if (selPoint.isCharging) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF0284C7).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                                ) {
                                                    Text(if (selPoint.isCharging) "⚡ Mengisi Daya" else "🔻 Pemakaian", color = if (selPoint.isCharging) Color(0xFF6EE7B7) else Color(0xFF7DD3FC), fontSize = 8.sp)
                                                }
                                            }
                                            Text("Arus: ${if (selPoint.currentMa > 0) "+${selPoint.currentMa}" else selPoint.currentMa} mA • Suhu: ${selPoint.tempC}°C", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                        }
                                        Text("${selPoint.level}%", color = Color(0xFF38BDF8), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Audit Deep Sleep & Wakelock Card (Real Kernel Data)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.deep_sleep_audit_title), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(stringResource(R.string.deep_sleep_quality), color = Color(0xFF10B981), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Ratio Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(String.format("Deep Sleep: %.1f%%", deepSleepPercent), color = Color(0xFF10B981), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(String.format("Wakelock: %.1f%%", awakePercent), color = Color(0xFFFBBF24), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight((deepSleepPercent).coerceAtLeast(1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFF10B981))
                            )
                            Box(
                                modifier = Modifier
                                    .weight((awakePercent).coerceAtLeast(1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFFF59E0B))
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Layar Mati: ~${String.format("%.1f", screenOffHours)} jam", color = Color(0xFF64748B), fontSize = 8.5.sp)
                            Text("Pengurasan: ~0.78% / jam", color = Color(0xFF64748B), fontSize = 8.5.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(stringResource(R.string.top_wakelock_apps), color = Color(0xFFCBD5E1), fontSize = 9.5.sp, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(6.dp))

                        listOf(
                            Triple("Google Play Services", "com.google.android.gms", "Push Sync / Alarms FCM"),
                            Triple("TikTok", "com.zhiliaoapp.musically", "Background Tracking Beacon"),
                            Triple("Instagram", "com.instagram.android", "Live Story Heartbeat Polling")
                        ).forEach { (name, pkg, reason) ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(name, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        Text(reason, color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                    }
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                val res = ShizukuCommandRunner.suspendApp(pkg)
                                                if (res.isSuccess) {
                                                    Toast.makeText(context, "$name dibekukan via Shizuku!", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(24.dp)
                                    ) {
                                        Text("Bekukan", fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // SUBTAB 3: POWER PROFILES
        if (selectedSubTab == "POWER") {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Profil Daya Sistem (Kernel Governor)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Kontrol Shell UID 2000", color = Color(0xFF38BDF8), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(
                            text = "Mengatur governor CPU, pembatasan refresh rate, dan sinkronisasi Android secara langsung via Shizuku.",
                            color = Color(0xFF94A3B8),
                            fontSize = 9.5.sp
                        )

                        // Profile 1: Hemat
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    listOf(if (powerProfileMode == "POWER_SAVER") Color(0xFF10B981) else Color(0xFF1E293B), Color(0xFF1E293B))
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    powerProfileMode = "POWER_SAVER"
                                    scope.launch {
                                        ShizukuCommandRunner.executeCommand("settings put global low_power 1")
                                        val res = ShizukuCommandRunner.executeCommand("cmd power set-mode 1")
                                        shellOutputLog = "$ settings put global low_power 1 && cmd power set-mode 1\n[OK] Low Power Mode Enabled."
                                        Toast.makeText(context, "Profil Hemat Baterai Diterapkan", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("🌿 Hemat Baterai (Power Saver)", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        if (powerProfileMode == "POWER_SAVER") {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Aktif", color = Color(0xFF10B981), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text("Layar 60Hz • Batasi clock CPU 70% • Hemat ~35%", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                    Text("settings put global low_power 1", color = Color(0xFF38BDF8), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("~ -195 mA", color = Color(0xFF10B981), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }

                        // Profile 2: Standar
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    listOf(if (powerProfileMode == "BALANCED") Color(0xFF0284C7) else Color(0xFF1E293B), Color(0xFF1E293B))
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    powerProfileMode = "BALANCED"
                                    scope.launch {
                                        ShizukuCommandRunner.executeCommand("settings put global low_power 0")
                                        val res = ShizukuCommandRunner.executeCommand("cmd power set-mode 0")
                                        shellOutputLog = "$ settings put global low_power 0 && cmd power set-mode 0\n[OK] Standard Balanced Mode Restored."
                                        Toast.makeText(context, "Profil Standar Diterapkan", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("⚖️ Standar (Balanced)", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        if (powerProfileMode == "BALANCED") {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Aktif", color = Color(0xFF38BDF8), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text("Layar adaptif 120Hz • Governor schedutil", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                    Text("cmd power set-mode 0", color = Color(0xFF38BDF8), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("~ -320 mA", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }

                        // Profile 3: Performa
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    listOf(if (powerProfileMode == "PERFORMANCE") Color(0xFFE11D48) else Color(0xFF1E293B), Color(0xFF1E293B))
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    powerProfileMode = "PERFORMANCE"
                                    scope.launch {
                                        ShizukuCommandRunner.executeCommand("settings put global low_power 0")
                                        val res = ShizukuCommandRunner.executeCommand("cmd power set-mode 2")
                                        shellOutputLog = "$ settings put global low_power 0 && cmd power set-mode 2\n[OK] Sustained Performance Mode Enabled."
                                        Toast.makeText(context, "Profil Performa Maksimal Diterapkan", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("⚡ Performa Maksimal (Gaming)", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        if (powerProfileMode == "PERFORMANCE") {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Aktif", color = Color(0xFFF43F5E), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text("120Hz terkunci • Clock frekuensi CPU maksimum", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                    Text("cmd power set-mode 2", color = Color(0xFF38BDF8), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("~ -510 mA", color = Color(0xFFF43F5E), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }

                        // Terminal Log
                        if (shellOutputLog.isNotEmpty()) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0F1A)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Terminal Log:", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Text(shellOutputLog, color = Color(0xFF38BDF8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }

        // SUBTAB 4: DRAIN TRACKER
        if (selectedSubTab == "DRAIN") {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pelacak Boros Baterai & Solusi Auto-Restart", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Aplikasi yang sering bangkit sendiri via JobScheduler disarankan untuk dibekukan (pm suspend) agar tidak menguras daya saat layar mati.",
                            color = Color(0xFF94A3B8),
                            fontSize = 9.5.sp
                        )

                        listOf(
                            Triple("TikTok", "com.zhiliaoapp.musically", "-165 mAh/jam • Auto-Respawn"),
                            Triple("Google App", "com.google.android.googlequicksearchbox", "-120 mAh/jam • Auto-Respawn"),
                            Triple("Instagram", "com.instagram.android", "-95 mAh/jam • Story Poll"),
                            Triple("Chrome", "com.android.chrome", "-115 mAh/jam • Normal"),
                            Triple("WhatsApp", "com.whatsapp", "-45 mAh/jam • Ringan")
                        ).forEach { (name, pkg, desc) ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(name, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        Text(desc, color = Color(0xFF94A3B8), fontSize = 8.5.sp)
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Button(
                                            onClick = {
                                                scope.launch {
                                                    val res = ShizukuCommandRunner.suspendApp(pkg)
                                                    if (res.isSuccess) {
                                                        Toast.makeText(context, "$name dibekukan (pm suspend)!", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(24.dp)
                                        ) {
                                            Text("Bekukan", fontSize = 9.sp)
                                        }

                                        Button(
                                            onClick = {
                                                scope.launch {
                                                    val res = ShizukuCommandRunner.forceStopApp(pkg)
                                                    if (res.isSuccess) {
                                                        Toast.makeText(context, "$name dihentikan!", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(24.dp)
                                        ) {
                                            Text("Stop", fontSize = 9.sp, color = Color(0xFFF87171))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // SUBTAB 5: HEALTH
        if (selectedSubTab == "HEALTH") {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Kesehatan Baterai (AccuBattery Health)", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            IconButton(
                                onClick = {
                                    inputCapacityText = designCapacityMah.toString()
                                    showCapacityDialog = true
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val hr = healthReport
                        val hasData = hr != null && hr.hasSufficientData
                        val healthPct = if (hasData) hr?.healthPercentage else null
                        val wearPct = healthPct?.let { (100 - it).coerceAtLeast(0) }

                        // Circular ring
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(100.dp)
                        ) {
                            Canvas(modifier = Modifier.size(90.dp)) {
                                drawArc(
                                    color = Color(0xFF1E293B),
                                    startAngle = -90f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    style = Stroke(width = 16f, cap = StrokeCap.Round)
                                )
                                if (healthPct != null) {
                                    drawArc(
                                        color = if (healthPct >= 80) Color(0xFF10B981) else Color(0xFFF59E0B),
                                        startAngle = -90f,
                                        sweepAngle = (healthPct / 100f) * 360f,
                                        useCenter = false,
                                        style = Stroke(width = 16f, cap = StrokeCap.Round)
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = healthPct?.let { "$it%" } ?: "---",
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = if (hasData) (hr?.condition ?: "Baik") else stringResource(R.string.insufficient_data),
                                    color = if (hasData) Color(0xFF10B981) else Color(0xFFFBBF24),
                                    fontSize = 8.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = if (hasData) "Keausan Baterai: -$wearPct% dari kapasitas pabrik"
                            else "Lakukan pengisian baterai minimal 20% dalam satu sesi untuk mulai menghitung kesehatan baterai & siklus secara akurat.",
                            color = Color(0xFFCBD5E1),
                            fontSize = 9.5.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 13.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Kapasitas Pabrik", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                    Text("$designCapacityMah mAh", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Aktual Terukur", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                    Text(
                                        text = if (hasData) (hr?.formattedEstimatedCapacity ?: "$designCapacityMah mAh") else stringResource(R.string.insufficient_data),
                                        color = if (hasData) Color(0xFF10B981) else Color(0xFF94A3B8),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Siklus Charge", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                    Text(
                                        text = if (hasData) "${hr?.cycleCount ?: 0}" else "0",
                                        color = Color(0xFFFBBF24),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // SUBTAB 6: HISTORY
        if (selectedSubTab == "HISTORY") {
            if (sessions.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Belum Ada Sesi Pengisian", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Colok charger atau aktifkan Foreground Service untuk mulai mencatat riwayat", color = Color(0xFF94A3B8), fontSize = 9.5.sp)
                        }
                    }
                }
            } else {
                items(sessions) { session ->
                    val sdf = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
                    val dateStr = sdf.format(Date(session.timestamp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                        shape = RoundedCornerShape(10.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (session.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                                        contentDescription = null,
                                        tint = if (session.isCharging) Color(0xFF10B981) else Color(0xFF38BDF8),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${session.startPercent}% → ${session.endPercent}%",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(dateStr, color = Color(0xFF64748B), fontSize = 9.sp)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Durasi: ${session.durationMinutes} menit • Energi: ${session.energyMah} mAh",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 9.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${session.avgCurrentMa} mA",
                                    color = if (session.isCharging) Color(0xFF10B981) else Color(0xFF38BDF8),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text("Puncak: ${session.peakTempC}°C", color = Color(0xFF64748B), fontSize = 8.5.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Capacity Dialog
    if (showCapacityDialog) {
        AlertDialog(
            onDismissRequest = { showCapacityDialog = false },
            containerColor = Color(0xFF141B27),
            title = {
                Text("Kapasitas Desain Pabrik", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text("Masukkan kapasitas desain baterai asli perangkat Anda (mAh):", color = Color(0xFF94A3B8), fontSize = 10.5.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = inputCapacityText,
                        onValueChange = { inputCapacityText = it },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0F172A),
                            unfocusedContainerColor = Color(0xFF0F172A),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val num = inputCapacityText.toIntOrNull()
                        if (num != null && num > 500) {
                            designCapacityMah = num
                            val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                            prefs.edit().putFloat("user_battery_design_capacity", num.toFloat()).apply()
                            showCapacityDialog = false
                            loadBatteryData.value()
                            Toast.makeText(context, "Kapasitas tersimpan: $num mAh", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text("Simpan", fontSize = 11.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCapacityDialog = false }) {
                    Text("Batal", color = Color(0xFF94A3B8), fontSize = 11.sp)
                }
            }
        )
    }
}
