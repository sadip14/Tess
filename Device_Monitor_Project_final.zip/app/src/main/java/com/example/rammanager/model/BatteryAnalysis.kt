package com.example.rammanager.model

/**
 * Type of battery state session recorded
 */
enum class BatterySessionType(val displayName: String) {
    CHARGING("Pengisian Daya"),
    DISCHARGING("Pemakaian Baterai")
}

/**
 * Real-time electrical measurements from BatteryManager & kernel sysfs
 */
data class BatteryCurrentFlow(
    val currentNowMa: Int?,          // Null if hardware sensor is unreadable (Rule A.2)
    val currentAverageMa: Int?,
    val voltageMv: Int?,
    val powerWatts: Double?,
    val temperatureC: Double?,
    val isCharging: Boolean,
    val chargeSpeedType: String
) {
    val tempC: Float?
        get() = temperatureC?.toFloat()

    val formattedCurrent: String
        get() = currentNowMa?.let {
            if (it >= 0) "+$it mA" else "$it mA"
        } ?: "Tidak tersedia"

    val formattedPower: String
        get() = powerWatts?.let {
            String.format("%.2f W", kotlin.math.abs(it))
        } ?: "Tidak tersedia"

    val formattedVoltage: String
        get() = voltageMv?.let { "${it} mV" } ?: "Tidak tersedia"

    val formattedTemp: String
        get() = temperatureC?.let { String.format("%.1f°C", it) } ?: "Tidak tersedia"
}

/**
 * Stored historical session with real measured energy
 */
data class BatterySessionRecord(
    val id: String,
    val sessionType: BatterySessionType,
    val startTime: Long,
    val endTime: Long,
    val durationMinutes: Int,
    val startLevelPercent: Int,
    val endLevelPercent: Int,
    val energyMah: Double,           // Real measured energy via charge counter or time integration
    val avgCurrentMa: Int?,
    val peakTemperatureC: Double?,
    val chargerType: String? = null,
    val screenOnMinutes: Int? = null,
    val screenOffMinutes: Int? = null,
    val screenOnDrainPercent: Int? = null,
    val screenOffDrainPercent: Int? = null
) {
    val levelDelta: Int
        get() = kotlin.math.abs(endLevelPercent - startLevelPercent)

    val formattedEnergy: String
        get() = String.format("%.0f mAh", energyMah)

    // Alias properti yang dipakai UI
    val timestamp: Long
        get() = endTime
    val isCharging: Boolean
        get() = sessionType == BatterySessionType.CHARGING
    val startPercent: Int
        get() = startLevelPercent
    val endPercent: Int
        get() = endLevelPercent
    val peakTempC: Double?
        get() = peakTemperatureC
}

/**
 * Battery Health analysis calculated from real historical charge sessions
 */
data class BatteryHealthReport(
    val designCapacityMah: Int,
    val estimatedCapacityMah: Double?, // Null if insufficient sessions
    val healthPercent: Double?,        // Null if insufficient sessions
    val cycleCount: Int,
    val wearLevelPercent: Double?,
    val condition: String,             // "Belum cukup data", "Sangat Baik", "Baik", dll.
    val totalSessionsLearned: Int,
    val accuracyScorePercent: Int,
    val hasSufficientData: Boolean,
    val methodLabel: String = "Metode: Kernel Reader"
) {
    val healthPercentage: Int?
        get() = healthPercent?.toInt()

    val formattedHealth: String
        get() = healthPercent?.let { String.format("%.1f%%", it) } ?: "Belum cukup data"

    val formattedEstimatedCapacity: String
        get() = estimatedCapacityMah?.let { String.format("%.0f mAh", it) } ?: "Belum cukup data"
}

/**
 * Estimated time remaining for popular daily activities
 */
data class ActivityDrainEstimate(
    val id: String,
    val activityName: String,
    val category: String,
    val drainRatePercentPerHour: Double,
    val minutesRemaining: Int,
    val sourceLabel: String = "Perkiraan umum" // Explicit requirement Rule D
) {
    val formattedRemaining: String
        get() {
            val hours = minutesRemaining / 60
            val mins = minutesRemaining % 60
            return if (hours > 0) "${hours}j ${mins}m" else "${mins}m"
        }
}

/**
 * Learned drain rates computed from real screen on/off discharge sessions
 */
data class LearnedDrainInfo(
    val hasSufficientData: Boolean,
    val screenOnDrainRatePerHour: Double?,
    val screenOffDrainRatePerHour: Double?,
    val mixedDrainRatePerHour: Double?,
    val sevenDayScreenOnRatio: Double? = null,
    val totalDischargeMinutes: Int = 0
)

/**
 * Smart estimates calculated based on current battery level & drain rates
 */
data class BatterySmartEstimates(
    val timeToFullMinutes: Int?,
    val timeTo80PercentMinutes: Int?,
    val timeToEmptyScreenOnMinutes: Int?,
    val timeToEmptyScreenOffMinutes: Int?,
    val timeToEmptyMixedMinutes: Int?,
    val hasDischargeData: Boolean = false,
    val isChargingCapacityEstimated: Boolean = false,
    val screenOnDrainRatePerHour: Double? = null,
    val screenOffDrainRatePerHour: Double? = null,
    val mixedDrainRatePerHour: Double? = null,
    val activities: List<ActivityDrainEstimate> = emptyList()
) {
    fun formatMinutes(mins: Int?): String {
        if (mins == null || mins <= 0) return "--"
        val hours = mins / 60
        val remainder = mins % 60
        return if (hours > 0) "${hours}j ${remainder}m" else "${remainder}m"
    }
}
