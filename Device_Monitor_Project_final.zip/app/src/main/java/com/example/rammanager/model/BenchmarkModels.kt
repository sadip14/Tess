package com.example.rammanager.model

import java.util.Locale

enum class BenchmarkMode(val label: String) {
    FAST("Cepat (~15d)"),
    STANDARD("Standar (~60d)"),
    STRESS("Stress Test")
}

/**
 * Anchor Device Specification for Device Monitor Benchmark v1 (DMB-v1).
 * Anchor: Physical Samsung Galaxy S21 FE 5G (SM-G990E, Exynos 2100, 8GB LPDDR5, Android 14).
 * Every subscore on anchor yields exactly 10,000 points.
 * Overall Total Score on anchor = (10000 + 10000 + 10000 + 10000) / 4 = 10,000 points.
 */
object DmbV1Anchor {
    const val ID = "DMB-V1-S21FE-EXYNOS2100"
    const val DEVICE_NAME = "Galaxy S21 FE 5G (SM-G990E)"
    const val CHIPSET = "Samsung Exynos 2100"
    const val RAM_CONFIG = "8 GB LPDDR5"
    const val ANDROID_VERSION = "Android 14"
    const val BENCHMARK_VERSION = 1
    const val SCHEMA_VERSION = 1
    const val BASELINE_SCORE = 10_000

    // Physical baseline measurements on anchor device:
    const val BASE_SINGLE_TIME_MS = 210.0       // Sieve execution time in milliseconds (lower = faster)
    const val BASE_MULTI_THROUGHPUT_MOPS = 145.0 // Concurrent operations in MOps/sec (higher = faster)
    const val BASE_RAM_MB_SEC = 4250.0          // LPDDR memory throughput MB/s (higher = faster)
    const val BASE_STORAGE_MB_SEC = 850.0       // Internal storage I/O speed MB/s (higher = faster)
}

/**
 * Android Thermal Service Status from PowerManager.getCurrentThermalStatus()
 * Reports device thermal state directly from Android Thermal HAL/kernel driver.
 */
enum class AndroidThermalStatus(val code: Int, val label: String) {
    NONE(0, "Normal (Optimal)"),
    LIGHT(1, "Status Termal: Ringan"),
    MODERATE(2, "Status Termal: Sedang"),
    SEVERE(3, "Status Termal: Berat"),
    CRITICAL(4, "Status Termal: Kritis"),
    UNKNOWN(-1, "Status Termal: Standar");

    companion object {
        fun fromCode(code: Int): AndroidThermalStatus = when (code) {
            0 -> NONE
            1 -> LIGHT
            2 -> MODERATE
            3 -> SEVERE
            4 -> CRITICAL
            else -> UNKNOWN
        }
    }
}

enum class MetricType {
    TIME_MS,        // For single-core latency (ms / µs)
    THROUGHPUT_MOPS,// For multi-core compute (MOps/s)
    THROUGHPUT_MB_S // For RAM and Storage bandwidth (MB/s)
}

data class MetricVariation(
    val median: Double,
    val min: Double,
    val max: Double,
    val avg: Double,
    val metricType: MetricType = MetricType.THROUGHPUT_MB_S
) {
    val formattedMedian: String
        get() = formatValue(median)

    val formattedVariation: String
        get() = String.format(
            Locale.US,
            "min: %s | rata-rata: %s | maks: %s",
            formatValue(min),
            formatValue(avg),
            formatValue(max)
        )

    private fun formatValue(v: Double): String {
        return when (metricType) {
            MetricType.TIME_MS -> {
                if (v >= 1.0) {
                    String.format(Locale.US, "%.1f ms", v)
                } else if (v > 0.0) {
                    String.format(Locale.US, "%.0f µs", v * 1000.0)
                } else {
                    "0 ms"
                }
            }
            MetricType.THROUGHPUT_MOPS -> {
                if (v >= 1000.0) {
                    String.format(Locale.US, "%.1f GOps/s", v / 1000.0)
                } else {
                    String.format(Locale.US, "%.1f MOps/s", v)
                }
            }
            MetricType.THROUGHPUT_MB_S -> {
                if (v >= 1024.0) {
                    String.format(Locale.US, "%.2f GB/s", v / 1024.0)
                } else {
                    String.format(Locale.US, "%.1f MB/s", v)
                }
            }
        }
    }
}

data class StressDataPoint(
    val second: Int,
    val score: Int,
    val tempC: Float?
)

data class BenchmarkResultRecord(
    val id: String,
    val timestamp: Long,
    val mode: BenchmarkMode,
    val deviceModel: String,
    val totalScore: Int,
    val singleCoreScore: Int,
    val multiCoreScore: Int,
    val ramScore: Int,
    val storageScore: Int,
    val singleCoreOpsSec: MetricVariation,
    val multiCoreOpsSec: MetricVariation,
    val ramThroughputMbSec: MetricVariation,
    val storageThroughputMbSec: MetricVariation,
    val tempBeforeC: Float?,
    val tempAfterC: Float?,
    val batteryBeforePct: Int,
    val batteryAfterPct: Int,
    val thermalStatus: AndroidThermalStatus = AndroidThermalStatus.NONE,
    val isVerifiedPhysical: Boolean = false,
    val source: String = "LOCAL_DEVICE",
    val benchmarkVersion: Int = DmbV1Anchor.BENCHMARK_VERSION,
    val schemaVersion: Int = DmbV1Anchor.SCHEMA_VERSION,
    val throttlingDropPct: Float? = null,
    val stressCurve: List<StressDataPoint> = emptyList()
) {
    fun toShareText(): String {
        return buildString {
            appendLine("schema_version=$schemaVersion")
            appendLine("benchmark_version=$benchmarkVersion")
            appendLine("mode=${mode.name}")
            appendLine("total_score=$totalScore")
            appendLine("skor_single=$singleCoreScore")
            appendLine("skor_multi=$multiCoreScore")
            appendLine("ram=$ramScore")
            appendLine("storage=$storageScore")
            appendLine("thermal_status=${thermalStatus.name}")
            appendLine("suhu=${tempAfterC ?: tempBeforeC ?: 0f}")
            appendLine("model=$deviceModel")
            appendLine("source=COMMUNITY_SHARE")
        }
    }
}

data class ImportedBenchmarkComparison(
    val deviceModel: String,
    val mode: BenchmarkMode,
    val totalScore: Int,
    val singleScore: Int,
    val multiScore: Int,
    val ramScore: Int,
    val storageScore: Int,
    val tempC: Float,
    val thermalStatus: AndroidThermalStatus = AndroidThermalStatus.NONE,
    val isVerifiedPhysical: Boolean = false, // Always unverified for imported data!
    val source: String = "COMMUNITY_IMPORT",
    val benchmarkVersion: Int = DmbV1Anchor.BENCHMARK_VERSION,
    val schemaVersion: Int = DmbV1Anchor.SCHEMA_VERSION
)
