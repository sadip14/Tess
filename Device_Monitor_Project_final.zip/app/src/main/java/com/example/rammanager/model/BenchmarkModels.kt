package com.example.rammanager.model

import java.util.Locale

enum class BenchmarkMode(val label: String) {
    FAST("Tes singkat"),
    STANDARD("Standar (~60d)"),
    STRESS("Stress Test")
}

/**
 * Anchor Device Specification for Device Monitor Benchmark v1 (DMB-v1).
 * Anchor: Physical Samsung Galaxy S21 FE 5G (SM-G990E, Exynos 2100, 8GB LPDDR5, Android 14).
 * STATUS: "BELUM TERUKUR" (Provisional values, pending calibrated lab measurement).
 */
object DmbV1Anchor {
    const val ID = "DMB-V1-S21FE-EXYNOS2100"
    const val STATUS = "BELUM TERUKUR"
    const val IS_MEASURED = false
    const val DEVICE_NAME = "Galaxy S21 FE 5G (SM-G990E)"
    const val CHIPSET = "Samsung Exynos 2100"
    const val RAM_CONFIG = "8 GB LPDDR5"
    const val ANDROID_VERSION = "Android 14"
    const val BENCHMARK_VERSION = 1
    const val SCHEMA_VERSION = 1
    const val BASELINE_SCORE = 10_000

    // Physical baseline measurements on anchor device (BELUM TERUKUR / PROVISIONAL)
    const val BASE_SINGLE_TIME_MS = 210.0        // Sieve execution time in milliseconds (lower = faster)
    const val BASE_MULTI_THROUGHPUT_MOPS = 145.0  // Concurrent operations in MOps/sec (higher = faster)
    const val BASE_RAM_MB_SEC = 4250.0           // Memory copy throughput MiB/s (higher = faster)
    const val BASE_STORAGE_MB_SEC = 850.0        // Mixed file I/O throughput MiB/s (higher = faster)
}

/**
 * Android Thermal Service Status from PowerManager.getCurrentThermalStatus()
 * Reports device thermal state directly from Android Thermal HAL / Thermal Service.
 */
enum class AndroidThermalStatus(val code: Int, val label: String) {
    NONE(0, "Normal (Optimal)"),
    LIGHT(1, "Status Termal: Ringan"),
    MODERATE(2, "Status Termal: Sedang"),
    SEVERE(3, "Status Termal: Berat"),
    CRITICAL(4, "Status Termal: Kritis"),
    EMERGENCY(5, "Status Termal: Darurat"),
    SHUTDOWN(6, "Status Termal: Shutdown"),
    UNKNOWN(-1, "Status termal tidak tersedia");

    companion object {
        fun fromCode(code: Int): AndroidThermalStatus = when (code) {
            0 -> NONE
            1 -> LIGHT
            2 -> MODERATE
            3 -> SEVERE
            4 -> CRITICAL
            5 -> EMERGENCY
            6 -> SHUTDOWN
            else -> UNKNOWN
        }
    }
}

enum class MetricType {
    TIME_MS,          // For single-core latency (ms / µs)
    THROUGHPUT_MOPS,  // For multi-core compute (MOps/s, GOps/s)
    THROUGHPUT_MIB_S  // For Memory Copy & Mixed File I/O throughput (MiB/s, GiB/s)
}

data class MetricVariation(
    val median: Double,
    val min: Double,
    val max: Double,
    val avg: Double,
    val metricType: MetricType = MetricType.THROUGHPUT_MIB_S
) {
    val formattedMedian: String
        get() = formatValue(median)

    val formattedVariation: String
        get() = String.format(
            Locale.US,
            "median: %s | min: %s | rata-rata: %s | maks: %s",
            formatValue(median),
            formatValue(min),
            formatValue(avg),
            formatValue(max)
        )

    val formattedMinMaxAvg: String
        get() = String.format(
            Locale.US,
            "min: %s | rata-rata: %s | maks: %s",
            formatValue(min),
            formatValue(avg),
            formatValue(max)
        )

    private fun formatValue(v: Double): String {
        return when (metricType) {
            MetricType.TIME_MS -> {
                if (v >= 1.0) {
                    String.format(Locale.US, "%.1f ms", v)
                } else if (v > 0.0) {
                    String.format(Locale.US, "%.0f µs", v * 1000.0)
                } else {
                    "0 ms"
                }
            }
            MetricType.THROUGHPUT_MOPS -> {
                if (v >= 1000.0) {
                    String.format(Locale.US, "%.2f GOps/s", v / 1000.0)
                } else {
                    String.format(Locale.US, "%.1f MOps/s", v)
                }
            }
            MetricType.THROUGHPUT_MIB_S -> {
                if (v >= 1024.0) {
                    String.format(Locale.US, "%.2f GiB/s", v / 1024.0)
                } else {
                    String.format(Locale.US, "%.1f MiB/s", v)
                }
            }
        }
    }
}

data class StressDataPoint(
    val second: Int,
    val score: Int,
    val tempC: Float?
)

data class BenchmarkResultRecord(
    val id: String,
    val timestamp: Long,
    val mode: BenchmarkMode,
    val deviceModel: String,
    val totalScore: Int,
    val singleCoreScore: Int,
    val multiCoreScore: Int,
    val ramScore: Int,
    val storageScore: Int,
    val singleCoreOpsSec: MetricVariation,
    val multiCoreOpsSec: MetricVariation,
    val ramThroughputMbSec: MetricVariation,
    val storageThroughputMbSec: MetricVariation,
    val tempBeforeC: Float?,
    val tempAfterC: Float?,
    val batteryBeforePct: Int,
    val batteryAfterPct: Int,
    val thermalStatusBefore: AndroidThermalStatus = AndroidThermalStatus.UNKNOWN,
    val thermalStatusAfter: AndroidThermalStatus = AndroidThermalStatus.NONE,
    val thermalStatus: AndroidThermalStatus = thermalStatusAfter,
    val isVerifiedPhysical: Boolean = false,
    val source: String = "LOCAL_MEASURED",
    val benchmarkVersion: Int = DmbV1Anchor.BENCHMARK_VERSION,
    val schemaVersion: Int = DmbV1Anchor.SCHEMA_VERSION,
    val throttlingDropPct: Float? = null,
    val stressCurve: List<StressDataPoint> = emptyList(),
    val isValid: Boolean = true,
    val validationError: String? = null
) {
    fun toShareText(): String {
        return buildString {
            appendLine("schema_version=$schemaVersion")
            appendLine("benchmark_version=$benchmarkVersion")
            appendLine("mode=${mode.name}")
            appendLine("total_score=$totalScore")
            appendLine("skor_single=$singleCoreScore")
            appendLine("skor_multi=$multiCoreScore")
            appendLine("ram=$ramScore")
            appendLine("storage=$storageScore")
            appendLine("thermal_status_before=${thermalStatusBefore.name}")
            appendLine("thermal_status_after=${thermalStatusAfter.name}")
            appendLine("thermal_status=${thermalStatus.name}")
            appendLine("suhu=${tempAfterC ?: tempBeforeC ?: 0f}")
            appendLine("model=$deviceModel")
            appendLine("source=COMMUNITY_SHARE")
            appendLine("is_valid=$isValid")
        }
    }
}

data class ImportedBenchmarkComparison(
    val deviceModel: String,
    val mode: BenchmarkMode,
    val totalScore: Int,
    val singleScore: Int,
    val multiScore: Int,
    val ramScore: Int,
    val storageScore: Int,
    val tempC: Float,
    val thermalStatusBefore: AndroidThermalStatus = AndroidThermalStatus.UNKNOWN,
    val thermalStatusAfter: AndroidThermalStatus = AndroidThermalStatus.NONE,
    val thermalStatus: AndroidThermalStatus = thermalStatusAfter,
    val isVerifiedPhysical: Boolean = false, // Always unverified for community imports!
    val source: String = "COMMUNITY_IMPORT",
    val benchmarkVersion: Int = DmbV1Anchor.BENCHMARK_VERSION,
    val schemaVersion: Int = DmbV1Anchor.SCHEMA_VERSION,
    val isValid: Boolean = true
)
