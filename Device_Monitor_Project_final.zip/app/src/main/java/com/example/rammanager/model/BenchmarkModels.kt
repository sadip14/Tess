package com.example.rammanager.model

enum class BenchmarkMode(val label: String) {
    FAST("Cepat (~15d)"),
    STANDARD("Standar (~60d)"),
    STRESS("Stress Test")
}

data class MetricVariation(
    val median: Double,
    val min: Double,
    val max: Double,
    val avg: Double
) {
    val formattedMedian: String
        get() = String.format("%.1f", median)

    val formattedVariation: String
        get() = String.format("min: %.1f | rata-rata: %.1f | maks: %.1f", min, avg, max)
}

data class StressDataPoint(
    val second: Int,
    val score: Int,
    val tempC: Float?
)

data class BenchmarkResultRecord(
    val id: String,
    val timestamp: Long,
    val mode: BenchmarkMode,
    val deviceModel: String,
    val totalScore: Int,
    val singleCoreScore: Int,
    val multiCoreScore: Int,
    val ramScore: Int,
    val storageScore: Int,
    val singleCoreOpsSec: MetricVariation,
    val multiCoreOpsSec: MetricVariation,
    val ramThroughputMbSec: MetricVariation,
    val storageThroughputMbSec: MetricVariation,
    val tempBeforeC: Float?,
    val tempAfterC: Float?,
    val batteryBeforePct: Int,
    val batteryAfterPct: Int,
    val throttlingDropPct: Float? = null,
    val stressCurve: List<StressDataPoint> = emptyList()
) {
    fun toShareText(): String {
        return buildString {
            appendLine("versi_format=1")
            appendLine("mode=${mode.name}")
            appendLine("skor_single=$singleCoreScore")
            appendLine("skor_multi=$multiCoreScore")
            appendLine("ram=$ramScore")
            appendLine("storage=$storageScore")
            appendLine("suhu=${tempAfterC ?: tempBeforeC ?: 0f}")
            appendLine("model=$deviceModel")
        }
    }
}

data class ImportedBenchmarkComparison(
    val deviceModel: String,
    val mode: BenchmarkMode,
    val totalScore: Int,
    val singleScore: Int,
    val multiScore: Int,
    val ramScore: Int,
    val storageScore: Int,
    val tempC: Float
)
