package com.example.rammanager.battery

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.model.*
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

/**
 * Universal Android Battery Analytics Engine.
 * Reads real electric current flow from BatteryManager and Linux power_supply nodes.
 * Strictly adheres to real hardware readings without artificial fallbacks.
 */
class BatteryAnalyticsEngine(
    private val context: Context,
    private val historyRepository: BatteryHistoryRepository = BatteryHistoryRepository.getInstance(context)
) {
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

    suspend fun getLiveCurrentFlow(): BatteryCurrentFlow = withContext(Dispatchers.IO) {
        val batteryStatus: Intent? = try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            context.registerReceiver(null, ifilter)
        } catch (_: Throwable) {
            null
        }

        val status = try {
            batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        } catch (_: Throwable) {
            -1
        }
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val voltageMv = try {
            batteryStatus?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)?.let {
                if (it > 0) it else null
            }
        } catch (_: Throwable) {
            null
        }
        val tempRaw = try {
            batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        } catch (_: Throwable) {
            null
        }
        val temperatureC = if (tempRaw != null && tempRaw > 0) tempRaw / 10.0 else null

        // Read current in microamperes (uA) and convert to milliamperes (mA)
        var currentMicroamps = try {
            batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
        } catch (_: Throwable) {
            0
        }
        val avgCurrentMicroamps = try {
            batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE) ?: 0
        } catch (_: Throwable) {
            0
        }

        // Fallback to sysfs if BatteryManager returns 0
        if (currentMicroamps == 0) {
            currentMicroamps = readSysfsCurrentNow()
        }

        var currentMa: Int? = if (currentMicroamps != 0) currentMicroamps / 1000 else null
        val avgCurrentMa: Int? = if (avgCurrentMicroamps != 0) avgCurrentMicroamps / 1000 else null

        // Normalize direction based on charging state
        if (currentMa != null) {
            if (!isCharging && currentMa > 0) {
                currentMa = -currentMa
            } else if (isCharging && currentMa < 0) {
                currentMa = -currentMa
            }
        }

        val powerWatts = if (voltageMv != null && currentMa != null) {
            (voltageMv.toDouble() * abs(currentMa).toDouble()) / 1_000_000.0
        } else null

        val speedType = when {
            !isCharging -> "Discharging (Pemakaian Baterai)"
            powerWatts != null && powerWatts >= 20.0 -> "Fast Charging (>20W)"
            powerWatts != null && powerWatts >= 14.0 -> "Fast Charging (15W)"
            powerWatts != null && powerWatts >= 8.0 -> "Normal Charging (10W)"
            powerWatts != null -> "Standard Charging"
            else -> "Charging"
        }

        BatteryCurrentFlow(
            currentNowMa = currentMa,
            currentAverageMa = avgCurrentMa,
            voltageMv = voltageMv,
            powerWatts = powerWatts,
            temperatureC = temperatureC,
            isCharging = isCharging,
            chargeSpeedType = speedType
        )
    }

    private fun readSysfsCurrentNow(): Int {
        val paths = listOf(
            "/sys/class/power_supply/battery/current_now",
            "/sys/class/power_supply/battery/batt_current_now",
            "/sys/class/power_supply/battery/device/current_now",
            "/sys/class/power_supply/bms/current_now",
            "/sys/class/power_supply/usb/current_now"
        )
        for (path in paths) {
            try {
                val file = File(path)
                if (file.exists() && file.canRead()) {
                    val line = file.readText().trim()
                    val value = line.toIntOrNull()
                    if (value != null && value != 0) return value
                }
            } catch (_: Throwable) {}
        }
        return 0
    }

    suspend fun calculateSmartEstimates(
        currentLevelPercent: Int,
        designCapacityMah: Int,
        measuredCapacityMah: Double? = null,
        isCharging: Boolean,
        currentMa: Int?
    ): BatterySmartEstimates = withContext(Dispatchers.IO) {
        val learnedInfo = historyRepository.getLearnedDrainRates()

        val isCapacityEstimated: Boolean
        val effectiveCapacityMah: Double = if (measuredCapacityMah != null && measuredCapacityMah > 500.0) {
            isCapacityEstimated = false
            measuredCapacityMah
        } else {
            isCapacityEstimated = true
            designCapacityMah.toDouble()
        }

        val timeToFull: Int?
        val timeTo80: Int?

        if (isCharging && effectiveCapacityMah > 0) {
            // Rule 4: Jika arus tidak terbaca, tampilkan null ("Tidak tersedia"), jangan fallback 1500 mA
            if (currentMa != null && currentMa > 50) {
                val effCurrent = currentMa.toDouble()
                val percentNeeded = (100 - currentLevelPercent).coerceAtLeast(0)
                val mahNeeded = (percentNeeded / 100.0) * effectiveCapacityMah
                val saturationMultiplier = if (currentLevelPercent > 80) 1.3 else 1.08
                timeToFull = ((mahNeeded / effCurrent) * 60.0 * saturationMultiplier).toInt().coerceAtLeast(1)

                timeTo80 = if (currentLevelPercent < 80) {
                    val mahTo80 = ((80 - currentLevelPercent) / 100.0) * effectiveCapacityMah
                    ((mahTo80 / effCurrent) * 60.0).toInt().coerceAtLeast(1)
                } else null
            } else {
                timeToFull = null
                timeTo80 = null
            }
        } else {
            timeToFull = null
            timeTo80 = null
        }

        // Rule 1, 2, 3: Hitung hanya jika ada data riil, jangan pakai angka bawaan 13.5 atau 0.8
        val screenOnHours = learnedInfo.screenOnDrainRatePerHour?.takeIf { it > 0 }?.let { currentLevelPercent / it }
        val screenOnMinutes = screenOnHours?.let { (it * 60).toInt() }

        val screenOffHours = learnedInfo.screenOffDrainRatePerHour?.takeIf { it > 0 }?.let { currentLevelPercent / it }
        val screenOffMinutes = screenOffHours?.let { (it * 60).toInt() }

        val mixedHours = learnedInfo.mixedDrainRatePerHour?.takeIf { it > 0 }?.let { currentLevelPercent / it }
        val mixedMinutes = mixedHours?.let { (it * 60).toInt() }

        // General reference activities (Rule D: labeled explicitly as Perkiraan umum)
        val activities = listOf(
            ActivityDrainEstimate(
                id = "streaming",
                activityName = "Video Streaming (YouTube/Netflix)",
                category = "Media",
                drainRatePercentPerHour = 11.5,
                minutesRemaining = ((currentLevelPercent / 11.5) * 60).toInt(),
                sourceLabel = "Perkiraan umum"
            ),
            ActivityDrainEstimate(
                id = "gaming",
                activityName = "Game 3D / Beban Berat",
                category = "Game",
                drainRatePercentPerHour = 22.0,
                minutesRemaining = ((currentLevelPercent / 22.0) * 60).toInt(),
                sourceLabel = "Perkiraan umum"
            ),
            ActivityDrainEstimate(
                id = "social",
                activityName = "Sosmed & Chatting",
                category = "Social",
                drainRatePercentPerHour = 13.0,
                minutesRemaining = ((currentLevelPercent / 13.0) * 60).toInt(),
                sourceLabel = "Perkiraan umum"
            ),
            ActivityDrainEstimate(
                id = "audio",
                activityName = "Audio Layar Mati",
                category = "Audio",
                drainRatePercentPerHour = 2.8,
                minutesRemaining = ((currentLevelPercent / 2.8) * 60).toInt(),
                sourceLabel = "Perkiraan umum"
            ),
            ActivityDrainEstimate(
                id = "reading",
                activityName = "Membaca / Web Browsing",
                category = "Web",
                drainRatePercentPerHour = 8.5,
                minutesRemaining = ((currentLevelPercent / 8.5) * 60).toInt(),
                sourceLabel = "Perkiraan umum"
            )
        )

        BatterySmartEstimates(
            timeToFullMinutes = timeToFull,
            timeTo80PercentMinutes = timeTo80,
            timeToEmptyScreenOnMinutes = screenOnMinutes,
            timeToEmptyScreenOffMinutes = screenOffMinutes,
            timeToEmptyMixedMinutes = mixedMinutes,
            hasDischargeData = learnedInfo.hasSufficientData,
            isChargingCapacityEstimated = isCapacityEstimated,
            screenOnDrainRatePerHour = learnedInfo.screenOnDrainRatePerHour,
            screenOffDrainRatePerHour = learnedInfo.screenOffDrainRatePerHour,
            mixedDrainRatePerHour = learnedInfo.mixedDrainRatePerHour,
            activities = activities
        )
    }

    suspend fun getPrivilegedBatteryDump(): String = withContext(Dispatchers.IO) {
        try {
            val result = ShizukuCommandRunner.executeCommand("dumpsys battery")
            if (result.isSuccess && !result.getOrNull().isNullOrBlank()) {
                result.getOrNull() ?: ""
            } else {
                "dumpsys battery tidak tersedia (Izin Shizuku belum aktif)."
            }
        } catch (e: Exception) {
            "Gagal membaca status baterai: ${e.message}"
        }
    }
}
