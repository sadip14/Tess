package com.example.rammanager

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.CleaningHistoryRecord
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val historyRepo = remember { HistoryRepository.getInstance(context) }

    var shellCommand by remember { mutableStateOf("") }
    var shellOutput by remember { mutableStateOf("") }
    var isExecuting by remember { mutableStateOf(false) }

    var historyList by remember { mutableStateOf<List<CleaningHistoryRecord>>(emptyList()) }
    var userCapacityText by remember { mutableStateOf("") }

    fun refreshHistory() {
        scope.launch {
            historyList = historyRepo.getAllHistory()
        }
    }

    LaunchedEffect(Unit) {
        refreshHistory()
        val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
        val saved = prefs.getFloat("user_battery_design_capacity", 0f)
        if (saved > 0f) {
            userCapacityText = saved.toInt().toString()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Shizuku Interactive Terminal Section (Rule F)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.terminal_title),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (!hasShizukuPermission) {
                            TextButton(onClick = onRequestPermission) {
                                Text(
                                    stringResource(R.string.shizuku_grant_permission),
                                    color = Color(0xFF38BDF8),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick Command Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val shortcuts = listOf(
                            "dumpsys battery",
                            "dumpsys meminfo",
                            "getprop ro.product.model",
                            "top -n 1 -b"
                        )
                        shortcuts.forEach { cmd ->
                            AssistChip(
                                onClick = { shellCommand = cmd },
                                label = {
                                    Text(
                                        cmd.substringBefore(" "),
                                        fontSize = 9.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                },
                                shape = RoundedCornerShape(6.dp),
                                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF1E293B)),
                                border = null
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = shellCommand,
                            onValueChange = { shellCommand = it },
                            placeholder = {
                                Text(
                                    stringResource(R.string.shell_placeholder),
                                    color = Color(0xFF64748B),
                                    fontSize = 11.sp
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF0284C7),
                                unfocusedBorderColor = Color(0xFF1E293B)
                            )
                        )

                        Button(
                            onClick = {
                                if (shellCommand.isNotBlank()) {
                                    isExecuting = true
                                    scope.launch {
                                        val res = ShizukuCommandRunner.executeCommand(shellCommand)
                                        isExecuting = false
                                        shellOutput = if (res.isSuccess) {
                                            "$ \$shellCommand\n${res.getOrNull()}"
                                        } else {
                                            "$ \$shellCommand\n[Error] ${res.exceptionOrNull()?.message}"
                                        }
                                    }
                                }
                            },
                            enabled = !isExecuting && shellCommand.isNotBlank() && hasShizukuPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(stringResource(R.string.run_command), fontSize = 11.sp)
                        }
                    }

                    if (shellOutput.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 180.dp)
                                .background(Color(0xFF0A0E17), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = shellOutput,
                                color = Color(0xFF38BDF8),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Battery Design Capacity Setting (Rule B.3)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.battery_capacity_setting),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.battery_capacity_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = userCapacityText,
                            onValueChange = { userCapacityText = it },
                            placeholder = { Text("cth: 5000", color = Color(0xFF64748B), fontSize = 11.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF0284C7),
                                unfocusedBorderColor = Color(0xFF1E293B)
                            )
                        )

                        Button(
                            onClick = {
                                val cap = userCapacityText.toFloatOrNull()
                                if (cap != null && cap > 500f) {
                                    context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                                        .edit().putFloat("user_battery_design_capacity", cap).apply()
                                    Toast.makeText(context, "Kapasitas tersimpan: ${cap.toInt()} mAh", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Kapasitas tidak valid", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(stringResource(R.string.save), fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Action History Section (Rule F)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.history_logs_title),
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                if (historyList.isNotEmpty()) {
                    TextButton(onClick = {
                        scope.launch {
                            historyRepo.clearHistory()
                            refreshHistory()
                            Toast.makeText(context, "Riwayat dibersihkan", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Text(stringResource(R.string.clear_logs), color = Color(0xFFEF4444), fontSize = 10.sp)
                    }
                }
            }
        }

        if (historyList.isEmpty()) {
            item {
                Text(
                    stringResource(R.string.no_history_logs),
                    color = Color(0xFF64748B),
                    fontSize = 11.sp
                )
            }
        } else {
            items(historyList.take(30)) { item ->
                val df = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault())
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = item.appName,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = item.action.displayName,
                                    color = when (item.action) {
                                        CleaningAction.FORCE_STOP -> Color(0xFFEF4444)
                                        CleaningAction.SUSPEND -> Color(0xFFA855F7)
                                        CleaningAction.UNSUSPEND -> Color(0xFF38BDF8)
                                        CleaningAction.BATCH_BOOST -> Color(0xFF10B981)
                                    },
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(df.format(Date(item.timestamp)), color = Color(0xFF64748B), fontSize = 9.sp)
                        }

                        if (item.estimatedRamFreedMb > 0) {
                            Text(
                                text = "+${item.formattedRamFreed}",
                                color = Color(0xFF10B981),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
