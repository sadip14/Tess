package com.example.rammanager

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.data.BenchmarkHistoryRepository
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.CleaningHistoryRecord
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
    hasShizukuPermission: Boolean,
    pollingIntervalSec: Int = 5,
    onPollingIntervalChange: (Int) -> Unit = {},
    themeMode: String = "SYSTEM",
    onThemeModeChange: (String) -> Unit = {},
    onRequestPermission: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val historyRepo = remember { HistoryRepository.getInstance(context) }

    var crashLogText by remember { mutableStateOf<String?>(DeviceMonitorApp.readCrashLog(context)) }

    var shellCommand by remember { mutableStateOf("") }
    var shellOutput by remember { mutableStateOf("") }
    var isExecuting by remember { mutableStateOf(false) }
    var commandHistory by remember { mutableStateOf<List<String>>(emptyList()) }
    var pendingRiskyCommand by remember { mutableStateOf<String?>(null) }

    var historyList by remember { mutableStateOf<List<CleaningHistoryRecord>>(emptyList()) }
    var suspendedPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    var isRestoringAll by remember { mutableStateOf(false) }
    var restoreResults by remember { mutableStateOf<List<Pair<String, String?>>>(emptyList()) }
    var restoreStatusMessage by remember { mutableStateOf<String?>(null) }

    var userProtectedList by remember {
        mutableStateOf(ShizukuCommandRunner.getUserProtectedPackages(context).toList().sorted())
    }
    var newProtectedPkg by remember { mutableStateOf("") }

    var userCapacityText by remember { mutableStateOf("") }

    val settingsPrefs = remember {
        context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
    }
    var autoCleanEnabled by remember {
        mutableStateOf(settingsPrefs.getBoolean("auto_clean_enabled", false))
    }
    var autoCleanThreshold by remember {
        mutableStateOf(settingsPrefs.getInt("auto_clean_threshold_pct", 15))
    }
    var showAutoCleanConfirmDialog by remember { mutableStateOf(false) }

    var highTempAlertEnabled by remember {
        mutableStateOf(settingsPrefs.getBoolean("high_temp_alert_enabled", true))
    }

    var isTrimmingCaches by remember { mutableStateOf(false) }
    var trimCacheResult by remember { mutableStateOf<ShizukuCommandRunner.TrimCacheResult?>(null) }

    val exportSuccessMsg = stringResource(R.string.export_success)

    fun csvEscape(value: String): String {
        return "\"${value.replace("\"", "\"\"")}\""
    }

    val batteryCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val sessions = BatteryHistoryRepository.getInstance(context).getAllSessions()
                    val csv = buildString {
                        appendLine(
                            listOf(
                                "id", "sessionType", "startTime", "endTime", "durationMinutes",
                                "startLevelPercent", "endLevelPercent", "energyMah", "avgCurrentMa", "peakTemperatureC"
                            ).joinToString(",") { csvEscape(it) }
                        )
                        sessions.forEach { s ->
                            appendLine(
                                listOf(
                                    csvEscape(s.id),
                                    csvEscape(s.sessionType.name),
                                    s.startTime.toString(),
                                    s.endTime.toString(),
                                    s.durationMinutes.toString(),
                                    s.startLevelPercent.toString(),
                                    s.endLevelPercent.toString(),
                                    s.energyMah.toString(),
                                    (s.avgCurrentMa ?: "").toString(),
                                    (s.peakTemperatureC ?: "").toString()
                                ).joinToString(",")
                            )
                        }
                    }
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                    }
                    Toast.makeText(context, exportSuccessMsg, Toast.LENGTH_SHORT).show()
                } catch (e: Throwable) {
                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val benchmarkCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val results = BenchmarkHistoryRepository.getInstance(context).getAllResults()
                    val csv = buildString {
                        appendLine(
                            listOf(
                                "id", "timestamp", "mode", "totalScore",
                                "singleCoreScore", "multiCoreScore", "ramScore", "storageScore"
                            ).joinToString(",") { csvEscape(it) }
                        )
                        results.forEach { r ->
                            appendLine(
                                listOf(
                                    csvEscape(r.id),
                                    r.timestamp.toString(),
                                    csvEscape(r.mode.name),
                                    r.totalScore.toString(),
                                    r.singleCoreScore.toString(),
                                    r.multiCoreScore.toString(),
                                    r.ramScore.toString(),
                                    r.storageScore.toString()
                                ).joinToString(",")
                            )
                        }
                    }
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                    }
                    Toast.makeText(context, exportSuccessMsg, Toast.LENGTH_SHORT).show()
                } catch (e: Throwable) {
                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val actionsCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val actions = historyRepo.getAllHistory()
                    val csv = buildString {
                        appendLine(
                            listOf(
                                "timestamp", "action", "appName", "packageName", "estimatedRamFreedMb"
                            ).joinToString(",") { csvEscape(it) }
                        )
                        actions.forEach { a ->
                            appendLine(
                                listOf(
                                    a.timestamp.toString(),
                                    csvEscape(a.action.name),
                                    csvEscape(a.appName),
                                    csvEscape(a.packageName),
                                    a.estimatedRamFreedMb.toString()
                                ).joinToString(",")
                            )
                        }
                    }
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                    }
                    Toast.makeText(context, exportSuccessMsg, Toast.LENGTH_SHORT).show()
                } catch (e: Throwable) {
                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun refreshHistoryAndSuspended() {
        scope.launch {
            historyList = historyRepo.getAllHistory()
            if (hasShizukuPermission) {
                suspendedPackages = ShizukuCommandRunner.getSuspendedPackages(context)
            }
        }
    }

    fun isRiskyShellCommand(cmd: String): Boolean {
        val lower = cmd.trim().lowercase(Locale.ROOT)
        return Regex("""(^|\s|;|&|\|)rm(\s|$)""").containsMatchIn(lower) ||
            Regex("""(^|\s|;|&|\|)reboot(\s|$)""").containsMatchIn(lower) ||
            lower.contains("pm uninstall") ||
            lower.contains("pm clear") ||
            lower.contains("settings put")
    }

    fun runShellCommandNow(cmd: String) {
        val trimmed = cmd.trim()
        if (trimmed.isEmpty() || isExecuting) return
        isExecuting = true
        val updatedHistory = (listOf(trimmed) + commandHistory.filter { it != trimmed }).take(10)
        commandHistory = updatedHistory
        val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
        prefs.edit().putString("terminal_command_history", updatedHistory.joinToString("\n")).apply()

        scope.launch {
            val res = ShizukuCommandRunner.executeCommand(trimmed)
            shellOutput = if (res.isSuccess) {
                "$ $trimmed\n" + (res.getOrNull() ?: "(Keluaran kosong)")
            } else {
                "$ $trimmed\n[ERROR]: " + (res.exceptionOrNull()?.message ?: "Gagal")
            }
            isExecuting = false
        }
    }

    LaunchedEffect(hasShizukuPermission) {
        refreshHistoryAndSuspended()
        val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
        val saved = prefs.getFloat("user_battery_design_capacity", 0f)
        if (saved > 0f) {
            userCapacityText = saved.toInt().toString()
        }
        val savedCmds = prefs.getString("terminal_command_history", "") ?: ""
        if (savedCmds.isNotBlank()) {
            commandHistory = savedCmds.split("\n").filter { it.isNotBlank() }
        }
    }

    if (pendingRiskyCommand != null) {
        val cmdToRun = pendingRiskyCommand!!
        AlertDialog(
            onDismissRequest = { pendingRiskyCommand = null },
            containerColor = Color(0xFF141B27),
            title = {
                Text(
                    text = stringResource(R.string.risky_command_title),
                    color = Color(0xFFEF4444),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.risky_command_msg, cmdToRun),
                    color = Color(0xFFCBD5E1),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingRiskyCommand = null
                        runShellCommandNow(cmdToRun)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text(stringResource(R.string.confirm), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingRiskyCommand = null }) {
                    Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 12.sp)
                }
            }
        )
    }

    if (showAutoCleanConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showAutoCleanConfirmDialog = false },
            containerColor = Color(0xFF141B27),
            title = {
                Text(
                    text = stringResource(R.string.auto_clean_confirm_title),
                    color = Color(0xFF38BDF8),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.auto_clean_confirm_msg, autoCleanThreshold),
                    color = Color(0xFFCBD5E1),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        autoCleanEnabled = true
                        settingsPrefs.edit().putBoolean("auto_clean_enabled", true).apply()
                        showAutoCleanConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text(stringResource(R.string.confirm), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAutoCleanConfirmDialog = false }) {
                    Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 12.sp)
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B101B))
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Shizuku Interactive Terminal Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.terminal_title),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (!hasShizukuPermission) {
                            TextButton(onClick = onRequestPermission, contentPadding = PaddingValues(0.dp)) {
                                Text(
                                    stringResource(R.string.shizuku_grant_permission),
                                    color = Color(0xFF38BDF8),
                                    fontSize = 10.sp
                                )
                            }
                        } else {
                            Text("UID 2000 Shell", color = Color(0xFF10B981), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Shortcut Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val shortcuts = listOf(
                            "dumpsys battery",
                            "dumpsys meminfo",
                            "getprop ro.product.model",
                            "top -n 1 -b",
                            "pm list packages -3"
                        )
                        shortcuts.forEach { cmd ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0F172A))
                                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(6.dp))
                                    .clickable { shellCommand = cmd }
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Text(cmd, color = Color(0xFF94A3B8), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    if (commandHistory.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.command_history_title),
                            color = Color(0xFF64748B),
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            commandHistory.forEach { pastCmd ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF1E293B).copy(alpha = 0.6f))
                                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                                        .clickable { shellCommand = pastCmd }
                                        .padding(horizontal = 7.dp, vertical = 3.dp)
                                ) {
                                    Text(pastCmd, color = Color(0xFFCBD5E1), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Input Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = shellCommand,
                            onValueChange = { shellCommand = it },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp),
                            placeholder = { Text(stringResource(R.string.shell_placeholder), color = Color(0xFF64748B), fontSize = 10.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF0F172A),
                                unfocusedContainerColor = Color(0xFF0F172A),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF0284C7),
                                unfocusedBorderColor = Color(0xFF1E293B)
                            )
                        )

                        Button(
                            onClick = {
                                val trimmed = shellCommand.trim()
                                if (trimmed.isNotEmpty() && !isExecuting) {
                                    if (isRiskyShellCommand(trimmed)) {
                                        pendingRiskyCommand = trimmed
                                    } else {
                                        runShellCommandNow(trimmed)
                                    }
                                }
                            },
                            enabled = hasShizukuPermission && !isExecuting,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.heightIn(min = 44.dp)
                        ) {
                            Text(if (isExecuting) "..." else stringResource(R.string.run_command), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Console Output Box
                    if (shellOutput.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF090D16)),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Terminal Output", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                clipboard.setPrimaryClip(ClipData.newPlainText("Shell Output", shellOutput))
                                                Toast.makeText(context, "Output disalin!", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(12.dp))
                                        }
                                        IconButton(
                                            onClick = { shellOutput = "" },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = shellOutput,
                                    color = Color(0xFF38BDF8),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 12.sp,
                                    maxLines = 15
                                )
                            }
                        }
                    }
                }
            }
        }

        // 1b. Pemulihan Darurat (Pulihkan semua app yang dibekukan)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF8B5CF6).copy(alpha = 0.4f), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Restore, contentDescription = null, tint = Color(0xFFA78BFA), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.emergency_restore_title),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (suspendedPackages.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF8B5CF6).copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${suspendedPackages.size} dibekukan",
                                    color = Color(0xFFA78BFA),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.emergency_restore_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (!isRestoringAll) {
                                isRestoringAll = true
                                restoreResults = emptyList()
                                restoreStatusMessage = null
                                scope.launch {
                                    val suspendedRes = ShizukuCommandRunner.getSuspendedPackagesResult(context)
                                    if (suspendedRes.isFailure) {
                                        restoreStatusMessage = "Gagal membaca daftar aplikasi dibekukan: ${suspendedRes.exceptionOrNull()?.message ?: "Unknown error"}"
                                    } else {
                                        val currentSuspended = suspendedRes.getOrDefault(emptySet())
                                        if (currentSuspended.isEmpty()) {
                                            restoreStatusMessage = "Tidak ada aplikasi yang sedang dibekukan."
                                            suspendedPackages = emptySet()
                                        } else {
                                            val results = mutableListOf<Pair<String, String?>>()
                                            for (pkg in currentSuspended.sorted()) {
                                                val res = ShizukuCommandRunner.unsuspendApp(pkg)
                                                if (res.isSuccess) {
                                                    results.add(pkg to null)
                                                    historyRepo.recordAction(
                                                        pkg,
                                                        pkg,
                                                        CleaningAction.UNSUSPEND,
                                                        0.0
                                                    )
                                                } else {
                                                    results.add(pkg to (res.exceptionOrNull()?.message ?: "Gagal"))
                                                }
                                            }
                                            restoreResults = results
                                            refreshHistoryAndSuspended()
                                        }
                                    }
                                    isRestoringAll = false
                                }
                            }
                        },
                        enabled = hasShizukuPermission && !isRestoringAll,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 42.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRestoringAll) "..." else stringResource(R.string.restore_all_apps),
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (restoreStatusMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = restoreStatusMessage!!,
                            color = Color(0xFF94A3B8),
                            fontSize = 9.5.sp
                        )
                    }

                    if (restoreResults.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF090D16), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            restoreResults.forEach { (pkg, err) ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = pkg,
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (err == null) "Berhasil" else "Gagal: $err",
                                        color = if (err == null) Color(0xFF10B981) else Color(0xFFEF4444),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 1c. Bersihkan Cache Semua App (pm trim-caches)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.trim_caches_title),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.trim_caches_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (!isTrimmingCaches) {
                                isTrimmingCaches = true
                                scope.launch {
                                    val res = ShizukuCommandRunner.trimAllAppCaches()
                                    if (res.isSuccess) {
                                        trimCacheResult = res.getOrNull()
                                    } else {
                                        Toast.makeText(
                                            context,
                                            res.exceptionOrNull()?.message ?: "Gagal",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                    isTrimmingCaches = false
                                }
                            }
                        },
                        enabled = hasShizukuPermission && !isTrimmingCaches,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 40.dp)
                    ) {
                        Text(
                            text = if (isTrimmingCaches) "..." else stringResource(R.string.trim_caches_btn),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    trimCacheResult?.let { tr ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF090D16), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(stringResource(R.string.storage_before), color = Color(0xFF64748B), fontSize = 8.sp)
                                Text("${tr.freeBeforeMb} MB", color = Color(0xFFCBD5E1), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                            Column {
                                Text(stringResource(R.string.storage_after), color = Color(0xFF64748B), fontSize = 8.sp)
                                Text("${tr.freeAfterMb} MB", color = Color(0xFFCBD5E1), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(stringResource(R.string.storage_reclaimed), color = Color(0xFF64748B), fontSize = 8.sp)
                                Text("+${tr.reclaimedMb} MB", color = Color(0xFF10B981), fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // 2. Kapasitas Baterai Manual Override
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.battery_capacity_setting),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.battery_capacity_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = userCapacityText,
                            onValueChange = { userCapacityText = it },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp),
                            placeholder = { Text("Contoh: 4500", color = Color(0xFF64748B), fontSize = 10.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF0F172A),
                                unfocusedContainerColor = Color(0xFF0F172A),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Button(
                            onClick = {
                                val parsed = userCapacityText.toFloatOrNull()
                                if (parsed != null && parsed > 500f) {
                                    val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                                    prefs.edit().putFloat("user_battery_design_capacity", parsed).apply()
                                    Toast.makeText(context, "Kapasitas tersimpan: ${parsed.toInt()} mAh", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.heightIn(min = 44.dp)
                        ) {
                            Text(stringResource(R.string.save), fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // 3. Pengaturan Interval Refresh
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.settings_title),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.polling_interval_label),
                        color = Color(0xFFCBD5E1),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = stringResource(R.string.polling_interval_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(5, 10, 15, 30).forEach { sec ->
                            val isSelected = pollingIntervalSec == sec
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) Color(0xFF0284C7) else Color(0xFF0F172A))
                                    .border(
                                        1.dp,
                                        if (isSelected) Color(0xFF38BDF8) else Color(0xFF1E293B),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                                        prefs.edit().putInt("polling_interval_seconds", sec).apply()
                                        onPollingIntervalChange(sec)
                                    }
                                    .padding(vertical = 7.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                    Text(
                                    text = stringResource(R.string.seconds_short, sec),
                                    color = if (isSelected) Color.White else Color(0xFF94A3B8),
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Bahasa Aplikasi (Ikuti Sistem / Indonesia / English)
                    var selectedLang by remember {
                        mutableStateOf(settingsPrefs.getString("app_language", "SYSTEM") ?: "SYSTEM")
                    }
                    Text(
                        text = stringResource(R.string.language_setting_label),
                        color = Color(0xFFCBD5E1),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val langOptions = listOf(
                            "SYSTEM" to stringResource(R.string.language_system),
                            "id" to stringResource(R.string.language_id),
                            "en" to stringResource(R.string.language_en)
                        )
                        langOptions.forEach { (langKey, langLabel) ->
                            val isSel = selectedLang == langKey
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) Color(0xFF0284C7) else Color(0xFF0F172A))
                                    .border(
                                        1.dp,
                                        if (isSel) Color(0xFF38BDF8) else Color(0xFF1E293B),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        if (selectedLang != langKey) {
                                            selectedLang = langKey
                                            settingsPrefs.edit().putString("app_language", langKey).apply()
                                            (context as? Activity)?.recreate()
                                        }
                                    }
                                    .padding(horizontal = 4.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = langLabel,
                                    color = if (isSel) Color.White else Color(0xFF94A3B8),
                                    fontSize = 9.5.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Auto-Clean RAM (Default OFF, wajib konfirmasi saat diaktifkan)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.auto_clean_title),
                                color = Color(0xFFCBD5E1),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = stringResource(R.string.auto_clean_desc),
                                color = Color(0xFF94A3B8),
                                fontSize = 8.5.sp,
                                lineHeight = 11.5.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Switch(
                            checked = autoCleanEnabled,
                            onCheckedChange = { checked ->
                                if (checked) {
                                    showAutoCleanConfirmDialog = true
                                } else {
                                    autoCleanEnabled = false
                                    settingsPrefs.edit().putBoolean("auto_clean_enabled", false).apply()
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF0284C7)
                            )
                        )
                    }

                    if (autoCleanEnabled) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.auto_clean_threshold),
                            color = Color(0xFF94A3B8),
                            fontSize = 9.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(10, 15, 20, 25).forEach { pct ->
                                val isSel = autoCleanThreshold == pct
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSel) Color(0xFF0284C7) else Color(0xFF0F172A))
                                        .border(
                                            1.dp,
                                            if (isSel) Color(0xFF38BDF8) else Color(0xFF1E293B),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            autoCleanThreshold = pct
                                            settingsPrefs.edit().putInt("auto_clean_threshold_pct", pct).apply()
                                        }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$pct%",
                                        color = if (isSel) Color.White else Color(0xFF94A3B8),
                                        fontSize = 10.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Notifikasi Suhu Baterai Tinggi (>42°C)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.high_temp_alert_title),
                                color = Color(0xFFCBD5E1),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = stringResource(R.string.high_temp_alert_desc),
                                color = Color(0xFF94A3B8),
                                fontSize = 8.5.sp,
                                lineHeight = 11.5.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Switch(
                            checked = highTempAlertEnabled,
                            onCheckedChange = { checked ->
                                highTempAlertEnabled = checked
                                settingsPrefs.edit().putBoolean("high_temp_alert_enabled", checked).apply()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF0284C7)
                            )
                        )
                    }
                }
            }
        }

        // 3a. Ekspor Riwayat ke CSV (Storage Access Framework)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.export_csv_title),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.export_csv_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { batteryCsvLauncher.launch("battery_history.csv") },
                            border = BorderStroke(1.dp, Color(0xFF334155)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 38.dp)
                        ) {
                            Text(stringResource(R.string.export_battery_csv), color = Color(0xFF38BDF8), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { benchmarkCsvLauncher.launch("benchmark_history.csv") },
                            border = BorderStroke(1.dp, Color(0xFF334155)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 38.dp)
                        ) {
                            Text(stringResource(R.string.export_benchmark_csv), color = Color(0xFF38BDF8), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { actionsCsvLauncher.launch("action_history.csv") },
                            border = BorderStroke(1.dp, Color(0xFF334155)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 38.dp)
                        ) {
                            Text(stringResource(R.string.export_actions_csv), color = Color(0xFF38BDF8), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 3b. Editor Daftar Aplikasi Dilindungi
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.protected_list_title),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.protected_list_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newProtectedPkg,
                            onValueChange = { newProtectedPkg = it },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp),
                            placeholder = { Text(stringResource(R.string.add_package_hint), color = Color(0xFF64748B), fontSize = 10.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF0F172A),
                                unfocusedContainerColor = Color(0xFF0F172A),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF0284C7),
                                unfocusedBorderColor = Color(0xFF1E293B)
                            )
                        )

                        Button(
                            onClick = {
                                val pkg = newProtectedPkg.trim()
                                if (pkg.isNotEmpty()) {
                                    ShizukuCommandRunner.addUserProtectedPackage(context, pkg)
                                    userProtectedList = ShizukuCommandRunner.getUserProtectedPackages(context).toList().sorted()
                                    newProtectedPkg = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(44.dp)
                        ) {
                            Text(stringResource(R.string.add), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (userProtectedList.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            userProtectedList.forEach { pkg ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = pkg,
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 9.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = {
                                            ShizukuCommandRunner.removeUserProtectedPackage(context, pkg)
                                            userProtectedList = ShizukuCommandRunner.getUserProtectedPackages(context).toList().sorted()
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = null,
                                            tint = Color(0xFFEF4444),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Laporan Error (Crash Log)
        item {
            val copiedMsg = stringResource(R.string.copied_to_clipboard)
            val deletedMsg = stringResource(R.string.error_report_deleted)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BugReport, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.error_report_title),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.error_report_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val logContent = crashLogText
                    if (logContent.isNullOrBlank()) {
                        Text(
                            text = stringResource(R.string.no_error_report),
                            color = Color(0xFF64748B),
                            fontSize = 9.5.sp,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 160.dp)
                                .background(Color(0xFF090D16), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = logContent,
                                color = Color(0xFFFCA5A5),
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 11.5.sp,
                                maxLines = 14
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (!logContent.isNullOrBlank()) {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    clipboard?.setPrimaryClip(ClipData.newPlainText("Crash Log", logContent))
                                    Toast.makeText(context, copiedMsg, Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = !logContent.isNullOrBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 38.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.copy), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                DeviceMonitorApp.clearCrashLog(context)
                                crashLogText = null
                                Toast.makeText(context, deletedMsg, Toast.LENGTH_SHORT).show()
                            },
                            enabled = !logContent.isNullOrBlank(),
                            border = BorderStroke(1.dp, if (!logContent.isNullOrBlank()) Color(0xFFEF4444).copy(alpha = 0.5f) else Color(0xFF1E293B)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 38.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = null,
                                tint = if (!logContent.isNullOrBlank()) Color(0xFFEF4444) else Color(0xFF64748B),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                stringResource(R.string.delete),
                                color = if (!logContent.isNullOrBlank()) Color(0xFFEF4444) else Color(0xFF64748B),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 5. Action History
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.history_logs_title),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (historyList.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    scope.launch {
                                        historyRepo.clearAllHistory()
                                        refreshHistoryAndSuspended()
                                        Toast.makeText(context, "Riwayat dihapus", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(stringResource(R.string.clear_logs), color = Color(0xFFEF4444), fontSize = 9.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (historyList.isEmpty()) {
                        Text(
                            text = stringResource(R.string.no_history_logs),
                            color = Color(0xFF64748B),
                            fontSize = 9.5.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            historyList.take(15).forEach { rec ->
                                val df = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
                                val isCurrentlySuspended = rec.action == CleaningAction.SUSPEND && suspendedPackages.contains(rec.packageName)
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                val badgeColor = when (rec.action) {
                                                    CleaningAction.FORCE_STOP -> Color(0xFFEF4444)
                                                    CleaningAction.SUSPEND -> Color(0xFF8B5CF6)
                                                    CleaningAction.UNSUSPEND -> Color(0xFF0284C7)
                                                    CleaningAction.BATCH_BOOST -> Color(0xFF10B981)
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .background(badgeColor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                                ) {
                                                    Text(rec.action.name, color = badgeColor, fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(rec.appName, color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                            }
                                            Text(df.format(Date(rec.timestamp)), color = Color(0xFF64748B), fontSize = 8.sp)
                                        }

                                        if (isCurrentlySuspended) {
                                            TextButton(
                                                onClick = {
                                                    scope.launch {
                                                        val res = ShizukuCommandRunner.unsuspendApp(rec.packageName)
                                                        if (res.isSuccess) {
                                                            historyRepo.recordAction(
                                                                rec.packageName,
                                                                rec.appName,
                                                                CleaningAction.UNSUSPEND,
                                                                0.0
                                                            )
                                                            refreshHistoryAndSuspended()
                                                        } else {
                                                            Toast.makeText(
                                                                context,
                                                                res.exceptionOrNull()?.message ?: "Gagal",
                                                                Toast.LENGTH_SHORT
                                                            ).show()
                                                        }
                                                    }
                                                },
                                                enabled = hasShizukuPermission,
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                modifier = Modifier.heightIn(min = 28.dp)
                                            ) {
                                                Text(
                                                    text = stringResource(R.string.resume),
                                                    color = Color(0xFF38BDF8),
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        } else if (rec.estimatedRamFreedMb > 0) {
                                            Text(
                                                text = "+${rec.estimatedRamFreedMb.toInt()} MB",
                                                color = Color(0xFF38BDF8),
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
