package com.example.rammanager

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.CleaningHistoryRecord
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val historyRepo = remember { HistoryRepository.getInstance(context) }

    var shellCommand by remember { mutableStateOf("") }
    var shellOutput by remember { mutableStateOf("") }
    var isExecuting by remember { mutableStateOf(false) }

    var historyList by remember { mutableStateOf<List<CleaningHistoryRecord>>(emptyList()) }
    var userCapacityText by remember { mutableStateOf("") }

    fun refreshHistory() {
        scope.launch {
            historyList = historyRepo.getAllHistory()
        }
    }

    LaunchedEffect(Unit) {
        refreshHistory()
        val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
        val saved = prefs.getFloat("user_battery_design_capacity", 0f)
        if (saved > 0f) {
            userCapacityText = saved.toInt().toString()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B101B))
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Shizuku Interactive Terminal Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.terminal_title),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (!hasShizukuPermission) {
                            TextButton(onClick = onRequestPermission, contentPadding = PaddingValues(0.dp)) {
                                Text(
                                    stringResource(R.string.shizuku_grant_permission),
                                    color = Color(0xFF38BDF8),
                                    fontSize = 10.sp
                                )
                            }
                        } else {
                            Text("UID 2000 Shell", color = Color(0xFF10B981), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Shortcut Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val shortcuts = listOf(
                            "dumpsys battery",
                            "dumpsys meminfo",
                            "getprop ro.product.model",
                            "top -n 1 -b",
                            "pm list packages -3"
                        )
                        shortcuts.forEach { cmd ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0F172A))
                                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(6.dp))
                                    .clickable { shellCommand = cmd }
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Text(cmd, color = Color(0xFF94A3B8), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Input Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = shellCommand,
                            onValueChange = { shellCommand = it },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            placeholder = { Text(stringResource(R.string.shell_placeholder), color = Color(0xFF64748B), fontSize = 10.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF0F172A),
                                unfocusedContainerColor = Color(0xFF0F172A),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF0284C7),
                                unfocusedBorderColor = Color(0xFF1E293B)
                            )
                        )

                        Button(
                            onClick = {
                                if (shellCommand.isNotBlank() && !isExecuting) {
                                    isExecuting = true
                                    scope.launch {
                                        val res = ShizukuCommandRunner.executeCommand(shellCommand.trim())
                                        shellOutput = if (res.isSuccess) {
                                            "$ $shellCommand\n" + (res.getOrNull() ?: "(Keluaran kosong)")
                                        } else {
                                            "$ $shellCommand\n[ERROR]: " + (res.exceptionOrNull()?.message ?: "Gagal")
                                        }
                                        isExecuting = false
                                    }
                                }
                            },
                            enabled = hasShizukuPermission && !isExecuting,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.height(44.dp)
                        ) {
                            Text(if (isExecuting) "..." else stringResource(R.string.run_command), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Console Output Box
                    if (shellOutput.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF090D16)),
                            shape = RoundedCornerShape(8.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Terminal Output", color = Color(0xFF64748B), fontSize = 8.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                clipboard.setPrimaryClip(ClipData.newPlainText("Shell Output", shellOutput))
                                                Toast.makeText(context, "Output disalin!", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(12.dp))
                                        }
                                        IconButton(
                                            onClick = { shellOutput = "" },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = shellOutput,
                                    color = Color(0xFF38BDF8),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 12.sp,
                                    maxLines = 15
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Kapasitas Baterai Manual Override
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.battery_capacity_setting),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.battery_capacity_desc),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = userCapacityText,
                            onValueChange = { userCapacityText = it },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            placeholder = { Text("Contoh: 4500", color = Color(0xFF64748B), fontSize = 10.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF0F172A),
                                unfocusedContainerColor = Color(0xFF0F172A),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Button(
                            onClick = {
                                val parsed = userCapacityText.toFloatOrNull()
                                if (parsed != null && parsed > 500f) {
                                    val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                                    prefs.edit().putFloat("user_battery_design_capacity", parsed).apply()
                                    Toast.makeText(context, "Kapasitas tersimpan: ${parsed.toInt()} mAh", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(44.dp)
                        ) {
                            Text(stringResource(R.string.save), fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // 3. Action History
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.history_logs_title),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (historyList.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    scope.launch {
                                        historyRepo.clearAllHistory()
                                        refreshHistory()
                                        Toast.makeText(context, "Riwayat dihapus", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(stringResource(R.string.clear_logs), color = Color(0xFFEF4444), fontSize = 9.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (historyList.isEmpty()) {
                        Text(
                            text = stringResource(R.string.no_history_logs),
                            color = Color(0xFF64748B),
                            fontSize = 9.5.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            historyList.take(15).forEach { rec ->
                                val df = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                val badgeColor = when (rec.action) {
                                                    CleaningAction.FORCE_STOP -> Color(0xFFEF4444)
                                                    CleaningAction.SUSPEND -> Color(0xFF8B5CF6)
                                                    CleaningAction.UNSUSPEND -> Color(0xFF0284C7)
                                                    CleaningAction.BATCH_BOOST -> Color(0xFF10B981)
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .background(badgeColor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                                ) {
                                                    Text(rec.action.name, color = badgeColor, fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(rec.appName, color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                            }
                                            Text(df.format(Date(rec.timestamp)), color = Color(0xFF64748B), fontSize = 8.sp)
                                        }

                                        if (rec.estimatedRamFreedMb > 0) {
                                            Text(
                                                text = "+${rec.estimatedRamFreedMb.toInt()} MB",
                                                color = Color(0xFF38BDF8),
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
