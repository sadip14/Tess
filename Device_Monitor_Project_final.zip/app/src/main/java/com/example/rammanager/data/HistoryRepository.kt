package com.example.rammanager.data

import android.content.Context
import android.content.SharedPreferences
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.CleaningHistoryRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class HistoryRepository private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "device_monitor_cleaning_history"
        private const val KEY_HISTORY = "key_cleaning_history"
        private const val MAX_ITEMS = 200

        @Volatile
        private var instance: HistoryRepository? = null

        fun getInstance(context: Context): HistoryRepository {
            return instance ?: synchronized(this) {
                instance ?: HistoryRepository(context).also { instance = it }
            }
        }
    }

    suspend fun recordAction(
        packageName: String,
        appName: String,
        action: CleaningAction,
        estimatedRamFreedMb: Double
    ) = withContext(Dispatchers.IO) {
        val list = readAll().toMutableList()
        list.add(
            0,
            CleaningHistoryRecord(
                packageName = packageName,
                appName = appName,
                action = action,
                estimatedRamFreedMb = estimatedRamFreedMb,
                timestamp = System.currentTimeMillis()
            )
        )
        if (list.size > MAX_ITEMS) {
            list.subList(MAX_ITEMS, list.size).clear()
        }
        writeAll(list)
    }

    suspend fun getAllHistory(): List<CleaningHistoryRecord> = withContext(Dispatchers.IO) {
        readAll()
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY_HISTORY).apply()
    }

    private fun readAll(): List<CleaningHistoryRecord> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<CleaningHistoryRecord>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val action = try {
                    CleaningAction.valueOf(o.optString("action", CleaningAction.FORCE_STOP.name))
                } catch (_: IllegalArgumentException) {
                    CleaningAction.FORCE_STOP
                }
                out.add(
                    CleaningHistoryRecord(
                        packageName = o.optString("packageName"),
                        appName = o.optString("appName"),
                        action = action,
                        estimatedRamFreedMb = o.optDouble("freedMb", 0.0),
                        timestamp = o.optLong("timestamp", 0L)
                    )
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeAll(list: List<CleaningHistoryRecord>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("packageName", it.packageName)
                    .put("appName", it.appName)
                    .put("action", it.action.name)
                    .put("freedMb", it.estimatedRamFreedMb)
                    .put("timestamp", it.timestamp)
            )
        }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }
}
