package com.example.rammanager.shizuku

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.RamOverview
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.Locale

object ShizukuCommandRunner {

    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001
    private val validPackageRegex = Regex("""^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$""")

    fun isValidPackageName(packageName: String): Boolean = validPackageRegex.matches(packageName)

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
    }

    fun hasPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            if (Shizuku.isPreV11()) {
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (_: Throwable) {
            false
        }
    }

    fun requestPermission() {
        if (isShizukuAvailable()) {
            try {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            } catch (_: Throwable) {}
        }
    }

    private fun createShizukuProcess(command: String): Process {
        val cmdArray = arrayOf("sh", "-c", "($command) 2>&1")
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            method.invoke(null, cmdArray, null, null) as Process
        } catch (_: NoSuchMethodException) {
            val fallbackMethod = Shizuku::class.java.methods.firstOrNull { it.name == "newProcess" }
                ?: throw IllegalStateException("Shizuku newProcess method not found")
            fallbackMethod.isAccessible = true
            if (fallbackMethod.parameterTypes.size == 3) {
                fallbackMethod.invoke(null, cmdArray, null, null) as Process
            } else {
                fallbackMethod.invoke(null, cmdArray) as Process
            }
        }
    }

    suspend fun executeCommand(command: String, timeoutMs: Long = 15_000L): Result<String> = withContext(Dispatchers.IO) {
        if (!isShizukuAvailable()) {
            return@withContext Result.failure(IllegalStateException("Shizuku binder is not available."))
        }
        if (!hasPermission()) {
            return@withContext Result.failure(SecurityException("Shizuku permission not granted."))
        }

        var process: Process? = null
        val watchdog = CoroutineScope(Dispatchers.IO).launch {
            delay(timeoutMs)
            try {
                process?.destroyForcibly()
            } catch (_: Throwable) {}
        }
        try {
            withTimeout(timeoutMs) {
                process = createShizukuProcess(command)
                val reader = BufferedReader(InputStreamReader(process!!.inputStream))
                val output = StringBuilder()

                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    output.appendLine(line)
                }

                process!!.waitFor()
                val exitCode = process!!.exitValue()

                if (exitCode == 0) {
                    Result.success(output.toString())
                } else {
                    val errStr = output.toString().trim()
                    Result.failure(RuntimeException(if (errStr.isNotEmpty()) errStr else "Exit code: $exitCode"))
                }
            }
        } catch (e: Throwable) {
            Result.failure(e)
        } finally {
            watchdog.cancel()
            try {
                process?.destroyForcibly()
            } catch (_: Throwable) {}
        }
    }

    fun isSystemPackage(context: Context, packageName: String): Boolean {
        return try {
            val appInfo = context.packageManager.getApplicationInfo(packageName, 0)
            (appInfo.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
        } catch (_: Throwable) {
            false
        }
    }

    fun isSafeQuickCleanCategory(oomCategory: String): Boolean {
        val lower = oomCategory.trim().lowercase(Locale.ROOT)
        if (lower.isEmpty()) return false
        if (lower.contains("foreground") ||
            lower.contains("visible") ||
            lower.contains("perceptible") ||
            lower.contains("persistent") ||
            lower.contains("previous") ||
            lower.contains("home") ||
            lower.contains("heavy") ||
            lower.contains("backup") ||
            lower.contains("service")
        ) {
            return false
        }
        return lower == "cached" || lower == "empty" || lower == "cached empty" || lower.startsWith("cached ")
    }

    suspend fun forceStopApp(context: Context, packageName: String): Result<String> {
        if (!isValidPackageName(packageName)) {
            return Result.failure(IllegalArgumentException("Invalid package name"))
        }
        if (getProtectedPackages(context).contains(packageName)) {
            return Result.failure(SecurityException("Protected app cannot be stopped"))
        }
        if (isSystemPackage(context, packageName)) {
            return Result.failure(SecurityException("System app cannot be force-stopped"))
        }
        return executeCommand("am force-stop $packageName")
    }

    suspend fun suspendApp(context: Context, packageName: String): Result<String> {
        if (!isValidPackageName(packageName)) {
            return Result.failure(IllegalArgumentException("Invalid package name"))
        }
        if (getProtectedPackages(context).contains(packageName)) {
            return Result.failure(SecurityException("Protected app cannot be suspended"))
        }
        return executeCommand("pm suspend $packageName")
    }

    suspend fun unsuspendApp(packageName: String): Result<String> {
        if (!isValidPackageName(packageName)) {
            return Result.failure(IllegalArgumentException("Invalid package name"))
        }
        return executeCommand("pm unsuspend $packageName")
    }

    data class ProcessHeapInfo(
        val nativeMb: Int?,
        val dalvikMb: Int?,
        val graphicsMb: Int?,
        val privateDirtyMb: Int?
    )

    suspend fun fetchProcessHeapInfo(packageName: String): ProcessHeapInfo? = withContext(Dispatchers.IO) {
        if (!hasPermission() || !isValidPackageName(packageName)) return@withContext null
        val res = executeCommand("dumpsys meminfo $packageName", timeoutMs = 8_000L)
        val raw = res.getOrNull() ?: return@withContext null
        var nativeKb: Long? = null
        var dalvikKb: Long? = null
        var graphicsKb = 0L
        var hasGraphics = false
        var privateDirtyKb: Long? = null

        for (line in raw.lines()) {
            val trimmed = line.trim()
            when {
                trimmed.startsWith("Native Heap ") -> {
                    val nums = Regex("""\d+""").findAll(trimmed).mapNotNull { it.value.toLongOrNull() }.toList()
                    if (nums.isNotEmpty()) nativeKb = nums[0]
                }
                trimmed.startsWith("Dalvik Heap ") -> {
                    val nums = Regex("""\d+""").findAll(trimmed).mapNotNull { it.value.toLongOrNull() }.toList()
                    if (nums.isNotEmpty()) dalvikKb = nums[0]
                }
                trimmed.startsWith("GL mtrack ") || trimmed.startsWith("EGL mtrack ") -> {
                    val nums = Regex("""\d+""").findAll(trimmed).mapNotNull { it.value.toLongOrNull() }.toList()
                    if (nums.isNotEmpty()) {
                        graphicsKb += nums[0]
                        hasGraphics = true
                    }
                }
                trimmed.startsWith("TOTAL ") && !trimmed.startsWith("TOTAL PSS:") && !trimmed.startsWith("TOTAL SWAP") -> {
                    val nums = Regex("""\d+""").findAll(trimmed).mapNotNull { it.value.toLongOrNull() }.toList()
                    if (nums.size >= 2) privateDirtyKb = nums[1]
                }
            }
        }

        if (nativeKb == null && dalvikKb == null && !hasGraphics && privateDirtyKb == null) {
            null
        } else {
            ProcessHeapInfo(
                nativeMb = nativeKb?.let { (it / 1024L).toInt() },
                dalvikMb = dalvikKb?.let { (it / 1024L).toInt() },
                graphicsMb = if (hasGraphics) (graphicsKb / 1024L).toInt() else null,
                privateDirtyMb = privateDirtyKb?.let { (it / 1024L).toInt() }
            )
        }
    }

    data class QuickCleanResult(
        val stoppedCount: Int,
        val freedMb: Long
    )

    data class TrimCacheResult(
        val freeBeforeMb: Long,
        val freeAfterMb: Long,
        val reclaimedMb: Long
    )

    suspend fun runQuickClean(context: Context): QuickCleanResult = withContext(Dispatchers.IO) {
        if (!hasPermission()) return@withContext QuickCleanResult(0, 0L)
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memBefore = ActivityManager.MemoryInfo()
        try {
            am?.getMemoryInfo(memBefore)
        } catch (_: Throwable) {}

        val (_, processes) = fetchMemoryInfo(context)
        val targets = processes.filter {
            !it.isProtected &&
                !it.isSystemApp &&
                !it.isSuspended &&
                it.packageName != context.packageName &&
                isSafeQuickCleanCategory(it.oomCategory)
        }

        var stopped = 0
        for (proc in targets) {
            val res = forceStopApp(context, proc.packageName)
            if (res.isSuccess) {
                stopped++
            }
        }

        if (stopped > 0) {
            delay(2000L)
        }

        val memAfter = ActivityManager.MemoryInfo()
        try {
            am?.getMemoryInfo(memAfter)
        } catch (_: Throwable) {}

        val freedMb = ((memAfter.availMem - memBefore.availMem) / (1024L * 1024L)).coerceAtLeast(0L)

        if (stopped > 0) {
            try {
                HistoryRepository.getInstance(context).recordAction(
                    "batch.clean",
                    "Quick Clean ($stopped apps)",
                    CleaningAction.BATCH_BOOST,
                    freedMb.toDouble()
                )
            } catch (_: Throwable) {}
        }

        QuickCleanResult(stopped, freedMb)
    }

    suspend fun trimAllAppCaches(): Result<TrimCacheResult> = withContext(Dispatchers.IO) {
        if (!hasPermission()) {
            return@withContext Result.failure(SecurityException("Shizuku permission not granted."))
        }
        val beforeBytes = try {
            StatFs(Environment.getDataDirectory().path).availableBytes
        } catch (_: Throwable) {
            0L
        }

        val res = executeCommand("pm trim-caches 999999999999999999")
        if (res.isFailure) {
            return@withContext Result.failure(res.exceptionOrNull() ?: RuntimeException("pm trim-caches failed"))
        }

        val afterBytes = try {
            StatFs(Environment.getDataDirectory().path).availableBytes
        } catch (_: Throwable) {
            beforeBytes
        }

        val beforeMb = beforeBytes / (1024L * 1024L)
        val afterMb = afterBytes / (1024L * 1024L)
        val reclaimedMb = (afterMb - beforeMb).coerceAtLeast(0L)
        Result.success(TrimCacheResult(beforeMb, afterMb, reclaimedMb))
    }

    suspend fun getMarketName(context: Context): String = withContext(Dispatchers.IO) {
        if (hasPermission()) {
            try {
                val propRes = executeCommand("getprop ro.product.marketname")
                val propVal = propRes.getOrNull()?.trim()
                if (!propVal.isNullOrBlank()) {
                    return@withContext propVal
                }
            } catch (_: Throwable) {}
        }
        try {
            val globalName = Settings.Global.getString(context.contentResolver, "device_name")?.trim()
            if (!globalName.isNullOrBlank()) {
                return@withContext globalName
            }
        } catch (_: Throwable) {}
        Build.MODEL
    }

    suspend fun setPowerProfile(mode: String): Result<String> {
        val (cmd, expectedLowPower) = when (mode.uppercase()) {
            "POWER_SAVER" -> ("settings put global low_power 1 && cmd power set-mode 1" to "1")
            "PERFORMANCE" -> ("settings put global low_power 0 && cmd power set-mode 2" to "0")
            else -> ("settings put global low_power 0 && cmd power set-mode 0" to "0")
        }
        val execRes = executeCommand(cmd)
        if (!execRes.isSuccess) {
            return execRes
        }
        // Baca ulang setting setelah dijalankan untuk memastikan
        val verifyRes = executeCommand("settings get global low_power")
        val currentLowPower = verifyRes.getOrNull()?.trim()
        return if (currentLowPower == expectedLowPower) {
            Result.success("Mode $mode berhasil diverifikasi aktif (low_power=$currentLowPower)")
        } else {
            Result.failure(Exception("Gagal verifikasi mode: low_power terbaca '$currentLowPower', diharapkan '$expectedLowPower'"))
        }
    }


    fun getBuiltInProtectedReason(context: Context, packageName: String): String? {
        when (packageName) {
            "com.google.android.gms" -> return "Layanan Google Play (Wajib untuk login & layanan sistem)"
            "com.google.android.googlequicksearchbox" -> return "Google App (Komponen pencarian & asisten sistem)"
            "com.android.vending" -> return "Google Play Store (Toko aplikasi & lisensi)"
            "com.google.android.gsf" -> return "Google Services Framework (Komponen login & akun Google)"
            "com.android.systemui" -> return "System UI (Antarmuka utama sistem Android)"
            "android" -> return "Sistem Android (Framework inti)"
            "moe.shizuku.privileged.api", "rikka.shizuku" -> return "Layanan Shizuku (Diperlukan untuk akses shell)"
            context.packageName -> return "Aplikasi ini sendiri (Device Monitor)"
        }

        val pm = context.packageManager
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            @Suppress("DEPRECATION")
            val homeActivities = pm.queryIntentActivities(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
            val isLauncher = homeActivities.any {
                val pkg = it.activityInfo?.packageName
                !pkg.isNullOrBlank() && pkg != "android" && pkg == packageName
            }
            if (isLauncher) {
                return "Launcher Default (Layar beranda utama)"
            }
        } catch (_: Throwable) {}

        try {
            val defaultIme = Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            val imePkg = defaultIme?.substringBefore("/")
            if (!imePkg.isNullOrBlank() && imePkg == packageName) {
                return "Keyboard Aktif (Metode input sistem)"
            }
        } catch (_: Throwable) {}

        try {
            val smsPkg = Telephony.Sms.getDefaultSmsPackage(context)
            if (!smsPkg.isNullOrBlank() && smsPkg == packageName) {
                return "Aplikasi SMS Default"
            }
        } catch (_: Throwable) {}

        try {
            val telecom = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            val dialerPkg = telecom?.defaultDialerPackage
            if (!dialerPkg.isNullOrBlank() && dialerPkg == packageName) {
                return "Aplikasi Telepon Default"
            }
        } catch (_: Throwable) {}

        return null
    }

    fun getProtectedPackages(context: Context): Set<String> {
        val protectedSet = mutableSetOf<String>()
        val pm = context.packageManager

        protectedSet.add(context.packageName)
        protectedSet.add("moe.shizuku.privileged.api")
        protectedSet.add("rikka.shizuku")
        protectedSet.add("com.google.android.gms")
        protectedSet.add("com.google.android.googlequicksearchbox")
        protectedSet.add("com.android.vending")
        protectedSet.add("com.google.android.gsf")
        protectedSet.add("com.android.systemui")
        protectedSet.add("android")

        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            @Suppress("DEPRECATION")
            val homeActivities = pm.queryIntentActivities(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
            for (info in homeActivities) {
                val pkg = info.activityInfo?.packageName
                if (!pkg.isNullOrBlank() && pkg != "android") {
                    protectedSet.add(pkg)
                }
            }
        } catch (_: Throwable) {}

        try {
            val defaultIme = Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            if (!defaultIme.isNullOrBlank()) {
                val imePkg = defaultIme.substringBefore("/")
                if (imePkg.isNotBlank()) protectedSet.add(imePkg)
            }
        } catch (_: Throwable) {}

        try {
            Telephony.Sms.getDefaultSmsPackage(context)?.let {
                if (it.isNotBlank()) protectedSet.add(it)
            }
        } catch (_: Throwable) {}

        try {
            val telecom = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            telecom?.defaultDialerPackage?.let {
                if (it.isNotBlank()) protectedSet.add(it)
            }
        } catch (_: Throwable) {}

        protectedSet.addAll(getUserProtectedPackages(context))
        return protectedSet
    }

    fun getUserProtectedPackages(context: Context): Set<String> {
        return try {
            val prefs = context.getSharedPreferences("device_monitor_protected", Context.MODE_PRIVATE)
            prefs.getStringSet("user_protected_pkgs", emptySet())?.toSet() ?: emptySet()
        } catch (_: Throwable) {
            emptySet()
        }
    }

    fun addUserProtectedPackage(context: Context, packageName: String) {
        val clean = packageName.trim()
        if (clean.isEmpty()) return
        try {
            val prefs = context.getSharedPreferences("device_monitor_protected", Context.MODE_PRIVATE)
            val userSet = (prefs.getStringSet("user_protected_pkgs", emptySet()) ?: emptySet()).toMutableSet()
            userSet.add(clean)
            prefs.edit().putStringSet("user_protected_pkgs", userSet).apply()
        } catch (_: Throwable) {}
    }

    fun removeUserProtectedPackage(context: Context, packageName: String) {
        try {
            val prefs = context.getSharedPreferences("device_monitor_protected", Context.MODE_PRIVATE)
            val userSet = (prefs.getStringSet("user_protected_pkgs", emptySet()) ?: emptySet()).toMutableSet()
            userSet.remove(packageName)
            prefs.edit().putStringSet("user_protected_pkgs", userSet).apply()
        } catch (_: Throwable) {}
    }

    fun isUserProtected(context: Context, packageName: String): Boolean {
        return getUserProtectedPackages(context).contains(packageName)
    }

    fun toggleUserProtection(context: Context, packageName: String): Boolean {
        val prefs = context.getSharedPreferences("device_monitor_protected", Context.MODE_PRIVATE)
        val userSet = (prefs.getStringSet("user_protected_pkgs", emptySet()) ?: emptySet()).toMutableSet()
        val willProtect = !userSet.contains(packageName)
        if (willProtect) {
            userSet.add(packageName)
        } else {
            userSet.remove(packageName)
        }
        prefs.edit().putStringSet("user_protected_pkgs", userSet).apply()
        return willProtect
    }

    suspend fun getSuspendedPackagesResult(context: Context): Result<Set<String>> = withContext(Dispatchers.IO) {
        try {
            val suspended = mutableSetOf<String>()
            val pm = context.packageManager
            val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.MATCH_UNINSTALLED_PACKAGES.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES)
            }
            for (app in apps) {
                if ((app.flags and ApplicationInfo.FLAG_SUSPENDED) != 0) {
                    suspended.add(app.packageName)
                }
            }
            Result.success(suspended)
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    suspend fun getSuspendedPackages(context: Context): Set<String> {
        return getSuspendedPackagesResult(context).getOrDefault(emptySet())
    }

    private fun normalizeBatteryCapacity(raw: Double): Double {
        return if (raw > 100_000.0) raw / 1000.0 else if (raw > 50_000.0) raw / 1000.0 else raw
    }

    suspend fun getBatteryDesignCapacity(context: Context): Double? = withContext(Dispatchers.IO) {
        // 1. Explicit user input priority
        try {
            val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
            val userCapacity = prefs.getFloat("user_battery_design_capacity", 0f).toDouble()
            if (userCapacity > 500) {
                return@withContext userCapacity
            }
        } catch (_: Throwable) {}

        // 2. Factory design capacity paths
        val sysPaths = listOf(
            "/sys/class/power_supply/battery/charge_full_design",
            "/sys/class/power_supply/bms/charge_full_design",
            "/sys/class/power_supply/battery/fg_design_cap"
        )
        for (path in sysPaths) {
            try {
                val f = File(path)
                if (f.exists() && f.canRead()) {
                    val raw = f.readText().trim().toDoubleOrNull()
                    if (raw != null && raw > 500) {
                        val normalized = normalizeBatteryCapacity(raw)
                        if (normalized in 500.0..30000.0) return@withContext normalized
                    }
                }
            } catch (_: Throwable) {}
        }

        if (hasPermission()) {
            for (path in sysPaths) {
                val res = executeCommand("cat $path")
                if (res.isSuccess) {
                    val raw = res.getOrNull()?.trim()?.toDoubleOrNull()
                    if (raw != null && raw > 500) {
                        val normalized = normalizeBatteryCapacity(raw)
                        if (normalized in 500.0..30000.0) return@withContext normalized
                    }
                }
            }
        }

        // 3. Fallback to Android PowerProfile
        try {
            val powerProfileClass = Class.forName("com.android.internal.os.PowerProfile")
            val constructor = powerProfileClass.getConstructor(Context::class.java)
            val powerProfile = constructor.newInstance(context)
            val getCapMethod = powerProfileClass.getMethod("getBatteryCapacity")
            val capacity = getCapMethod.invoke(powerProfile) as? Double
            if (capacity != null && capacity > 500) {
                return@withContext capacity
            }
        } catch (_: Throwable) {}

        null
    }

    suspend fun getBatteryActualCapacity(context: Context): Double? = withContext(Dispatchers.IO) {
        // Multi-path kernel scanning for charge_full (Actual current capacity only)
        val actualPaths = listOf(
            "/sys/class/power_supply/battery/charge_full",
            "/sys/class/power_supply/bms/charge_full"
        )

        for (path in actualPaths) {
            try {
                val f = File(path)
                if (f.exists() && f.canRead()) {
                    val raw = f.readText().trim().toDoubleOrNull()
                    if (raw != null && raw > 500) {
                        val normalized = normalizeBatteryCapacity(raw)
                        if (normalized in 500.0..30000.0) return@withContext normalized
                    }
                }
            } catch (_: Throwable) {}
        }

        if (hasPermission()) {
            for (path in actualPaths) {
                val res = executeCommand("cat $path")
                if (res.isSuccess) {
                    val raw = res.getOrNull()?.trim()?.toDoubleOrNull()
                    if (raw != null && raw > 500) {
                        val normalized = normalizeBatteryCapacity(raw)
                        if (normalized in 500.0..30000.0) return@withContext normalized
                    }
                }
            }
        }

        null
    }

    private val cpuLock = Any()
    private var lastCpuTotal: Long = 0L
    private var lastCpuIdle: Long = 0L

    suspend fun getCpuUsagePercent(): Float? = withContext(Dispatchers.IO) {
        try {
            val content = if (hasPermission()) {
                executeCommand("head -n 1 /proc/stat").getOrNull() ?: ""
            } else {
                File("/proc/stat").bufferedReader().readLine() ?: ""
            }

            if (content.startsWith("cpu ")) {
                val parts = content.split("\\s+".toRegex()).drop(1).mapNotNull { it.toLongOrNull() }
                if (parts.size >= 4) {
                    val idle = parts[3]
                    val total = parts.sum()
                    synchronized(cpuLock) {
                        if (lastCpuTotal > 0 && total > lastCpuTotal) {
                            val diffTotal = total - lastCpuTotal
                            val diffIdle = idle - lastCpuIdle
                            val usage = 100.0f * (1.0f - (diffIdle.toFloat() / diffTotal.toFloat()))
                            lastCpuTotal = total
                            lastCpuIdle = idle
                            return@withContext usage.coerceIn(0f, 100f)
                        }
                        lastCpuTotal = total
                        lastCpuIdle = idle
                    }
                }
            }
        } catch (_: Throwable) {}
        null
    }

    suspend fun getCpuTemperatureC(): Float? = withContext(Dispatchers.IO) {
        val thermalPaths = listOf(
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/class/thermal/thermal_zone1/temp",
            "/sys/class/thermal/thermal_zone2/temp"
        )
        for (path in thermalPaths) {
            try {
                val raw = if (hasPermission()) {
                    executeCommand("cat $path").getOrNull()?.trim()
                } else {
                    File(path).readText().trim()
                }
                val rawVal = raw?.toFloatOrNull()
                if (rawVal != null) {
                    val temp = if (rawVal > 1000f) rawVal / 1000.0f else rawVal
                    if (temp in 10f..110f) return@withContext temp
                }
            } catch (_: Throwable) {}
        }
        null
    }

    suspend fun fetchMemoryInfo(context: Context): Pair<RamOverview, List<AppProcessInfo>> =
        withContext(Dispatchers.IO) {
            var totalRamMb = 0L
            var freeRamMb = 0L
            var usedRamMb = 0L

            val am = try {
                context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            } catch (_: Throwable) {
                null
            }

            try {
                val memInfo = ActivityManager.MemoryInfo()
                am?.getMemoryInfo(memInfo)
                totalRamMb = (memInfo.totalMem / (1024 * 1024))
                freeRamMb = (memInfo.availMem / (1024 * 1024))
                usedRamMb = (totalRamMb - freeRamMb).coerceAtLeast(0)
            } catch (_: Throwable) {}

            val cpuLoad = try { getCpuUsagePercent() } catch (_: Throwable) { null }
            val cpuTemp = try { getCpuTemperatureC() } catch (_: Throwable) { null }
            val suspendedPackages = try { getSuspendedPackages(context) } catch (_: Throwable) { emptySet() }

            val dumpsysResult = try {
                if (hasPermission()) executeCommand("dumpsys meminfo") else Result.failure(Exception())
            } catch (e: Throwable) {
                Result.failure(e)
            }

            if (dumpsysResult.isSuccess) {
                try {
                    val rawText = dumpsysResult.getOrNull() ?: ""
                    val parsed = parseMemInfoOutput(rawText, context, suspendedPackages)
                    if (parsed.second.isNotEmpty()) {
                        return@withContext Pair(
                            parsed.first.copy(
                                cpuUsagePercent = cpuLoad,
                                cpuTempC = cpuTemp,
                                totalRamMb = if (parsed.first.totalRamMb > 0) parsed.first.totalRamMb else totalRamMb,
                                usedRamMb = if (parsed.first.usedRamMb > 0) parsed.first.usedRamMb else usedRamMb,
                                freeRamMb = if (parsed.first.freeRamMb > 0) parsed.first.freeRamMb else freeRamMb
                            ),
                            parsed.second
                        )
                    }
                } catch (_: Throwable) {}
            }

            val fallbackProcesses = mutableListOf<AppProcessInfo>()
            val pm = context.packageManager
            val protectedSet = getProtectedPackages(context)

            try {
                val runningApps = am?.runningAppProcesses ?: emptyList()
                val pids = runningApps.map { it.pid }.toIntArray()
                val memoryInfos = if (pids.isNotEmpty()) am?.getProcessMemoryInfo(pids) ?: emptyArray() else emptyArray()

                val map = mutableMapOf<String, MutableList<Pair<Int, Long>>>()
                runningApps.forEachIndexed { index, app ->
                    val pssKb = if (index < memoryInfos.size) memoryInfos[index].totalPss.toLong() else 0L
                    for (pkg in app.pkgList ?: arrayOf(app.processName)) {
                        map.getOrPut(pkg) { mutableListOf() }.add(Pair(app.pid, pssKb))
                    }
                }

                for ((pkg, list) in map) {
                    val totalPssKb = list.sumOf { it.second }
                    if (totalPssKb <= 0 && !pkg.contains(".")) continue

                    var label = pkg
                    var isSys = false
                    try {
                        val appInfo = pm.getApplicationInfo(pkg, 0)
                        label = pm.getApplicationLabel(appInfo).toString()
                        isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    } catch (_: Exception) {
                        label = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }
                    }

                    val builtInReason = getBuiltInProtectedReason(context, pkg)
                    val isUserProt = isUserProtected(context, pkg)
                    val isProtected = builtInReason != null || isUserProt || protectedSet.contains(pkg)
                    val reason = when {
                        builtInReason != null -> builtInReason
                        isUserProt -> "Dilindungi Pengguna"
                        isProtected -> "Layanan Utama"
                        else -> ""
                    }

                    fallbackProcesses.add(
                        AppProcessInfo(
                            packageName = pkg,
                            appName = label,
                            pids = list.map { it.first },
                            pssKb = totalPssKb,
                            isSystemApp = isSys,
                            isProtected = isProtected,
                            protectionReason = reason,
                            isSuspended = suspendedPackages.contains(pkg),
                            oomCategory = "Cached"
                        )
                    )
                }

                // Tambahkan app yang sedang disuspend dari sistem meskipun tidak aktif di memori
                val existingPkgs = fallbackProcesses.map { it.packageName }.toSet()
                for (pkg in suspendedPackages) {
                    if (!existingPkgs.contains(pkg)) {
                        var label = pkg
                        var isSys = false
                        try {
                            val appInfo = pm.getApplicationInfo(pkg, 0)
                            label = pm.getApplicationLabel(appInfo).toString()
                            isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                        } catch (_: Exception) {
                            label = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }
                        }
                        val builtInReason = getBuiltInProtectedReason(context, pkg)
                        val isUserProt = isUserProtected(context, pkg)
                        val isProtected = builtInReason != null || isUserProt || protectedSet.contains(pkg)
                        val reason = builtInReason ?: if (isUserProt) "Dilindungi Pengguna" else ""
                        fallbackProcesses.add(
                            AppProcessInfo(
                                packageName = pkg,
                                appName = label,
                                pids = emptyList(),
                                pssKb = 0L,
                                isSystemApp = isSys,
                                isProtected = isProtected,
                                protectionReason = reason,
                                isSuspended = true,
                                oomCategory = "Suspended"
                            )
                        )
                    }
                }

                fallbackProcesses.sortByDescending { it.pssKb }
            } catch (_: Exception) {}

            val overview = RamOverview(
                totalRamMb = totalRamMb,
                usedRamMb = usedRamMb,
                freeRamMb = freeRamMb,
                cpuUsagePercent = cpuLoad,
                cpuTempC = cpuTemp
            )

            Pair(overview, fallbackProcesses)
        }

    private fun parseMemInfoOutput(
        rawText: String,
        context: Context,
        suspendedPackages: Set<String> = emptySet()
    ): Pair<RamOverview, List<AppProcessInfo>> {
        val pm = context.packageManager
        val protectedSet = getProtectedPackages(context)

        var totalRamKb: Long = 0L
        var freeRamKb: Long = 0L
        var usedRamKb: Long = 0L
        var zramTotalKb: Long = 0L
        var zramUsedKb: Long = 0L

        val totalRamRegex = Regex("""Total RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val freeRamRegex = Regex("""Free RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val usedRamRegex = Regex("""Used RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val zramRegex = Regex("""ZRAM:\s+([\d,]+)K.*swap\s+\(([\d,]+)K""", RegexOption.IGNORE_CASE)

        totalRamRegex.find(rawText)?.let {
            totalRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: totalRamKb
        }
        freeRamRegex.find(rawText)?.let {
            freeRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: freeRamKb
        }
        usedRamRegex.find(rawText)?.let {
            usedRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: usedRamKb
        }
        zramRegex.find(rawText)?.let {
            zramUsedKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: zramUsedKb
            zramTotalKb = it.groupValues[2].replace(",", "").toLongOrNull() ?: zramTotalKb
        }

        val installedPackages: Set<String> = try {
            val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.MATCH_UNINSTALLED_PACKAGES.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES)
            }
            apps.map { it.packageName }.toSet()
        } catch (_: Throwable) {
            emptySet()
        }

        val packageRegex = validPackageRegex
        val rawProcessMap = mutableMapOf<String, MutableList<Pair<Int, Long>>>()
        val categoryMap = mutableMapOf<String, String>()
        var currentCategory = "Cached"
        var inOomAdjustmentSection = false

        for (line in rawText.lines()) {
            val trimmed = line.trim()
            if (trimmed.contains("Total PSS by OOM adjustment:", ignoreCase = true)) {
                inOomAdjustmentSection = true
                continue
            }
            if (inOomAdjustmentSection) {
                // Selesai jika menemukan bagian ringkasan / kategori berikutnya
                if (trimmed.startsWith("Total PSS by", ignoreCase = true) ||
                    trimmed.startsWith("Total RAM:", ignoreCase = true) ||
                    trimmed.startsWith("Free RAM:", ignoreCase = true) ||
                    trimmed.startsWith("Used RAM:", ignoreCase = true) ||
                    trimmed.startsWith("ZRAM:", ignoreCase = true)
                ) {
                    inOomAdjustmentSection = false
                    continue
                }

                // Baris tanpa "(pid" adalah nama kategori
                if (!line.contains("(pid", ignoreCase = true)) {
                    if (trimmed.isNotEmpty()) {
                        val catCandidate = if (trimmed.contains(":")) {
                            trimmed.substringAfter(":").trim().ifEmpty { trimmed.substringBefore(":").trim() }
                        } else {
                            trimmed
                        }
                        if (catCandidate.isNotEmpty() && !catCandidate.contains("K:") && !catCandidate.contains("kB", ignoreCase = true)) {
                            currentCategory = catCandidate
                        }
                    }
                    continue
                }

                // Baris dengan "(pid" adalah proses
                val pidMatch = Regex("""\(pid\s+(\d+)""", RegexOption.IGNORE_CASE).find(line)
                val pid = pidMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0

                val pssMatch = Regex("""([\d,]+)K:""", RegexOption.IGNORE_CASE).find(line)
                val pssKb = pssMatch?.groupValues?.get(1)?.replace(",", "")?.toLongOrNull() ?: 0L

                val procNamePart = line.substringAfter("K:", "").substringBefore("(pid", "").trim()
                if (procNamePart.isEmpty()) continue

                val rawPkg = procNamePart.substringBefore(":").trim()

                // Buang yang diawali titik (.so/.jar/.apk/.art)
                if (rawPkg.startsWith(".")) continue

                // Nama proses harus valid sebagai package
                if (!packageRegex.matches(rawPkg)) continue

                val lowerPkg = rawPkg.lowercase(Locale.ROOT)
                if (lowerPkg.endsWith(".so") ||
                    lowerPkg.endsWith(".jar") ||
                    lowerPkg.endsWith(".apk") ||
                    lowerPkg.endsWith(".art") ||
                    lowerPkg.endsWith(".oat") ||
                    lowerPkg.endsWith(".vdex") ||
                    lowerPkg.endsWith(".dex") ||
                    lowerPkg.endsWith(".odex") ||
                    lowerPkg.endsWith(".ttf")
                ) continue

                // Cocokkan ke package aplikasi terpasang (atau parent package terpanjang, kecualikan "android")
                val resolvedPkg = if (installedPackages.isNotEmpty()) {
                    if (installedPackages.contains(rawPkg)) {
                        rawPkg
                    } else {
                        installedPackages
                            .filter { it != "android" && rawPkg.startsWith("$it.") }
                            .maxByOrNull { it.length } ?: continue
                    }
                } else {
                    rawPkg
                }

                // Gabungkan proses satu paket jadi satu baris; jika ada proses non-cached, prioritaskan kategori non-cached
                rawProcessMap.getOrPut(resolvedPkg) { mutableListOf() }.add(Pair(pid, pssKb))
                val existingCat = categoryMap[resolvedPkg]
                if (existingCat == null || !isSafeQuickCleanCategory(currentCategory)) {
                    categoryMap[resolvedPkg] = currentCategory
                }
            }
        }

        val aggregatedList = mutableListOf<AppProcessInfo>()
        for ((pkg, pidList) in rawProcessMap) {
            val combinedPssKb = pidList.sumOf { it.second }
            var appLabel = pkg
            var isSystem = false
            try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                appLabel = pm.getApplicationLabel(appInfo).toString()
                isSystem = (appInfo.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
            } catch (_: Exception) {
                appLabel = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }
            }

            val builtInReason = getBuiltInProtectedReason(context, pkg)
            val isUserProt = isUserProtected(context, pkg)
            val isProtected = builtInReason != null || isUserProt || protectedSet.contains(pkg)
            val reason = when {
                builtInReason != null -> builtInReason
                isUserProt -> "Dilindungi Pengguna"
                isProtected -> "Layanan Utama"
                else -> ""
            }

            val realPids = pidList.map { it.first }.filter { it > 0 }.distinct()

            aggregatedList.add(
                AppProcessInfo(
                    packageName = pkg,
                    appName = appLabel,
                    pids = if (realPids.isNotEmpty()) realPids else listOf(0),
                    pssKb = combinedPssKb,
                    isSystemApp = isSystem,
                    isProtected = isProtected,
                    protectionReason = reason,
                    isSuspended = suspendedPackages.contains(pkg),
                    oomCategory = categoryMap[pkg] ?: "Cached"
                )
            )
        }

        // Tambahkan app yang sedang disuspend dari sistem meskipun tidak aktif di memori
        val existingPkgs = aggregatedList.map { it.packageName }.toSet()
        for (pkg in suspendedPackages) {
            if (!existingPkgs.contains(pkg)) {
                var appLabel = pkg
                var isSystem = false
                try {
                    val appInfo = pm.getApplicationInfo(pkg, 0)
                    appLabel = pm.getApplicationLabel(appInfo).toString()
                    isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                } catch (_: Exception) {
                    appLabel = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }
                }
                val builtInReason = getBuiltInProtectedReason(context, pkg)
                val isUserProt = isUserProtected(context, pkg)
                val isProtected = builtInReason != null || isUserProt || protectedSet.contains(pkg)
                val reason = builtInReason ?: if (isUserProt) "Dilindungi Pengguna" else ""
                aggregatedList.add(
                    AppProcessInfo(
                        packageName = pkg,
                        appName = appLabel,
                        pids = emptyList(),
                        pssKb = 0L,
                        isSystemApp = isSystem,
                        isProtected = isProtected,
                        protectionReason = reason,
                        isSuspended = true,
                        oomCategory = "Suspended"
                    )
                )
            }
        }

        aggregatedList.sortByDescending { it.pssKb }

        val overview = RamOverview(
            totalRamMb = totalRamKb / 1024,
            usedRamMb = usedRamKb / 1024,
            freeRamMb = freeRamKb / 1024,
            zramTotalMb = zramTotalKb / 1024,
            zramUsedMb = zramUsedKb / 1024
        )

        return Pair(overview, aggregatedList)
    }

    data class WakelockAppInfo(
        val packageName: String,
        val appName: String,
        val tag: String,
        val isProtected: Boolean,
        val protectionReason: String
    )

    suspend fun fetchWakelockApps(context: Context): List<WakelockAppInfo> = withContext(Dispatchers.IO) {
        if (!hasPermission()) return@withContext emptyList()
        val res = executeCommand("dumpsys power", timeoutMs = 8_000L)
        val raw = res.getOrNull() ?: return@withContext emptyList()

        val pm = context.packageManager
        val protectedSet = getProtectedPackages(context)
        val installedPackages: Set<String> = try {
            val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
            apps.map { it.packageName }.toSet()
        } catch (_: Throwable) {
            emptySet()
        }

        val found = linkedMapOf<String, String>()
        var inWakeLocks = false
        for (line in raw.lines()) {
            val trimmed = line.trim()
            if (trimmed.startsWith("Wake Locks:")) {
                inWakeLocks = true
                continue
            }
            if (inWakeLocks) {
                if (trimmed.isEmpty() || (!trimmed.contains("WAKE_LOCK") && !trimmed.startsWith("m"))) {
                    if (!trimmed.contains("WAKE_LOCK")) {
                        inWakeLocks = false
                        continue
                    }
                }
                if (trimmed.contains("WAKE_LOCK")) {
                    val tagMatch = Regex("""'([^']+)'""").find(trimmed)
                    val tag = tagMatch?.groupValues?.get(1)?.take(32) ?: "Wakelock"
                    val pkgCandidate = validPackageRegex.findAll(trimmed)
                        .map { it.value }
                        .firstOrNull { it != "android" && (installedPackages.isEmpty() || installedPackages.contains(it)) }
                    if (pkgCandidate != null && !found.containsKey(pkgCandidate)) {
                        found[pkgCandidate] = tag
                    }
                }
            }
        }

        found.entries.take(8).map { (pkg, tag) ->
            var label = pkg
            try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                label = pm.getApplicationLabel(appInfo).toString()
            } catch (_: Throwable) {
                label = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }
            }
            val builtInReason = getBuiltInProtectedReason(context, pkg)
            val isUserProt = isUserProtected(context, pkg)
            val isProt = builtInReason != null || isUserProt || protectedSet.contains(pkg)
            val reason = builtInReason ?: if (isUserProt) "Dilindungi Pengguna" else if (isProt) "Layanan Utama" else ""
            WakelockAppInfo(
                packageName = pkg,
                appName = label,
                tag = tag,
                isProtected = isProt,
                protectionReason = reason
            )
        }
    }
}
