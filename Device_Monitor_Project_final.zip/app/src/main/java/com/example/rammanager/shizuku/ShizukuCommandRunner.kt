package com.example.rammanager.shizuku

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.RamOverview
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

object ShizukuCommandRunner {

    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
    }

    fun hasPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            if (Shizuku.isPreV11()) {
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (_: Throwable) {
            false
        }
    }

    fun requestPermission() {
        if (isShizukuAvailable()) {
            try {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            } catch (_: Throwable) {}
        }
    }

    private fun createShizukuProcess(command: String): Process {
        val cmdArray = arrayOf("sh", "-c", command)
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            method.invoke(null, cmdArray, null, null) as Process
        } catch (_: NoSuchMethodException) {
            val fallbackMethod = Shizuku::class.java.methods.firstOrNull { it.name == "newProcess" }
                ?: throw IllegalStateException("Shizuku newProcess method not found")
            fallbackMethod.isAccessible = true
            if (fallbackMethod.parameterTypes.size == 3) {
                fallbackMethod.invoke(null, cmdArray, null, null) as Process
            } else {
                fallbackMethod.invoke(null, cmdArray) as Process
            }
        }
    }

    suspend fun executeCommand(command: String): Result<String> = withContext(Dispatchers.IO) {
        if (!isShizukuAvailable()) {
            return@withContext Result.failure(IllegalStateException("Shizuku binder is not available."))
        }
        if (!hasPermission()) {
            return@withContext Result.failure(SecurityException("Shizuku permission not granted."))
        }

        try {
            val process = createShizukuProcess(command)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            val output = StringBuilder()
            val error = StringBuilder()

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.appendLine(line)
            }
            while (errorReader.readLine().also { line = it } != null) {
                error.appendLine(line)
            }

            process.waitFor()
            val exitCode = process.exitValue()

            if (exitCode == 0) {
                Result.success(output.toString())
            } else {
                val errStr = error.toString().trim().ifEmpty { output.toString().trim() }
                Result.failure(RuntimeException(if (errStr.isNotEmpty()) errStr else "Exit code: $exitCode"))
            }
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    suspend fun forceStopApp(packageName: String): Result<String> = executeCommand("am force-stop $packageName")
    suspend fun suspendApp(packageName: String): Result<String> = executeCommand("pm suspend $packageName")
    suspend fun unsuspendApp(packageName: String): Result<String> = executeCommand("pm unsuspend $packageName")

    suspend fun setPowerProfile(mode: String): Result<String> {
        val cmd = when (mode.uppercase()) {
            "POWER_SAVER" -> "settings put global low_power 1 && cmd power set-mode 1"
            "PERFORMANCE" -> "settings put global low_power 0 && cmd power set-mode 2"
            else -> "settings put global low_power 0 && cmd power set-mode 0"
        }
        return executeCommand(cmd)
    }

    fun getProtectedPackages(context: Context): Set<String> {
        val protectedSet = mutableSetOf<String>()
        val pm = context.packageManager

        protectedSet.add(context.packageName)
        protectedSet.add("moe.shizuku.privileged.api")
        protectedSet.add("rikka.shizuku")

        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let {
                protectedSet.add(it)
            }
        } catch (_: Exception) {}

        try {
            val defaultIme = Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            if (!defaultIme.isNullOrBlank()) {
                val imePkg = defaultIme.substringBefore("/")
                if (imePkg.isNotBlank()) protectedSet.add(imePkg)
            }
        } catch (_: Exception) {}

        try {
            Telephony.Sms.getDefaultSmsPackage(context)?.let {
                if (it.isNotBlank()) protectedSet.add(it)
            }
        } catch (_: Exception) {}

        try {
            val telecom = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            telecom?.defaultDialerPackage?.let {
                if (it.isNotBlank()) protectedSet.add(it)
            }
        } catch (_: Exception) {}

        val prefs = context.getSharedPreferences("device_monitor_protected", Context.MODE_PRIVATE)
        val userSet = prefs.getStringSet("user_protected_pkgs", emptySet()) ?: emptySet()
        protectedSet.addAll(userSet)

        return protectedSet
    }

    fun isUserProtected(context: Context, packageName: String): Boolean {
        val prefs = context.getSharedPreferences("device_monitor_protected", Context.MODE_PRIVATE)
        val userSet = prefs.getStringSet("user_protected_pkgs", emptySet()) ?: emptySet()
        return userSet.contains(packageName)
    }

    fun toggleUserProtection(context: Context, packageName: String): Boolean {
        val prefs = context.getSharedPreferences("device_monitor_protected", Context.MODE_PRIVATE)
        val userSet = (prefs.getStringSet("user_protected_pkgs", emptySet()) ?: emptySet()).toMutableSet()
        val willProtect = !userSet.contains(packageName)
        if (willProtect) {
            userSet.add(packageName)
        } else {
            userSet.remove(packageName)
        }
        prefs.edit().putStringSet("user_protected_pkgs", userSet).apply()
        return willProtect
    }

    suspend fun getBatteryDesignCapacity(context: Context): Double? = withContext(Dispatchers.IO) {
        val sysPaths = listOf(
            "/sys/class/power_supply/battery/charge_full_design",
            "/sys/class/power_supply/bms/charge_full_design",
            "/sys/class/power_supply/battery/energy_full_design"
        )
        for (path in sysPaths) {
            try {
                val f = File(path)
                if (f.exists() && f.canRead()) {
                    val raw = f.readText().trim().toDoubleOrNull()
                    if (raw != null && raw > 1000) {
                        return@withContext if (raw > 50000) raw / 1000.0 else raw
                    }
                }
            } catch (_: Throwable) {}
        }

        if (hasPermission()) {
            for (path in sysPaths) {
                val res = executeCommand("cat $path")
                if (res.isSuccess) {
                    val raw = res.getOrNull()?.trim()?.toDoubleOrNull()
                    if (raw != null && raw > 1000) {
                        return@withContext if (raw > 50000) raw / 1000.0 else raw
                    }
                }
            }
        }

        try {
            val powerProfileClass = Class.forName("com.android.internal.os.PowerProfile")
            val constructor = powerProfileClass.getConstructor(Context::class.java)
            val powerProfile = constructor.newInstance(context)
            val getCapMethod = powerProfileClass.getMethod("getBatteryCapacity")
            val capacity = getCapMethod.invoke(powerProfile) as? Double
            if (capacity != null && capacity > 500) {
                return@withContext capacity
            }
        } catch (_: Throwable) {}

        val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
        val userCapacity = prefs.getFloat("user_battery_design_capacity", 0f).toDouble()
        if (userCapacity > 500) userCapacity else null
    }

    private var lastCpuTotal: Long = 0L
    private var lastCpuIdle: Long = 0L

    suspend fun getCpuUsagePercent(): Float? = withContext(Dispatchers.IO) {
        try {
            val content = if (hasPermission()) {
                executeCommand("head -n 1 /proc/stat").getOrNull() ?: ""
            } else {
                File("/proc/stat").bufferedReader().readLine() ?: ""
            }

            if (content.startsWith("cpu ")) {
                val parts = content.split("\\s+".toRegex()).drop(1).mapNotNull { it.toLongOrNull() }
                if (parts.size >= 4) {
                    val idle = parts[3]
                    val total = parts.sum()
                    if (lastCpuTotal > 0 && total > lastCpuTotal) {
                        val diffTotal = total - lastCpuTotal
                        val diffIdle = idle - lastCpuIdle
                        val usage = 100.0f * (1.0f - (diffIdle.toFloat() / diffTotal.toFloat()))
                        lastCpuTotal = total
                        lastCpuIdle = idle
                        return@withContext usage.coerceIn(0f, 100f)
                    }
                    lastCpuTotal = total
                    lastCpuIdle = idle
                }
            }
        } catch (_: Throwable) {}
        null
    }

    suspend fun getCpuTemperatureC(): Float? = withContext(Dispatchers.IO) {
        val thermalPaths = listOf(
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/class/thermal/thermal_zone1/temp",
            "/sys/class/thermal/thermal_zone2/temp"
        )
        for (path in thermalPaths) {
            try {
                val raw = if (hasPermission()) {
                    executeCommand("cat $path").getOrNull()?.trim()
                } else {
                    File(path).readText().trim()
                }
                val rawVal = raw?.toFloatOrNull()
                if (rawVal != null) {
                    val temp = if (rawVal > 1000f) rawVal / 1000.0f else rawVal
                    if (temp in 10f..110f) return@withContext temp
                }
            } catch (_: Throwable) {}
        }
        null
    }

    suspend fun fetchMemoryInfo(context: Context): Pair<RamOverview, List<AppProcessInfo>> =
        withContext(Dispatchers.IO) {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)

            var totalRamMb = (memInfo.totalMem / (1024 * 1024))
            var freeRamMb = (memInfo.availMem / (1024 * 1024))
            var usedRamMb = (totalRamMb - freeRamMb).coerceAtLeast(0)

            val cpuLoad = getCpuUsagePercent()
            val cpuTemp = getCpuTemperatureC()

            val dumpsysResult = if (hasPermission()) executeCommand("dumpsys meminfo") else Result.failure(Exception())

            if (dumpsysResult.isSuccess) {
                val rawText = dumpsysResult.getOrNull() ?: ""
                val parsed = parseMemInfoOutput(rawText, context)
                if (parsed.second.isNotEmpty()) {
                    return@withContext Pair(
                        parsed.first.copy(
                            cpuUsagePercent = cpuLoad,
                            cpuTempC = cpuTemp,
                            totalRamMb = if (parsed.first.totalRamMb > 0) parsed.first.totalRamMb else totalRamMb,
                            usedRamMb = if (parsed.first.usedRamMb > 0) parsed.first.usedRamMb else usedRamMb,
                            freeRamMb = if (parsed.first.freeRamMb > 0) parsed.first.freeRamMb else freeRamMb
                        ),
                        parsed.second
                    )
                }
            }

            val fallbackProcesses = mutableListOf<AppProcessInfo>()
            val pm = context.packageManager
            val protectedSet = getProtectedPackages(context)

            try {
                val runningApps = am?.runningAppProcesses ?: emptyList()
                val pids = runningApps.map { it.pid }.toIntArray()
                val memoryInfos = if (pids.isNotEmpty()) am?.getProcessMemoryInfo(pids) ?: emptyArray() else emptyArray()

                val map = mutableMapOf<String, MutableList<Pair<Int, Long>>>()
                runningApps.forEachIndexed { index, app ->
                    val pssKb = if (index < memoryInfos.size) memoryInfos[index].totalPss.toLong() else 0L
                    for (pkg in app.pkgList ?: arrayOf(app.processName)) {
                        map.getOrPut(pkg) { mutableListOf() }.add(Pair(app.pid, pssKb))
                    }
                }

                for ((pkg, list) in map) {
                    val totalPssKb = list.sumOf { it.second }
                    if (totalPssKb <= 0 && !pkg.contains(".")) continue

                    var label = pkg
                    var isSys = false
                    try {
                        val appInfo = pm.getApplicationInfo(pkg, 0)
                        label = pm.getApplicationLabel(appInfo).toString()
                        isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    } catch (_: Exception) {
                        label = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }
                    }

                    val isProtected = isSys || protectedSet.contains(pkg)
                    val reason = when {
                        isSys -> "Sistem Android"
                        pkg == context.packageName -> "Aplikasi Monitor"
                        pkg.contains("shizuku") -> "Shizuku Service"
                        isUserProtected(context, pkg) -> "Dilindungi Pengguna"
                        else -> if (isProtected) "Layanan Utama" else ""
                    }

                    fallbackProcesses.add(
                        AppProcessInfo(
                            packageName = pkg,
                            appName = label,
                            pids = list.map { it.first },
                            pssKb = totalPssKb,
                            isSystemApp = isSys,
                            isProtected = isProtected,
                            protectionReason = reason,
                            isSuspended = false,
                            oomCategory = "Cached"
                        )
                    )
                }
                fallbackProcesses.sortByDescending { it.pssKb }
            } catch (_: Exception) {}

            val overview = RamOverview(
                totalRamMb = totalRamMb,
                usedRamMb = usedRamMb,
                freeRamMb = freeRamMb,
                cpuUsagePercent = cpuLoad,
                cpuTempC = cpuTemp
            )

            Pair(overview, fallbackProcesses)
        }

    private fun parseMemInfoOutput(rawText: String, context: Context): Pair<RamOverview, List<AppProcessInfo>> {
        val pm = context.packageManager
        val protectedSet = getProtectedPackages(context)

        var totalRamKb: Long = 0L
        var freeRamKb: Long = 0L
        var usedRamKb: Long = 0L
        var zramTotalKb: Long = 0L
        var zramUsedKb: Long = 0L

        val totalRamRegex = Regex("""Total RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val freeRamRegex = Regex("""Free RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val usedRamRegex = Regex("""Used RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val zramRegex = Regex("""ZRAM:\s+([\d,]+)K.*swap\s+\(([\d,]+)K""", RegexOption.IGNORE_CASE)

        totalRamRegex.find(rawText)?.let {
            totalRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: totalRamKb
        }
        freeRamRegex.find(rawText)?.let {
            freeRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: freeRamKb
        }
        usedRamRegex.find(rawText)?.let {
            usedRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: usedRamKb
        }
        zramRegex.find(rawText)?.let {
            zramUsedKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: zramUsedKb
            zramTotalKb = it.groupValues[2].replace(",", "").toLongOrNull() ?: zramTotalKb
        }

        val processLineRegex = Regex("""^\s*([\d,]+)K:\s+([a-zA-Z0-9._]+)(?:\s+\(pid\s+(\d+))?""")
        val rawProcessMap = mutableMapOf<String, MutableList<Pair<Int, Long>>>()
        var currentCategory = "Cached"

        for (line in rawText.lines()) {
            val trimmed = line.trim()
            if (trimmed.startsWith("Total PSS by", ignoreCase = true)) continue
            if (trimmed.endsWith(":") && !trimmed.contains("K:")) {
                currentCategory = trimmed.removeSuffix(":")
                continue
            }

            val match = processLineRegex.find(line)
            if (match != null) {
                val pssKb = match.groupValues[1].replace(",", "").toLongOrNull() ?: 0L
                val processName = match.groupValues[2]
                val pid = match.groupValues[3].toIntOrNull() ?: 0

                if (!processName.contains(".")) continue
                rawProcessMap.getOrPut(processName) { mutableListOf() }.add(Pair(pid, pssKb))
            }
        }

        val aggregatedList = mutableListOf<AppProcessInfo>()
        for ((pkg, pidList) in rawProcessMap) {
            val combinedPssKb = pidList.sumOf { it.second }
            var appLabel = pkg
            var isSystem = false
            try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                appLabel = pm.getApplicationLabel(appInfo).toString()
                isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            } catch (_: Exception) {
                appLabel = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }
            }

            val isProtected = isSystem || protectedSet.contains(pkg)
            val reason = when {
                isSystem -> "Sistem Android"
                pkg == context.packageName -> "Aplikasi Monitor"
                pkg.contains("shizuku") -> "Shizuku Service"
                isUserProtected(context, pkg) -> "Dilindungi Pengguna"
                else -> if (isProtected) "Layanan Utama" else ""
            }

            aggregatedList.add(
                AppProcessInfo(
                    packageName = pkg,
                    appName = appLabel,
                    pids = pidList.map { it.first },
                    pssKb = combinedPssKb,
                    isSystemApp = isSystem,
                    isProtected = isProtected,
                    protectionReason = reason,
                    isSuspended = false,
                    oomCategory = currentCategory
                )
            )
        }

        aggregatedList.sortByDescending { it.pssKb }

        val overview = RamOverview(
            totalRamMb = totalRamKb / 1024,
            usedRamMb = usedRamKb / 1024,
            freeRamMb = freeRamKb / 1024,
            zramTotalMb = zramTotalKb / 1024,
            zramUsedMb = zramUsedKb / 1024
        )

        return Pair(overview, aggregatedList)
    }
}
