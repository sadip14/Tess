package com.example.rammanager

import android.app.ActivityManager
import android.content.Context
import android.content.res.Resources
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch

@Composable
fun DeviceInfoScreen(hasShizukuPermission: Boolean) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var gpuRenderer by remember { mutableStateOf<String?>(null) }
    var kernelVersion by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(hasShizukuPermission) {
        scope.launch {
            if (hasShizukuPermission) {
                val surfaceFlingerRes = ShizukuCommandRunner.executeCommand("dumpsys SurfaceFlinger")
                if (surfaceFlingerRes.isSuccess) {
                    val out = surfaceFlingerRes.getOrNull() ?: ""
                    val glesLine = out.lines().firstOrNull { it.contains("GLES:", ignoreCase = true) }
                    gpuRenderer = glesLine?.trim()?.removePrefix("GLES:")?.trim()
                }

                val unameRes = ShizukuCommandRunner.executeCommand("uname -r")
                if (unameRes.isSuccess) {
                    kernelVersion = unameRes.getOrNull()?.trim()
                }
            }
        }
    }

    // Memory info
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    val memInfo = ActivityManager.MemoryInfo()
    am?.getMemoryInfo(memInfo)
    val totalRamGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
    val freeRamGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
    val usedRamGb = (totalRamGb - freeRamGb).coerceAtLeast(0.0)
    val ramUsedPct = if (totalRamGb > 0) ((usedRamGb / totalRamGb) * 100).toInt() else 0

    // Storage info
    val statFs = StatFs(Environment.getDataDirectory().path)
    val totalStorageGb = (statFs.blockCountLong * statFs.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
    val freeStorageGb = (statFs.availableBlocksLong * statFs.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
    val usedStorageGb = (totalStorageGb - freeStorageGb).coerceAtLeast(0.0)
    val storageUsedPct = if (totalStorageGb > 0) ((usedStorageGb / totalStorageGb) * 100).toInt() else 0

    // Display metrics
    val dm = Resources.getSystem().displayMetrics
    val widthPx = dm.widthPixels
    val heightPx = dm.heightPixels
    val densityDpi = dm.densityDpi

    val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    val refreshRate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        context.display?.refreshRate?.toInt() ?: 60
    } else {
        @Suppress("DEPRECATION")
        wm?.defaultDisplay?.refreshRate?.toInt() ?: 60
    }

    // SoC chipset
    val socChipset = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (Build.SOC_MODEL.isNotBlank()) Build.SOC_MODEL else Build.HARDWARE
    } else {
        Build.HARDWARE
    }

    val coresCount = Runtime.getRuntime().availableProcessors()
    val architecture = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B101B))
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Identitas Perangkat
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Smartphone, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Identitas Perangkat",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    InfoRow("Merek / Brand", Build.MANUFACTURER.replaceFirstChar { it.uppercase() })
                    InfoRow(stringResource(R.string.device_model), Build.MODEL)
                    InfoRow("Perangkat / Board", "${Build.DEVICE} (${Build.BOARD})")
                    InfoRow(stringResource(R.string.os_version), "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        InfoRow("Patch Keamanan", Build.VERSION.SECURITY_PATCH)
                    }
                }
            }
        }

        // 2. Prosesor & SoC
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Memory, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Prosesor & SoC (Chipset)",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    InfoRow("Chipset SoC", socChipset)
                    InfoRow("Arsitektur CPU", architecture)
                    InfoRow(stringResource(R.string.cpu_cores), "$coresCount Cores")
                    InfoRow("GPU Renderer", gpuRenderer ?: if (hasShizukuPermission) "Mendeteksi SurfaceFlinger..." else "Adreno / Mali")
                    kernelVersion?.let { InfoRow("Versi Kernel", it) }
                }
            }
        }

        // 3. Memori & Penyimpanan
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Memori & Penyimpanan",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    // RAM Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("RAM Fisik", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        Text(String.format("%.1f GB / %.1f GB (%d%%)", usedRamGb, totalRamGb, ramUsedPct), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (ramUsedPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF0284C7),
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Storage Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Penyimpanan Internal", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        Text(String.format("%.1f GB / %.1f GB (%d%%)", usedStorageGb, totalStorageGb, storageUsedPct), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (storageUsedPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFFF59E0B),
                        trackColor = Color(0xFF1E293B)
                    )
                }
            }
        }

        // 4. Layar & Tampilan
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tv, contentDescription = null, tint = Color(0xFFA855F7), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Layar & Tampilan",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    InfoRow(stringResource(R.string.screen_res), "$widthPx x $heightPx piksel")
                    InfoRow("Kerapatan Layar", "$densityDpi DPI")
                    InfoRow(stringResource(R.string.refresh_rate), "$refreshRate Hz")
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color(0xFF94A3B8), fontSize = 10.sp)
        Text(value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}
