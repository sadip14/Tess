package com.example.rammanager

import android.app.ActivityManager
import android.content.Context
import android.content.res.Resources
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch

@Composable
fun DeviceInfoScreen(hasShizukuPermission: Boolean) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var gpuRenderer by remember { mutableStateOf<String?>(null) }
    var kernelVersion by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(hasShizukuPermission) {
        scope.launch {
            if (hasShizukuPermission) {
                val surfaceFlingerRes = ShizukuCommandRunner.executeCommand("dumpsys SurfaceFlinger")
                if (surfaceFlingerRes.isSuccess) {
                    val out = surfaceFlingerRes.getOrNull() ?: ""
                    val glesLine = out.lines().firstOrNull { it.contains("GLES:", ignoreCase = true) }
                    gpuRenderer = glesLine?.trim()?.removePrefix("GLES:")?.trim()
                }

                val unameRes = ShizukuCommandRunner.executeCommand("uname -r")
                if (unameRes.isSuccess) {
                    kernelVersion = unameRes.getOrNull()?.trim()
                }
            }
        }
    }

    // Memory info
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    val memInfo = ActivityManager.MemoryInfo()
    am?.getMemoryInfo(memInfo)
    val totalRamGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
    val freeRamGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)

    // Storage info
    val statFs = StatFs(Environment.getDataDirectory().path)
    val totalStorageGb = (statFs.blockCountLong * statFs.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
    val freeStorageGb = (statFs.availableBlocksLong * statFs.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)

    // Display metrics
    val dm = Resources.system.displayMetrics
    val widthPx = dm.widthPixels
    val heightPx = dm.heightPixels
    val densityDpi = dm.densityDpi

    val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    val refreshRate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        context.display?.refreshRate?.toInt() ?: 60
    } else {
        @Suppress("DEPRECATION")
        wm?.defaultDisplay?.refreshRate?.toInt() ?: 60
    }

    // SoC chipset (Rule B.1, F.1)
    val socChipset = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (Build.SOC_MODEL.isNotBlank()) Build.SOC_MODEL else Build.HARDWARE
    } else {
        Build.HARDWARE
    }

    val coresCount = Runtime.getRuntime().availableProcessors()
    val architecture = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Device identity card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.device_info_title),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    InfoRow("Merek / Brand", Build.MANUFACTURER.replaceFirstChar { it.uppercase() })
                    InfoRow(stringResource(R.string.device_model), Build.MODEL)
                    InfoRow("Perangkat / Board", "${Build.DEVICE} (${Build.BOARD})")
                    InfoRow(stringResource(R.string.os_version), "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        InfoRow("Patch Keamanan", Build.VERSION.SECURITY_PATCH)
                    }
                }
            }
        }

        // Processor & SoC card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.processor_title),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    InfoRow(stringResource(R.string.soc), socChipset)
                    InfoRow("Arsitektur CPU", architecture)
                    InfoRow(stringResource(R.string.cpu_cores), "$coresCount Cores")
                    InfoRow(stringResource(R.string.gpu), gpuRenderer ?: if (hasShizukuPermission) "Mendeteksi..." else stringResource(R.string.not_available))
                    kernelVersion?.let { InfoRow("Versi Kernel", it) }
                }
            }
        }

        // Memory & Storage card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.memory_storage_title),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    InfoRow("RAM Fisik Total", String.format("%.2f GB", totalRamGb))
                    InfoRow("RAM Tersedia", String.format("%.2f GB", freeRamGb))
                    InfoRow("Penyimpanan Total", String.format("%.1f GB", totalStorageGb))
                    InfoRow("Penyimpanan Kosong", String.format("%.1f GB", freeStorageGb))
                }
            }
        }

        // Display card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.display_title),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    InfoRow(stringResource(R.string.screen_res), "$widthPx x $heightPx piksel")
                    InfoRow("Kerapatan Piksel", "$densityDpi DPI")
                    InfoRow(stringResource(R.string.refresh_rate), "$refreshRate Hz")
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color(0xFF94A3B8), fontSize = 11.sp)
        Text(value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}
