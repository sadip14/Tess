package com.example.rammanager

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun DeviceInfoScreen(hasShizukuPermission: Boolean) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var gpuRenderer by remember { mutableStateOf<String?>(null) }
    var kernelVersion by remember { mutableStateOf<String?>(null) }
    var marketName by remember { mutableStateOf(Build.MODEL) }

    LaunchedEffect(hasShizukuPermission) {
        scope.launch {
            marketName = ShizukuCommandRunner.getMarketName(context)
            if (hasShizukuPermission) {
                try {
                    val surfaceFlingerRes = ShizukuCommandRunner.executeCommand("dumpsys SurfaceFlinger")
                    if (surfaceFlingerRes.isSuccess) {
                        val out = surfaceFlingerRes.getOrNull() ?: ""
                        val glesLine = out.lines().firstOrNull { it.contains("GLES:", ignoreCase = true) }
                        gpuRenderer = glesLine?.trim()?.removePrefix("GLES:")?.trim()?.takeIf { it.isNotBlank() }
                    }
                } catch (_: Throwable) {}

                try {
                    val unameRes = ShizukuCommandRunner.executeCommand("uname -r")
                    if (unameRes.isSuccess) {
                        kernelVersion = unameRes.getOrNull()?.trim()?.takeIf { it.isNotBlank() }
                    }
                } catch (_: Throwable) {}
            }
        }
    }

    // Memory info
    val (totalRamGb, freeRamGb) = remember {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)
            val total = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
            val free = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
            Pair(total, free)
        } catch (_: Throwable) {
            Pair(0.0, 0.0)
        }
    }
    val usedRamGb = (totalRamGb - freeRamGb).coerceAtLeast(0.0)
    val ramUsedPct = if (totalRamGb > 0) ((usedRamGb / totalRamGb) * 100).toInt() else 0

    // Storage info
    val storagePair: Pair<Double, Double>? = remember {
        try {
            val statFs = StatFs(Environment.getDataDirectory().path)
            val total = (statFs.blockCountLong * statFs.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
            val free = (statFs.availableBlocksLong * statFs.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
            Pair(total, free)
        } catch (_: Throwable) {
            null
        }
    }
    val totalStorageGb = storagePair?.first ?: 0.0
    val freeStorageGb = storagePair?.second ?: 0.0
    val usedStorageGb = (totalStorageGb - freeStorageGb).coerceAtLeast(0.0)
    val storageUsedPct = if (totalStorageGb > 0) ((usedStorageGb / totalStorageGb) * 100).toInt() else 0

    // Display metrics
    val dm = Resources.getSystem().displayMetrics
    val widthPx = dm.widthPixels
    val heightPx = dm.heightPixels
    val densityDpi = dm.densityDpi

    val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    val refreshRate = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.display?.refreshRate?.toInt() ?: 60
        } else {
            @Suppress("DEPRECATION")
            wm?.defaultDisplay?.refreshRate?.toInt() ?: 60
        }
    } catch (_: Throwable) {
        60
    }

    // SoC chipset
    val socChipset = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (Build.SOC_MODEL.isNotBlank()) Build.SOC_MODEL else Build.HARDWARE
    } else {
        Build.HARDWARE
    }

    val coresCount = Runtime.getRuntime().availableProcessors()
    val architecture = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B101B))
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Identitas Perangkat
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Smartphone, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Identitas Perangkat",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    InfoRow("Merek / Brand", Build.MANUFACTURER.replaceFirstChar { it.uppercase() })
                    InfoRow(stringResource(R.string.market_name), marketName)
                    InfoRow(stringResource(R.string.device_model), Build.MODEL)
                    InfoRow("Perangkat / Board", "${Build.DEVICE} (${Build.BOARD})")
                    InfoRow(stringResource(R.string.os_version), "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        InfoRow("Patch Keamanan", Build.VERSION.SECURITY_PATCH)
                    }
                }
            }
        }

        // 2. Prosesor & SoC
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Memory, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Prosesor & SoC (Chipset)",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    InfoRow("Chipset SoC", socChipset)
                    InfoRow("Arsitektur CPU", architecture)
                    InfoRow(stringResource(R.string.cpu_cores), "$coresCount Cores")
                    InfoRow(
                        stringResource(R.string.gpu),
                        gpuRenderer ?: stringResource(R.string.not_available)
                    )
                    InfoRow("Versi Kernel", kernelVersion ?: stringResource(R.string.not_available))
                }
            }
        }

        // 3. Memori & Penyimpanan
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Memori & Penyimpanan",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    // RAM Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("RAM Fisik", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        Text(
                            text = if (totalRamGb > 0) String.format(Locale.US, "%.1f GB / %.1f GB (%d%%)", usedRamGb, totalRamGb, ramUsedPct) else stringResource(R.string.not_available),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (ramUsedPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF0284C7),
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Storage Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Penyimpanan Internal", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        Text(
                            text = if (storagePair != null && totalStorageGb > 0) String.format(Locale.US, "%.1f GB / %.1f GB (%d%%)", usedStorageGb, totalStorageGb, storageUsedPct) else stringResource(R.string.not_available),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (storageUsedPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (storageUsedPct > 90) Color(0xFFEF4444) else Color(0xFFF59E0B),
                        trackColor = Color(0xFF1E293B)
                    )

                    if (storageUsedPct > 90) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFEF4444).copy(alpha = 0.14f), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFFEF4444).copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color(0xFFEF4444),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.storage_almost_full_warning, storageUsedPct),
                                color = Color(0xFFFCA5A5),
                                fontSize = 9.sp,
                                lineHeight = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // 4. Layar & Tampilan
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tv, contentDescription = null, tint = Color(0xFFA855F7), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Layar & Tampilan",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    InfoRow(stringResource(R.string.screen_res), "$widthPx x $heightPx piksel")
                    InfoRow("Kerapatan Layar", "$densityDpi DPI")
                    InfoRow(stringResource(R.string.refresh_rate), "$refreshRate Hz")
                }
            }
        }

        // 5. Salin & Bagikan Spesifikasi
        item {
            val specsCopiedMsg = stringResource(R.string.specs_copied)
            val shareTitle = stringResource(R.string.share_specs)
            val specsText = buildString {
                appendLine("=== Device Monitor Specs ===")
                appendLine("Brand: ${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }}")
                appendLine("Market Name: $marketName")
                appendLine("Model: ${Build.MODEL} (${Build.DEVICE})")
                appendLine("OS: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                appendLine("SoC: $socChipset ($coresCount cores, $architecture)")
                appendLine("GPU: ${gpuRenderer ?: "N/A"}")
                appendLine("Kernel: ${kernelVersion ?: "N/A"}")
                appendLine("RAM: ${String.format(Locale.US, "%.1f GB / %.1f GB (%d%%)", usedRamGb, totalRamGb, ramUsedPct)}")
                appendLine("Storage: ${String.format(Locale.US, "%.1f GB / %.1f GB (%d%%)", usedStorageGb, totalStorageGb, storageUsedPct)}")
                appendLine("Display: ${widthPx}x${heightPx} @ ${refreshRate}Hz (${densityDpi} DPI)")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        cm?.setPrimaryClip(ClipData.newPlainText("Device Specs", specsText))
                        Toast.makeText(context, specsCopiedMsg, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 42.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.copy_specs), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, specsText)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, shareTitle))
                    },
                    border = BorderStroke(1.dp, Color(0xFF334155)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 42.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.share_specs), color = Color(0xFF38BDF8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = Color(0xFF94A3B8),
            fontSize = 10.sp,
            modifier = Modifier.weight(1f, fill = false)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            textAlign = androidx.compose.ui.text.style.TextAlign.End,
            modifier = Modifier.weight(1.6f, fill = false)
        )
    }
}
