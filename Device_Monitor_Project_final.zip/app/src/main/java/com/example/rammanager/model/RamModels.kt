package com.example.rammanager.model

data class RamOverview(
    val totalRamMb: Long,
    val usedRamMb: Long,
    val freeRamMb: Long,
    val zramTotalMb: Long = 0L,
    val zramUsedMb: Long = 0L,
    val cpuUsagePercent: Float? = null,
    val cpuTempC: Float? = null
) {
    val usedPercentage: Int
        get() = if (totalRamMb > 0) ((usedRamMb * 100) / totalRamMb).toInt() else 0
}

data class AppProcessInfo(
    val packageName: String,
    val appName: String,
    val pids: List<Int>,
    val pssKb: Long,
    val isSystemApp: Boolean,
    val isProtected: Boolean,
    val protectionReason: String,
    val isSuspended: Boolean,
    val oomCategory: String
) {
    val pssMb: Double
        get() = pssKb / 1024.0

    val formattedRam: String
        get() = if (pssMb >= 1024.0) String.format("%.2f GB", pssMb / 1024.0)
        else String.format("%.0f MB", pssMb)
}

enum class CleaningAction(val displayName: String) {
    FORCE_STOP("Force Stop"),
    SUSPEND("Suspend"),
    UNSUSPEND("Unsuspend"),
    BATCH_BOOST("Deep Clean")
}

data class CleaningHistoryRecord(
    val packageName: String,
    val appName: String,
    val action: CleaningAction,
    val estimatedRamFreedMb: Double,
    val timestamp: Long
) {
    val formattedRamFreed: String
        get() = if (estimatedRamFreedMb >= 1024.0) String.format("%.2f GB", estimatedRamFreedMb / 1024.0)
        else String.format("%.0f MB", estimatedRamFreedMb)
}
