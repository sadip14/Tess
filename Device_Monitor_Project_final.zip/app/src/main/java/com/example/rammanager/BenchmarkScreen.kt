package com.example.rammanager

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.benchmark.DeviceBenchmarkEngine
import com.example.rammanager.data.BenchmarkHistoryRepository
import com.example.rammanager.model.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BenchmarkScreen(
    onBenchmarkStateChange: (isRunning: Boolean) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { DeviceBenchmarkEngine(context) }
    val repo = remember { BenchmarkHistoryRepository.getInstance(context) }

    var selectedMode by remember { mutableStateOf(BenchmarkMode.FAST) }
    var isRunning by remember { mutableStateOf(false) }
    var progressText by remember { mutableStateOf("") }
    var progressPercent by remember { mutableStateOf(0) }

    var currentResult by remember { mutableStateOf<BenchmarkResultRecord?>(null) }
    var previousResult by remember { mutableStateOf<BenchmarkResultRecord?>(null) }
    var averageHistoricalScore by remember { mutableStateOf(0) }
    var importedComparison by remember { mutableStateOf<ImportedBenchmarkComparison?>(null) }

    var showImportDialog by remember { mutableStateOf(false) }
    var importInputText by remember { mutableStateOf("") }
    var historyList by remember { mutableStateOf<List<BenchmarkResultRecord>>(emptyList()) }

    fun refreshHistory() {
        scope.launch {
            historyList = repo.getAllResults()
            previousResult = repo.getPreviousResult(selectedMode)
            averageHistoricalScore = repo.getAverageScore(selectedMode)
        }
    }

    LaunchedEffect(selectedMode) {
        refreshHistory()
    }

    val chipsetModel = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && Build.SOC_MODEL.isNotBlank()) {
            Build.SOC_MODEL
        } else {
            Build.HARDWARE
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B101B))
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Mode Selector Row
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Uji Komputasi Sintetis CPU Device Monitor",
                            color = Color.White,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Native Benchmark",
                            color = Color(0xFF38BDF8),
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        BenchmarkMode.values().forEach { mode ->
                            val isSel = selectedMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) Color(0xFF0284C7) else Color(0xFF0F172A))
                                    .border(1.dp, if (isSel) Color(0xFF38BDF8) else Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                    .clickable {
                                        if (!isRunning) {
                                            selectedMode = mode
                                            importedComparison = null
                                        }
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = mode.label,
                                    fontSize = 9.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSel) Color.White else Color(0xFF94A3B8),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // Hero Benchmark Score Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF0284C7).copy(alpha = 0.4f), Color(0xFF1E293B))
                    )
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.score).uppercase(),
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isRunning) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 12.dp)
                        ) {
                            Text(
                                text = "Menguji Performa...",
                                color = Color(0xFF38BDF8),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { progressPercent / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFF0284C7),
                                trackColor = Color(0xFF1E293B)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = progressText,
                                color = Color(0xFFCBD5E1),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    } else {
                        val scoreText = if (currentResult == null) {
                            "---"
                        } else if (!currentResult!!.isValid) {
                            "Tidak Valid"
                        } else if (currentResult!!.mode == BenchmarkMode.FAST) {
                            "Tes singkat"
                        } else {
                            String.format("%,d", currentResult!!.totalScore)
                        }

                        Text(
                            text = scoreText,
                            color = if (currentResult?.isValid == false) Color(0xFFEF4444) else Color.White,
                            fontSize = if (scoreText == "Tes singkat" || scoreText == "Tidak Valid") 24.sp else 34.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = if (selectedMode == BenchmarkMode.FAST) "$chipsetModel • Hasil singkat tanpa skor DMB" else "$chipsetModel • DMB-v1 Benchmark",
                            color = Color(0xFF64748B),
                            fontSize = 8.5.sp
                        )

                        currentResult?.let { res ->
                            Spacer(modifier = Modifier.height(6.dp))

                            // Thermal tracking before and after
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                val thermalColor = when (res.thermalStatusAfter) {
                                    AndroidThermalStatus.NONE -> Color(0xFF34D399)
                                    AndroidThermalStatus.LIGHT -> Color(0xFFFBBF24)
                                    AndroidThermalStatus.MODERATE -> Color(0xFFF97316)
                                    AndroidThermalStatus.SEVERE, AndroidThermalStatus.CRITICAL, AndroidThermalStatus.EMERGENCY, AndroidThermalStatus.SHUTDOWN -> Color(0xFFEF4444)
                                    AndroidThermalStatus.UNKNOWN -> Color(0xFF94A3B8)
                                }
                                Text(
                                    text = if (res.thermalStatusBefore == res.thermalStatusAfter) {
                                        "Status Termal Android: ${res.thermalStatusAfter.label}"
                                    } else {
                                        "Status Termal: ${res.thermalStatusBefore.label} ➔ ${res.thermalStatusAfter.label}"
                                    },
                                    color = thermalColor,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            if (!res.isValid) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Hasil Tidak Valid: ${res.validationError ?: "Kegagalan pengujian penyimpanan"}",
                                    color = Color(0xFFEF4444),
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (!isRunning) {
                                isRunning = true
                                onBenchmarkStateChange(true)
                                progressPercent = 0
                                progressText = "Menyiapkan pengujian…"
                                importedComparison = null

                                scope.launch {
                                    try {
                                        val record = engine.runBenchmark(selectedMode) { phase, pct ->
                                            progressText = phase
                                            progressPercent = pct
                                        }
                                        repo.saveResult(record)
                                        currentResult = record
                                        refreshHistory()
                                        val toastMsg = if (!record.isValid) {
                                            "Pengujian selesai dengan error: ${record.validationError}"
                                        } else if (record.mode == BenchmarkMode.FAST) {
                                            "Tes singkat selesai!"
                                        } else {
                                            "Benchmark DMB-v1 Selesai! Skor: ${record.totalScore}"
                                        }
                                        Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Pengujian gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                                    } finally {
                                        isRunning = false
                                        onBenchmarkStateChange(false)
                                    }
                                }
                            }
                        },
                        enabled = !isRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRunning) "Sedang Menguji..." else stringResource(R.string.run_benchmark),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // 4 Component Subscore Breakdown Cards (Displaying prominent Median alongside min/avg/max)
        currentResult?.let { res ->
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("CPU Single-Core", color = Color(0xFF94A3B8), fontSize = 9.sp)
                            val scoreStr = if (res.mode == BenchmarkMode.FAST) "---" else String.format("%,d", res.singleCoreScore)
                            Text(scoreStr, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Median: ${res.singleCoreOpsSec.formattedMedian}", color = Color(0xFF38BDF8), fontSize = 8.5.sp, fontWeight = FontWeight.SemiBold)
                            StabilityBadge(res.singleCoreOpsSec)
                            Text(res.singleCoreOpsSec.formattedMinMaxAvg, color = Color(0xFF64748B), fontSize = 7.5.sp)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("CPU Multi-Core", color = Color(0xFF94A3B8), fontSize = 9.sp)
                            val scoreStr = if (res.mode == BenchmarkMode.FAST) "---" else String.format("%,d", res.multiCoreScore)
                            Text(scoreStr, color = Color(0xFF38BDF8), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Median: ${res.multiCoreOpsSec.formattedMedian}", color = Color(0xFF38BDF8), fontSize = 8.5.sp, fontWeight = FontWeight.SemiBold)
                            StabilityBadge(res.multiCoreOpsSec)
                            Text(res.multiCoreOpsSec.formattedMinMaxAvg, color = Color(0xFF64748B), fontSize = 7.5.sp)
                        }
                    }
                }
            }

            if (res.mode != BenchmarkMode.STRESS) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Memory Copy Throughput", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                val scoreStr = if (res.mode == BenchmarkMode.FAST) "---" else String.format("%,d", res.ramScore)
                                Text(scoreStr, color = Color(0xFF10B981), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Median: ${res.ramThroughputMbSec.formattedMedian}", color = Color(0xFF10B981), fontSize = 8.5.sp, fontWeight = FontWeight.SemiBold)
                                StabilityBadge(res.ramThroughputMbSec)
                                Text(res.ramThroughputMbSec.formattedMinMaxAvg, color = Color(0xFF64748B), fontSize = 7.5.sp)
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Mixed File I/O Throughput", color = Color(0xFF94A3B8), fontSize = 9.sp)
                                val scoreStr = if (res.mode == BenchmarkMode.FAST) "---" else String.format("%,d", res.storageScore)
                                Text(scoreStr, color = Color(0xFFFBBF24), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Median: ${res.storageThroughputMbSec.formattedMedian}", color = Color(0xFFFBBF24), fontSize = 8.5.sp, fontWeight = FontWeight.SemiBold)
                                StabilityBadge(res.storageThroughputMbSec)
                                Text(res.storageThroughputMbSec.formattedMinMaxAvg, color = Color(0xFF64748B), fontSize = 7.5.sp)
                            }
                        }
                    }
                }
            }

            // Stress Test Throttling Graph
            if (res.mode == BenchmarkMode.STRESS && res.stressCurve.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Grafik Beban Suhu & Throttling", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                res.stressCurve.forEach { p ->
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("${p.second}s", color = Color(0xFF64748B), fontSize = 8.sp)
                                        Text("${p.score}", color = Color(0xFF38BDF8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        p.tempC?.let {
                                            Text(String.format("%.0f°C", it), color = Color(0xFFEF4444), fontSize = 8.sp)
                                        }
                                    }
                                }
                            }

                            res.throttlingDropPct?.let { drop ->
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Penurunan Performa (Throttling): -${String.format("%.1f%%", drop)}",
                                    color = if (drop > 15f) Color(0xFFEF4444) else Color(0xFF10B981),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // Perbandingan HANYA dengan Riwayat Pengujian Sendiri & Hasil Import (Baseline disembunyikan karena BELUM TERUKUR)
            if (res.mode != BenchmarkMode.FAST && res.isValid && (previousResult != null || averageHistoricalScore > 0)) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.linearGradient(listOf(Color(0xFF0284C7).copy(alpha = 0.35f), Color(0xFF1E293B)))
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Perbandingan Riwayat Sendiri",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                previousResult?.let { prev ->
                                    if (prev.isValid && prev.totalScore > 0) {
                                        val delta = res.totalScore - prev.totalScore
                                        val pctDelta = (delta.toFloat() / prev.totalScore.toFloat()) * 100f
                                        val isHigher = delta >= 0
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    if (isHigher) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFEF4444).copy(alpha = 0.15f),
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "${if (isHigher) "+" else ""}${String.format(Locale.US, "%.1f%%", pctDelta)}",
                                                color = if (isHigher) Color(0xFF34D399) else Color(0xFFF87171),
                                                fontSize = 8.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                previousResult?.let { prev ->
                                    if (prev.isValid && prev.totalScore > 0) {
                                        val delta = res.totalScore - prev.totalScore
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp)) {
                                                Text("Tes Sebelumnya", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                                Text(
                                                    text = String.format("%,d", prev.totalScore),
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                                Text(
                                                    text = "${if (delta >= 0) "+" else ""}${String.format("%,d", delta)} poin",
                                                    color = if (delta >= 0) Color(0xFF10B981) else Color(0xFFEF4444),
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                        }
                                    }
                                }

                                if (averageHistoricalScore > 0) {
                                    val avgDelta = res.totalScore - averageHistoricalScore
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(modifier = Modifier.padding(8.dp)) {
                                            Text("Rata-rata Riwayat", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                            Text(
                                                text = String.format("%,d", averageHistoricalScore),
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "${if (avgDelta >= 0) "+" else ""}${String.format("%,d", avgDelta)} poin",
                                                color = if (avgDelta >= 0) Color(0xFF10B981) else Color(0xFFEF4444),
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Perbandingan dengan Hasil Teman via Import
            importedComparison?.let { friend ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.linearGradient(listOf(Color(0xFF10B981).copy(alpha = 0.4f), Color(0xFF1E293B)))
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Komparasi Hasil Teman (Diimpor)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                if (res.totalScore > 0 && friend.totalScore > 0) {
                                    val diff = res.totalScore - friend.totalScore
                                    val pct = (diff.toFloat() / friend.totalScore.toFloat()) * 100f
                                    val isWin = diff >= 0
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (isWin) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFEF4444).copy(alpha = 0.15f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "${if (isWin) "+" else ""}${String.format(Locale.US, "%.1f%%", pct)} vs Teman",
                                            color = if (isWin) Color(0xFF34D399) else Color(0xFFF87171),
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Perangkat Teman: ${friend.deviceModel} (${friend.mode.label})",
                                color = Color(0xFFCBD5E1),
                                fontSize = 9.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text("Skor Anda", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                        Text(if (res.totalScore > 0) String.format("%,d", res.totalScore) else "---", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text("Skor Teman", color = Color(0xFF64748B), fontSize = 8.5.sp)
                                        Text(if (friend.totalScore > 0) String.format("%,d", friend.totalScore) else "---", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Action Buttons: Share & Import
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val shareText = res.toShareText()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Benchmark Result", shareText))
                            Toast.makeText(context, "Teks hasil disalin ke clipboard! Bagikan ke teman.", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141B27)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(R.string.share_result), color = Color.White, fontSize = 10.sp)
                    }

                    Button(
                        onClick = {
                            importInputText = ""
                            showImportDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141B27)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource(R.string.import_result), color = Color.White, fontSize = 10.sp)
                    }
                }
            }
        }

        // Benchmark History Section
        item {
            Text(
                text = stringResource(R.string.history_title),
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (historyList.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(10.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = stringResource(R.string.empty_benchmark_history),
                        color = Color(0xFF64748B),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        } else {
            items(historyList.take(6)) { h ->
                val df = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(8.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${h.deviceModel} • ${h.mode.label}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            Text(df.format(Date(h.timestamp)), color = Color(0xFF64748B), fontSize = 8.5.sp)
                        }
                        val scoreDisplay = if (!h.isValid) "Tidak Valid" else if (h.mode == BenchmarkMode.FAST) "Tes singkat" else String.format("%,d", h.totalScore)
                        Text(scoreDisplay, color = Color(0xFF38BDF8), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }

    // Import Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = Color(0xFF141B27),
            title = {
                Text(stringResource(R.string.import_result), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text("Tempel teks format benchmark teman Anda di sini:", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importInputText,
                        onValueChange = { importInputText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0F172A),
                            unfocusedContainerColor = Color(0xFF0F172A),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsed = repo.parseAndValidateImport(importInputText)
                        if (parsed.isSuccess) {
                            val friend = parsed.getOrNull()
                            if (friend != null) {
                                importedComparison = friend
                                showImportDialog = false
                                Toast.makeText(context, "Hasil ${friend.deviceModel} berhasil diimpor!", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "Format tidak valid: ${parsed.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text(stringResource(R.string.import_btn), fontSize = 11.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 11.sp)
                }
            }
        )
    }
}

@Composable
private fun StabilityBadge(variation: MetricVariation) {
    if (variation.median <= 0.0) return
    val spread = (variation.max - variation.min) / variation.median
    val (textRes, textColor, bgColor) = when {
        spread <= 0.05 -> Triple(R.string.stability_stable, Color(0xFF34D399), Color(0xFF10B981).copy(alpha = 0.15f))
        spread <= 0.10 -> Triple(R.string.stability_fair, Color(0xFFFBBF24), Color(0xFFF59E0B).copy(alpha = 0.15f))
        else -> Triple(R.string.stability_noisy, Color(0xFFF87171), Color(0xFFEF4444).copy(alpha = 0.15f))
    }
    Box(
        modifier = Modifier
            .padding(vertical = 2.dp)
            .background(bgColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
    ) {
        Text(
            text = stringResource(textRes),
            color = textColor,
            fontSize = 7.5.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

