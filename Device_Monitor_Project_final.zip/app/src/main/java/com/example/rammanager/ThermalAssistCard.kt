package com.example.rammanager

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.model.AndroidThermalStatus
import com.example.rammanager.model.BatterySessionRecord
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

data class CpuDrainApp(
    val packageName: String,
    val appName: String,
    val cpuPercent: Double,
    val isProtected: Boolean,
    val isSystem: Boolean
)

data class CoolingSample(
    val elapsedSeconds: Int,
    val tempC: Double
)

@Composable
fun ThermalAssistCard(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isExpanded by remember { mutableStateOf(true) }

    // Live Sensor Readings
    var currentBatteryTemp by remember { mutableStateOf<Double?>(null) }
    var isCharging by remember { mutableStateOf(false) }
    var androidThermalStatus by remember { mutableStateOf<AndroidThermalStatus?>(null) }

    // Top CPU Drain Apps state
    var isShizukuPermitted by remember { mutableStateOf(false) }
    var isLoadingCpuApps by remember { mutableStateOf(false) }
    var cpuAppsError by remember { mutableStateOf<String?>(null) }
    var topCpuApps by remember { mutableStateOf<List<CpuDrainApp>>(emptyList()) }

    // "Dinginkan" Dialog State
    var showCoolingDialog by remember { mutableStateOf(false) }
    var selectedAppsToStop by remember { mutableStateOf<Set<String>>(emptySet()) }
    var isCoolingInProgress by remember { mutableStateOf(false) }

    // 5-Minute Cool-down Tracking State
    var isMonitoringCooling by remember { mutableStateOf(false) }
    var monitoringFinished by remember { mutableStateOf(false) }
    var coolingStartTemp by remember { mutableStateOf<Double?>(null) }
    var coolingSamples by remember { mutableStateOf<List<CoolingSample>>(emptyList()) }

    // 24-Hour Battery History State
    var historicalSessions24h by remember { mutableStateOf<List<BatterySessionRecord>>(emptyList()) }
    var isHistoryLoaded by remember { mutableStateOf(false) }

    // Settings: Auto Power Saver on Heat
    val prefs = remember { context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE) }
    var autoPowerSaveOnHeat by remember {
        mutableStateOf(prefs.getBoolean("auto_power_save_on_heat", false))
    }
    var autoPowerSaveThreshold by remember {
        mutableIntStateOf(prefs.getInt("auto_power_save_threshold", 43))
    }

    // Function to read live battery & thermal sensors
    fun updateSensors() {
        val batteryIntent = try {
            context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (_: Throwable) {
            null
        }
        val tempRaw = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        currentBatteryTemp = if (tempRaw > 0) tempRaw / 10.0 else null

        val chargeStatus = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        isCharging = chargeStatus == BatteryManager.BATTERY_STATUS_CHARGING ||
                chargeStatus == BatteryManager.BATTERY_STATUS_FULL

        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val statusCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && pm != null) {
            try {
                pm.currentThermalStatus
            } catch (_: Throwable) {
                -1
            }
        } else {
            -1
        }
        androidThermalStatus = AndroidThermalStatus.fromCode(statusCode)
    }

    // Function to fetch top 5 CPU drain apps via Shizuku dumpsys cpuinfo
    fun refreshCpuApps() {
        isShizukuPermitted = ShizukuCommandRunner.hasPermission()
        if (!isShizukuPermitted) {
            topCpuApps = emptyList()
            cpuAppsError = null
            return
        }

        isLoadingCpuApps = true
        cpuAppsError = null

        scope.launch {
            val res = ShizukuCommandRunner.executeCommand("dumpsys cpuinfo")
            if (res.isSuccess) {
                val output = res.getOrNull().orEmpty()
                val parsed = withContext(Dispatchers.Default) {
                    parseTopCpuDrainApps(context, output)
                }
                topCpuApps = parsed
                isLoadingCpuApps = false
            } else {
                cpuAppsError = res.exceptionOrNull()?.message ?: "Gagal menjalankan dumpsys"
                topCpuApps = emptyList()
                isLoadingCpuApps = false
            }
        }
    }

    // Function to load 24h battery temperature history
    fun load24hHistory() {
        scope.launch {
            val repo = BatteryHistoryRepository.getInstance(context)
            val all = repo.getAllSessions()
            val cutoff = System.currentTimeMillis() - 24 * 3600 * 1000L
            val last24h = all.filter { it.endTime >= cutoff && it.peakTemperatureC != null }
                .sortedBy { it.endTime }
            historicalSessions24h = last24h
            isHistoryLoaded = true
        }
    }

    // Initial load
    LaunchedEffect(Unit) {
        updateSensors()
        refreshCpuApps()
        load24hHistory()
    }

    // Background 5-Minute Cool-down Tracking Loop
    LaunchedEffect(isMonitoringCooling) {
        if (isMonitoringCooling) {
            monitoringFinished = false
            // 10 intervals of 30 seconds = 300s (5 minutes)
            val initialTemp = currentBatteryTemp
            coolingStartTemp = initialTemp
            coolingSamples = if (initialTemp != null) listOf(CoolingSample(0, initialTemp)) else emptyList()

            for (step in 1..10) {
                delay(30_000L) // 30 seconds
                updateSensors()
                val tempNow = currentBatteryTemp
                if (tempNow != null) {
                    coolingSamples = coolingSamples + CoolingSample(step * 30, tempNow)
                }
            }
            isMonitoringCooling = false
            monitoringFinished = true
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                listOf(
                    if ((currentBatteryTemp ?: 0.0) >= 40.0) Color(0xFFEF4444).copy(alpha = 0.5f)
                    else Color(0xFF0284C7).copy(alpha = 0.35f),
                    Color(0xFF1E293B)
                )
            )
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Title & Expand/Collapse Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                if ((currentBatteryTemp ?: 0.0) >= 40.0)
                                    Color(0xFFEF4444).copy(alpha = 0.15f)
                                else
                                    Color(0xFF0284C7).copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Thermostat,
                            contentDescription = null,
                            tint = if ((currentBatteryTemp ?: 0.0) >= 40.0) Color(0xFFEF4444) else Color(0xFF38BDF8),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.thermal_assist_title),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(R.string.thermal_assist_desc),
                            color = Color(0xFF94A3B8),
                            fontSize = 9.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8)
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column {
                    Spacer(modifier = Modifier.height(12.dp))

                    // 1. Live Sensor Row: Battery Temp & Android Thermal Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Battery Temperature Box
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF0B1320),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = stringResource(R.string.battery_temp_title),
                                    color = Color(0xFF64748B),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = currentBatteryTemp?.let { String.format(Locale.US, "%.1f°C", it) }
                                            ?: stringResource(R.string.thermal_unavailable),
                                        color = when {
                                            currentBatteryTemp == null -> Color(0xFF94A3B8)
                                            currentBatteryTemp!! >= 42.0 -> Color(0xFFEF4444)
                                            currentBatteryTemp!! >= 38.0 -> Color(0xFFF59E0B)
                                            else -> Color(0xFF10B981)
                                        },
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    if (isCharging) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            Icons.Default.Bolt,
                                            contentDescription = null,
                                            tint = Color(0xFFF59E0B),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Android Thermal Status Box
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF0B1320),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = stringResource(R.string.android_thermal_status_title),
                                    color = Color(0xFF64748B),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                val status = androidThermalStatus ?: AndroidThermalStatus.UNKNOWN
                                Text(
                                    text = if (status == AndroidThermalStatus.UNKNOWN) {
                                        stringResource(R.string.thermal_unavailable)
                                    } else {
                                        status.label
                                    },
                                    color = when (status) {
                                        AndroidThermalStatus.NONE -> Color(0xFF10B981)
                                        AndroidThermalStatus.LIGHT, AndroidThermalStatus.MODERATE -> Color(0xFFF59E0B)
                                        AndroidThermalStatus.SEVERE, AndroidThermalStatus.CRITICAL,
                                        AndroidThermalStatus.EMERGENCY, AndroidThermalStatus.SHUTDOWN -> Color(0xFFEF4444)
                                        else -> Color(0xFF94A3B8)
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // 7. Charging High-Temp Warning (if isCharging && temp >= 40°C)
                    if (isCharging && (currentBatteryTemp ?: 0.0) >= 40.0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFEF4444).copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stringResource(R.string.charging_hot_advice),
                                    color = Color(0xFFFCA5A5),
                                    fontSize = 10.sp,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. Top 5 CPU Drain Apps via dumpsys cpuinfo
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.top_cpu_apps_title),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    updateSensors()
                                    refreshCpuApps()
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (!isShizukuPermitted) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF0F172A),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = stringResource(R.string.shizuku_required_for_cpu),
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    } else if (isLoadingCpuApps) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Color(0xFF38BDF8),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Membaca dumpsys cpuinfo…",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }
                    } else if (cpuAppsError != null) {
                        Text(
                            text = "${stringResource(R.string.failed_parsing_cpu)}: $cpuAppsError",
                            color = Color(0xFFF87171),
                            fontSize = 10.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else if (topCpuApps.isEmpty()) {
                        Text(
                            text = stringResource(R.string.no_cpu_apps_found),
                            color = Color(0xFF64748B),
                            fontSize = 10.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        // Display Top 5 Apps
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            topCpuApps.forEach { app ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF0B1320),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = app.appName,
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Medium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (app.isProtected) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    Icons.Default.Lock,
                                                    contentDescription = stringResource(R.string.protected_app_locked),
                                                    tint = Color(0xFF10B981),
                                                    modifier = Modifier.size(11.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = String.format(Locale.US, "%.1f%% CPU", app.cpuPercent),
                                            color = if (app.cpuPercent >= 10.0) Color(0xFFEF4444) else Color(0xFF38BDF8),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 3. Tombol "Dinginkan"
                        val stopCandidates = remember(topCpuApps) {
                            topCpuApps.filter { !it.isProtected && !it.isSystem && it.cpuPercent >= 5.0 }
                        }

                        Button(
                            onClick = {
                                selectedAppsToStop = stopCandidates.map { it.packageName }.toSet()
                                showCoolingDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (stopCandidates.isNotEmpty()) Color(0xFF0284C7) else Color(0xFF1E293B)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !isCoolingInProgress && !isMonitoringCooling
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.AcUnit,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = stringResource(R.string.btn_cool_down),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // 4 & 5. Bukti Hasil: 5-Minute Cool-down Tracking & Real Delta
                    if (coolingSamples.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF0B1320),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.cooling_monitoring_title),
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (isMonitoringCooling) {
                                        Text(
                                            text = stringResource(R.string.cooling_monitoring_active),
                                            color = Color(0xFF38BDF8),
                                            fontSize = 9.sp
                                        )
                                    } else if (monitoringFinished) {
                                        Text(
                                            text = stringResource(R.string.cooling_monitoring_finished),
                                            color = Color(0xFF10B981),
                                            fontSize = 9.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                val firstTemp = coolingSamples.firstOrNull()?.tempC ?: 0.0
                                val latestTemp = coolingSamples.lastOrNull()?.tempC ?: firstTemp
                                val delta = latestTemp - firstTemp

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.cooling_initial_temp, String.format(Locale.US, "%.1f°C", firstTemp)),
                                        color = Color(0xFF94A3B8),
                                        fontSize = 10.sp
                                    )
                                    Text(
                                        text = stringResource(R.string.cooling_current_temp, String.format(Locale.US, "%.1f°C", latestTemp)),
                                        color = Color(0xFF94A3B8),
                                        fontSize = 10.sp
                                    )
                                    // Real Measured Delta Label
                                    Text(
                                        text = when {
                                            delta <= -0.15 -> stringResource(R.string.temp_change_dropped, String.format(Locale.US, "%.1f", abs(delta)))
                                            delta >= 0.15 -> stringResource(R.string.temp_change_rose, String.format(Locale.US, "%.1f", delta))
                                            else -> stringResource(R.string.temp_change_unchanged)
                                        },
                                        color = when {
                                            delta <= -0.15 -> Color(0xFF10B981)
                                            delta >= 0.15 -> Color(0xFFEF4444)
                                            else -> Color(0xFF94A3B8)
                                        },
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Mini line chart of measured points
                                MiniTemperatureChart(
                                    samples = coolingSamples,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(60.dp)
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Explicit Disclaimer
                                Text(
                                    text = stringResource(R.string.cooling_disclaimer),
                                    color = Color(0xFF64748B),
                                    fontSize = 9.sp,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }

                    // 6. Grafik Riwayat Suhu Baterai 24 Jam Terakhir
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF0B1320),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = stringResource(R.string.temp_history_24h_title),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            if (historicalSessions24h.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = stringResource(R.string.temp_history_no_data),
                                        color = Color(0xFF64748B),
                                        fontSize = 10.sp
                                    )
                                }
                            } else {
                                History24hTemperatureChart(
                                    sessions = historicalSessions24h,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(70.dp)
                                )
                            }
                        }
                    }

                    // 8. Opsi "Hemat Daya otomatis saat panas"
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF0B1320),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.auto_power_save_heat_title),
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = stringResource(R.string.auto_power_save_heat_desc, autoPowerSaveThreshold),
                                        color = Color(0xFF94A3B8),
                                        fontSize = 9.sp,
                                        lineHeight = 12.sp
                                    )
                                }
                                Switch(
                                    checked = autoPowerSaveOnHeat,
                                    onCheckedChange = { checked ->
                                        autoPowerSaveOnHeat = checked
                                        prefs.edit().putBoolean("auto_power_save_on_heat", checked).apply()
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF0284C7),
                                        uncheckedThumbColor = Color(0xFF94A3B8),
                                        uncheckedTrackColor = Color(0xFF1E293B)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog for "Dinginkan"
    if (showCoolingDialog) {
        val stopCandidates = remember(topCpuApps) {
            topCpuApps.filter { !it.isProtected && !it.isSystem && it.cpuPercent >= 5.0 }
        }

        AlertDialog(
            onDismissRequest = {
                if (!isCoolingInProgress) showCoolingDialog = false
            },
            title = {
                Text(
                    text = stringResource(R.string.cooling_dialog_title),
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    if (stopCandidates.isEmpty()) {
                        Text(
                            text = stringResource(R.string.cooling_dialog_no_apps),
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.cooling_dialog_desc),
                            color = Color(0xFFCBD5E1),
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        stopCandidates.forEach { app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedAppsToStop = if (selectedAppsToStop.contains(app.packageName)) {
                                            selectedAppsToStop - app.packageName
                                        } else {
                                            selectedAppsToStop + app.packageName
                                        }
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = selectedAppsToStop.contains(app.packageName),
                                    onCheckedChange = { isChecked ->
                                        selectedAppsToStop = if (isChecked) {
                                            selectedAppsToStop + app.packageName
                                        } else {
                                            selectedAppsToStop - app.packageName
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = Color(0xFF0284C7),
                                        checkmarkColor = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = app.appName,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${app.packageName} (${String.format(Locale.US, "%.1f%%", app.cpuPercent)})",
                                        color = Color(0xFF64748B),
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isCoolingInProgress = true
                        scope.launch {
                            var stoppedCount = 0
                            for (pkg in selectedAppsToStop) {
                                val stopRes = ShizukuCommandRunner.forceStopApp(context, pkg)
                                if (stopRes.isSuccess) {
                                    stoppedCount++
                                }
                            }
                            // Call verified Power Profile "POWER_SAVER"
                            val powerRes = ShizukuCommandRunner.setPowerProfile("POWER_SAVER")
                            isCoolingInProgress = false
                            showCoolingDialog = false

                            Toast.makeText(
                                context,
                                context.getString(R.string.cooling_completed_toast, stoppedCount),
                                Toast.LENGTH_SHORT
                            ).show()

                            // Refresh CPU list and start 5-minute tracking
                            refreshCpuApps()
                            updateSensors()
                            isMonitoringCooling = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    enabled = !isCoolingInProgress
                ) {
                    if (isCoolingInProgress) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Text(text = stringResource(R.string.btn_confirm_cooling), color = Color.White, fontSize = 11.sp)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCoolingDialog = false },
                    enabled = !isCoolingInProgress
                ) {
                    Text(text = "Batal", color = Color(0xFF94A3B8), fontSize = 11.sp)
                }
            },
            containerColor = Color(0xFF141B27)
        )
    }
}

/**
 * Mini line chart for the 5-minute cooling monitoring
 */
@Composable
private fun MiniTemperatureChart(
    samples: List<CoolingSample>,
    modifier: Modifier = Modifier
) {
    if (samples.size < 2) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("Mengumpulkan data interval pertama (30s)…", color = Color(0xFF64748B), fontSize = 9.sp)
        }
        return
    }

    val minTemp = samples.minOf { it.tempC }
    val maxTemp = samples.maxOf { it.tempC }
    val tempRange = (maxTemp - minTemp).coerceAtLeast(1.0)

    Canvas(modifier = modifier.padding(vertical = 4.dp, horizontal = 2.dp)) {
        val w = size.width
        val h = size.height

        val points = samples.mapIndexed { idx, s ->
            val x = (idx.toFloat() / (samples.size - 1).coerceAtLeast(1)) * w
            val normalizedY = ((s.tempC - minTemp) / tempRange).toFloat()
            val y = h - (normalizedY * (h - 10f)) - 5f
            Offset(x, y)
        }

        // Draw line
        val path = Path().apply {
            moveTo(points.first().x, points.first().y)
            for (i in 1 until points.size) {
                lineTo(points[i].x, points[i].y)
            }
        }

        drawPath(
            path = path,
            color = Color(0xFF38BDF8),
            style = Stroke(width = 2.dp.toPx())
        )

        // Draw points
        points.forEach { pt ->
            drawCircle(
                color = Color(0xFF38BDF8),
                radius = 3.dp.toPx(),
                center = pt
            )
            drawCircle(
                color = Color(0xFF0B1320),
                radius = 1.5.dp.toPx(),
                center = pt
            )
        }
    }
}

/**
 * Mini line chart for the last 24h battery temperature history
 */
@Composable
private fun History24hTemperatureChart(
    sessions: List<BatterySessionRecord>,
    modifier: Modifier = Modifier
) {
    val validSessions = sessions.filter { it.peakTemperatureC != null }
    if (validSessions.size < 2) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("Data titik sesi belum mencukupi untuk grafik.", color = Color(0xFF64748B), fontSize = 9.sp)
        }
        return
    }

    val minTemp = validSessions.minOf { it.peakTemperatureC!! }
    val maxTemp = validSessions.maxOf { it.peakTemperatureC!! }
    val tempRange = (maxTemp - minTemp).coerceAtLeast(1.0)

    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    Column(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxWidth().weight(1f).padding(vertical = 4.dp)) {
            val w = size.width
            val h = size.height

            val points = validSessions.mapIndexed { idx, s ->
                val x = (idx.toFloat() / (validSessions.size - 1).coerceAtLeast(1)) * w
                val normalizedY = ((s.peakTemperatureC!! - minTemp) / tempRange).toFloat()
                val y = h - (normalizedY * (h - 10f)) - 5f
                Offset(x, y)
            }

            val path = Path().apply {
                moveTo(points.first().x, points.first().y)
                for (i in 1 until points.size) {
                    lineTo(points[i].x, points[i].y)
                }
            }

            drawPath(
                path = path,
                color = Color(0xFFF59E0B),
                style = Stroke(width = 2.dp.toPx())
            )

            points.forEach { pt ->
                drawCircle(
                    color = Color(0xFFF59E0B),
                    radius = 3.dp.toPx(),
                    center = pt
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = timeFormat.format(Date(validSessions.first().endTime)),
                color = Color(0xFF64748B),
                fontSize = 8.sp
            )
            Text(
                text = "Min: ${String.format(Locale.US, "%.1f°C", minTemp)} | Maks: ${String.format(Locale.US, "%.1f°C", maxTemp)}",
                color = Color(0xFF94A3B8),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = timeFormat.format(Date(validSessions.last().endTime)),
                color = Color(0xFF64748B),
                fontSize = 8.sp
            )
        }
    }
}

/**
 * Parses dumpsys cpuinfo output into top 5 CPU drain apps
 */
private fun parseTopCpuDrainApps(context: Context, rawOutput: String): List<CpuDrainApp> {
    val pm = context.packageManager
    val protectedSet = ShizukuCommandRunner.getProtectedPackages(context)

    // Regex for dumpsys cpuinfo lines:
    // e.g.: "  18% 1234/com.google.android.youtube: 14% user + 4% kernel"
    // or:   "  5.2% com.example.app: ..."
    val lineRegex = """^\s*(\d+(?:\.\d+)?)\s*%\s+(?:(\d+)/)?([a-zA-Z0-9._]+):""".toRegex()

    val parsedList = mutableListOf<CpuDrainApp>()

    rawOutput.lineSequence().forEach { line ->
        val match = lineRegex.find(line) ?: return@forEach
        val cpuPct = match.groupValues[1].toDoubleOrNull() ?: 0.0
        val pkg = match.groupValues[3].trim()

        // Filter out non-package tokens
        if (pkg.equals("TOTAL", ignoreCase = true) ||
            pkg.startsWith("kworker") ||
            pkg.startsWith("system_server") ||
            !pkg.contains(".")
        ) {
            return@forEach
        }

        if (!ShizukuCommandRunner.isValidPackageName(pkg)) {
            return@forEach
        }

        val appLabel = try {
            val appInfo = pm.getApplicationInfo(pkg, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (_: Throwable) {
            pkg
        }

        val isSystem = ShizukuCommandRunner.isSystemPackage(context, pkg)
        val isProtected = protectedSet.contains(pkg) ||
                ShizukuCommandRunner.getBuiltInProtectedReason(context, pkg) != null

        parsedList.add(
            CpuDrainApp(
                packageName = pkg,
                appName = appLabel,
                cpuPercent = cpuPct,
                isProtected = isProtected,
                isSystem = isSystem
            )
        )
    }

    // Sort by cpuPercent descending, and take top 5
    return parsedList
        .sortedByDescending { it.cpuPercent }
        .distinctBy { it.packageName }
        .take(5)
}
