package com.example.rammanager.data

import android.content.Context
import android.content.SharedPreferences
import com.example.rammanager.model.BatteryHealthReport
import com.example.rammanager.model.BatterySessionRecord
import com.example.rammanager.model.BatterySessionType
import com.example.rammanager.model.LearnedDrainInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class BatteryHistoryRepository private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "device_monitor_battery_history"
        private const val KEY_SESSIONS_DATA = "key_battery_sessions"
        private const val KEY_CYCLE_COUNT = "key_battery_cycle_count"
        private const val MAX_SESSIONS = 200

        @Volatile
        private var instance: BatteryHistoryRepository? = null

        fun getInstance(context: Context): BatteryHistoryRepository {
            return instance ?: synchronized(this) {
                instance ?: BatteryHistoryRepository(context).also { instance = it }
            }
        }
    }

    suspend fun recordSession(session: BatterySessionRecord): BatterySessionRecord = withContext(Dispatchers.IO) {
        val currentList = getAllSessionsInternal().toMutableList()
        currentList.add(0, session)

        if (currentList.size > MAX_SESSIONS) {
            currentList.subList(MAX_SESSIONS, currentList.size).clear()
        }

        saveSessionsInternal(currentList)

        // Increment cycle count only when actual charge delta occurred
        if (session.sessionType == BatterySessionType.CHARGING && session.levelDelta > 5) {
            val deltaCycles = session.levelDelta / 100.0
            val existingCycles = prefs.getFloat(KEY_CYCLE_COUNT, 0.0f)
            prefs.edit().putFloat(KEY_CYCLE_COUNT, existingCycles + deltaCycles.toFloat()).apply()
        }

        session
    }

    suspend fun getAllSessions(): List<BatterySessionRecord> = withContext(Dispatchers.IO) {
        getAllSessionsInternal()
    }

    suspend fun clearSessions() = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY_SESSIONS_DATA).apply()
    }

    /**
     * Calculates real battery health from kernel sysfs charge_full or stored historical sessions.
     * When kernel node is available, uses "Metode: Kernel Reader".
     * Fallback to AccuBattery charge session delta method ("Metode: Estimasi Sesi Charger") when kernel is unreadable.
     */
    suspend fun getHealthReport(
        designCapacityMah: Int,
        kernelActualCapacityMah: Double? = null
    ): BatteryHealthReport = withContext(Dispatchers.IO) {
        val cycleCount = prefs.getFloat(KEY_CYCLE_COUNT, 0.0f).toInt()

        // 1. Prioritaskan Kernel Reader jika node kernel terdeteksi valid
        if (kernelActualCapacityMah != null && kernelActualCapacityMah > 500.0 && designCapacityMah > 500) {
            val healthPercent = (kernelActualCapacityMah / designCapacityMah.toDouble()) * 100.0
            val wearLevel = (100.0 - healthPercent).coerceAtLeast(0.0)
            val condition = when {
                healthPercent >= 90.0 -> "Sangat Baik"
                healthPercent >= 80.0 -> "Baik"
                healthPercent >= 70.0 -> "Perlu Perhatian"
                else -> "Disarankan Ganti"
            }

            return@withContext BatteryHealthReport(
                designCapacityMah = designCapacityMah,
                estimatedCapacityMah = kernelActualCapacityMah,
                healthPercent = healthPercent,
                cycleCount = cycleCount,
                wearLevelPercent = wearLevel,
                condition = condition,
                totalSessionsLearned = getAllSessionsInternal().size,
                accuracyScorePercent = 98,
                hasSufficientData = true,
                methodLabel = "Metode: Pembaca Kernel"
            )
        }

        // 2. Metode Fallback: AccuBattery Delta Method dari sesi charging
        val sessions = getAllSessionsInternal().filter {
            it.sessionType == BatterySessionType.CHARGING && it.levelDelta >= 15 && it.energyMah > 50
        }

        if (sessions.isEmpty() || designCapacityMah <= 0) {
            return@withContext BatteryHealthReport(
                designCapacityMah = designCapacityMah,
                estimatedCapacityMah = null,
                healthPercent = null,
                cycleCount = cycleCount,
                wearLevelPercent = null,
                condition = "Belum cukup data",
                totalSessionsLearned = 0,
                accuracyScorePercent = 0,
                hasSufficientData = false,
                methodLabel = "Belum cukup data"
            )
        }

        var totalWeightedCap = 0.0
        var totalDelta = 0

        for (s in sessions) {
            val delta = s.levelDelta
            // AccuBattery Delta Formula: (mAh terisi / % bertambah) * 100
            val estCap = (s.energyMah / delta.toDouble()) * 100.0
            // Exclude extreme anomalies
            if (estCap in (designCapacityMah * 0.4)..(designCapacityMah * 1.3)) {
                totalWeightedCap += estCap * delta
                totalDelta += delta
            }
        }

        if (totalDelta == 0) {
            return@withContext BatteryHealthReport(
                designCapacityMah = designCapacityMah,
                estimatedCapacityMah = null,
                healthPercent = null,
                cycleCount = cycleCount,
                wearLevelPercent = null,
                condition = "Belum cukup data",
                totalSessionsLearned = sessions.size,
                accuracyScorePercent = 0,
                hasSufficientData = false,
                methodLabel = "Belum cukup data"
            )
        }

        val estimatedCapacity = totalWeightedCap / totalDelta
        val healthPercent = (estimatedCapacity / designCapacityMah.toDouble()) * 100.0
        val wearLevel = (100.0 - healthPercent).coerceAtLeast(0.0)

        val condition = when {
            healthPercent >= 90.0 -> "Sangat Baik"
            healthPercent >= 80.0 -> "Baik"
            healthPercent >= 70.0 -> "Perlu Perhatian"
            else -> "Disarankan Ganti"
        }

        val accuracy = (50 + (sessions.size * 5)).coerceAtMost(95)

        BatteryHealthReport(
            designCapacityMah = designCapacityMah,
            estimatedCapacityMah = estimatedCapacity,
            healthPercent = healthPercent,
            cycleCount = cycleCount,
            wearLevelPercent = wearLevel,
            condition = condition,
            totalSessionsLearned = sessions.size,
            accuracyScorePercent = accuracy,
            hasSufficientData = true,
            methodLabel = "Metode: Estimasi Sesi Charger"
        )
    }

    suspend fun getLearnedDrainRates(): LearnedDrainInfo = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val allDischarge = getAllSessionsInternal().filter {
            it.sessionType == BatterySessionType.DISCHARGING &&
                    it.durationMinutes >= 15 &&
                    it.levelDelta > 0
        }

        // Sesi lama tanpa data layar dikecualikan dari estimasi
        val validSessions = allDischarge.filter {
            it.screenOnMinutes != null && it.screenOffMinutes != null &&
                    it.screenOnDrainPercent != null && it.screenOffDrainPercent != null
        }

        if (validSessions.isEmpty()) {
            return@withContext LearnedDrainInfo(
                hasSufficientData = false,
                screenOnDrainRatePerHour = null,
                screenOffDrainRatePerHour = null,
                mixedDrainRatePerHour = null,
                sevenDayScreenOnRatio = null,
                totalDischargeMinutes = 0
            )
        }

        // Hitung laju Layar Nyala langsung dari data akumulasi menit nyala & drain nyala
        val totalScreenOnMinutes = validSessions.sumOf { it.screenOnMinutes ?: 0 }
        val totalScreenOnDrain = validSessions.sumOf { it.screenOnDrainPercent ?: 0 }

        val screenOnRate: Double? = if (totalScreenOnMinutes > 0 && totalScreenOnDrain > 0) {
            (totalScreenOnDrain.toDouble() / totalScreenOnMinutes.toDouble()) * 60.0
        } else null

        // Hitung laju Layar Mati langsung dari data akumulasi menit mati & drain mati
        val totalScreenOffMinutes = validSessions.sumOf { it.screenOffMinutes ?: 0 }
        val totalScreenOffDrain = validSessions.sumOf { it.screenOffDrainPercent ?: 0 }

        val screenOffRate: Double? = if (totalScreenOffMinutes > 0 && totalScreenOffDrain > 0) {
            (totalScreenOffDrain.toDouble() / totalScreenOffMinutes.toDouble()) * 60.0
        } else null

        // 3. Campuran memakai rasio waktu layar nyala dan mati yang diukur selama 7 hari terakhir
        val sevenDaysAgo = now - (7 * 24 * 3600 * 1000L)
        val sevenDaySessions = validSessions.filter { it.endTime >= sevenDaysAgo }
        val ratioSessions = if (sevenDaySessions.isNotEmpty()) sevenDaySessions else validSessions

        val ratioScreenOnMins = ratioSessions.sumOf { it.screenOnMinutes ?: 0 }
        val ratioScreenOffMins = ratioSessions.sumOf { it.screenOffMinutes ?: 0 }
        val totalRatioMins = ratioScreenOnMins + ratioScreenOffMins

        val (onRatio, offRatio) = if (totalRatioMins > 0) {
            Pair(
                ratioScreenOnMins.toDouble() / totalRatioMins.toDouble(),
                ratioScreenOffMins.toDouble() / totalRatioMins.toDouble()
            )
        } else {
            Pair(0.5, 0.5)
        }

        val mixedRate: Double? = if (screenOnRate != null && screenOffRate != null) {
            (screenOnRate * onRatio) + (screenOffRate * offRatio)
        } else if (screenOnRate != null) {
            screenOnRate
        } else if (screenOffRate != null) {
            screenOffRate
        } else {
            null
        }

        LearnedDrainInfo(
            hasSufficientData = screenOnRate != null || screenOffRate != null || mixedRate != null,
            screenOnDrainRatePerHour = screenOnRate,
            screenOffDrainRatePerHour = screenOffRate,
            mixedDrainRatePerHour = mixedRate,
            sevenDayScreenOnRatio = onRatio,
            totalDischargeMinutes = validSessions.sumOf { it.durationMinutes }
        )
    }

    private fun getAllSessionsInternal(): List<BatterySessionRecord> {
        val jsonStr = prefs.getString(KEY_SESSIONS_DATA, null) ?: return emptyList()
        val list = mutableListOf<BatterySessionRecord>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val rec = BatterySessionRecord(
                    id = obj.optString("id", "session-$i"),
                    sessionType = BatterySessionType.valueOf(obj.optString("sessionType", "CHARGING")),
                    startTime = obj.optLong("startTime", 0L),
                    endTime = obj.optLong("endTime", 0L),
                    durationMinutes = obj.optInt("durationMinutes", 0),
                    startLevelPercent = obj.optInt("startLevelPercent", 0),
                    endLevelPercent = obj.optInt("endLevelPercent", 0),
                    energyMah = obj.optDouble("energyMah", 0.0),
                    avgCurrentMa = if (obj.has("avgCurrentMa")) obj.optInt("avgCurrentMa") else null,
                    peakTemperatureC = if (obj.has("peakTemperatureC")) obj.optDouble("peakTemperatureC") else null,
                    chargerType = obj.optString("chargerType", null),
                    screenOnMinutes = if (obj.has("screenOnMinutes")) obj.optInt("screenOnMinutes") else null,
                    screenOffMinutes = if (obj.has("screenOffMinutes")) obj.optInt("screenOffMinutes") else null,
                    screenOnDrainPercent = if (obj.has("screenOnDrainPercent")) obj.optInt("screenOnDrainPercent") else null,
                    screenOffDrainPercent = if (obj.has("screenOffDrainPercent")) obj.optInt("screenOffDrainPercent") else null
                )
                list.add(rec)
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveSessionsInternal(sessions: List<BatterySessionRecord>) {
        try {
            val jsonArray = JSONArray()
            for (s in sessions) {
                val obj = JSONObject().apply {
                    put("id", s.id)
                    put("sessionType", s.sessionType.name)
                    put("startTime", s.startTime)
                    put("endTime", s.endTime)
                    put("durationMinutes", s.durationMinutes)
                    put("startLevelPercent", s.startLevelPercent)
                    put("endLevelPercent", s.endLevelPercent)
                    put("energyMah", s.energyMah)
                    s.avgCurrentMa?.let { put("avgCurrentMa", it) }
                    s.peakTemperatureC?.let { put("peakTemperatureC", it) }
                    s.chargerType?.let { put("chargerType", it) }
                    s.screenOnMinutes?.let { put("screenOnMinutes", it) }
                    s.screenOffMinutes?.let { put("screenOffMinutes", it) }
                    s.screenOnDrainPercent?.let { put("screenOnDrainPercent", it) }
                    s.screenOffDrainPercent?.let { put("screenOffDrainPercent", it) }
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString(KEY_SESSIONS_DATA, jsonArray.toString()).apply()
        } catch (_: Exception) {}
    }
}
