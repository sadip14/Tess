package com.example.rammanager.data

import android.content.Context
import android.content.SharedPreferences
import com.example.rammanager.model.BatteryHealthReport
import com.example.rammanager.model.BatterySessionRecord
import com.example.rammanager.model.BatterySessionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class BatteryHistoryRepository private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "device_monitor_battery_history"
        private const val KEY_SESSIONS_DATA = "key_battery_sessions"
        private const val KEY_CYCLE_COUNT = "key_battery_cycle_count"
        private const val MAX_SESSIONS = 200

        @Volatile
        private var instance: BatteryHistoryRepository? = null

        fun getInstance(context: Context): BatteryHistoryRepository {
            return instance ?: synchronized(this) {
                instance ?: BatteryHistoryRepository(context).also { instance = it }
            }
        }
    }

    suspend fun recordSession(session: BatterySessionRecord): BatterySessionRecord = withContext(Dispatchers.IO) {
        val currentList = getAllSessionsInternal().toMutableList()
        currentList.add(0, session)

        if (currentList.size > MAX_SESSIONS) {
            currentList.subList(MAX_SESSIONS, currentList.size).clear()
        }

        saveSessionsInternal(currentList)

        // Increment cycle count only when actual charge delta occurred
        if (session.sessionType == BatterySessionType.CHARGING && session.levelDelta > 5) {
            val deltaCycles = session.levelDelta / 100.0
            val existingCycles = prefs.getFloat(KEY_CYCLE_COUNT, 0.0f)
            prefs.edit().putFloat(KEY_CYCLE_COUNT, existingCycles + deltaCycles.toFloat()).apply()
        }

        session
    }

    suspend fun getAllSessions(): List<BatterySessionRecord> = withContext(Dispatchers.IO) {
        getAllSessionsInternal()
    }

    suspend fun clearSessions() = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY_SESSIONS_DATA).apply()
    }

    /**
     * Calculates real battery health from kernel sysfs charge_full or stored historical sessions.
     * When kernel node is available, uses "Metode: Kernel Reader".
     * Fallback to AccuBattery charge session delta method ("Metode: Estimasi Sesi Charger") when kernel is unreadable.
     */
    suspend fun getHealthReport(
        designCapacityMah: Int,
        kernelActualCapacityMah: Double? = null
    ): BatteryHealthReport = withContext(Dispatchers.IO) {
        val cycleCount = prefs.getFloat(KEY_CYCLE_COUNT, 0.0f).toInt()

        // 1. Prioritaskan Kernel Reader jika node kernel terdeteksi valid
        if (kernelActualCapacityMah != null && kernelActualCapacityMah > 500.0 && designCapacityMah > 500) {
            val healthPercent = (kernelActualCapacityMah / designCapacityMah.toDouble()) * 100.0
            val wearLevel = (100.0 - healthPercent).coerceAtLeast(0.0)
            val condition = when {
                healthPercent >= 90.0 -> "Sangat Baik"
                healthPercent >= 80.0 -> "Baik"
                healthPercent >= 70.0 -> "Perlu Perhatian"
                else -> "Disarankan Ganti"
            }

            return@withContext BatteryHealthReport(
                designCapacityMah = designCapacityMah,
                estimatedCapacityMah = kernelActualCapacityMah,
                healthPercent = healthPercent,
                cycleCount = cycleCount,
                wearLevelPercent = wearLevel,
                condition = condition,
                totalSessionsLearned = getAllSessionsInternal().size,
                accuracyScorePercent = 98,
                hasSufficientData = true,
                methodLabel = "Metode: Pembaca Kernel"
            )
        }

        // 2. Metode Fallback: AccuBattery Delta Method dari sesi charging
        val sessions = getAllSessionsInternal().filter {
            it.sessionType == BatterySessionType.CHARGING && it.levelDelta >= 15 && it.energyMah > 50
        }

        if (sessions.isEmpty() || designCapacityMah <= 0) {
            return@withContext BatteryHealthReport(
                designCapacityMah = designCapacityMah,
                estimatedCapacityMah = null,
                healthPercent = null,
                cycleCount = cycleCount,
                wearLevelPercent = null,
                condition = "Belum cukup data",
                totalSessionsLearned = 0,
                accuracyScorePercent = 0,
                hasSufficientData = false,
                methodLabel = "Belum cukup data"
            )
        }

        var totalWeightedCap = 0.0
        var totalDelta = 0

        for (s in sessions) {
            val delta = s.levelDelta
            // AccuBattery Delta Formula: (mAh terisi / % bertambah) * 100
            val estCap = (s.energyMah / delta.toDouble()) * 100.0
            // Exclude extreme anomalies
            if (estCap in (designCapacityMah * 0.4)..(designCapacityMah * 1.3)) {
                totalWeightedCap += estCap * delta
                totalDelta += delta
            }
        }

        if (totalDelta == 0) {
            return@withContext BatteryHealthReport(
                designCapacityMah = designCapacityMah,
                estimatedCapacityMah = null,
                healthPercent = null,
                cycleCount = cycleCount,
                wearLevelPercent = null,
                condition = "Belum cukup data",
                totalSessionsLearned = sessions.size,
                accuracyScorePercent = 0,
                hasSufficientData = false,
                methodLabel = "Belum cukup data"
            )
        }

        val estimatedCapacity = totalWeightedCap / totalDelta
        val healthPercent = (estimatedCapacity / designCapacityMah.toDouble()) * 100.0
        val wearLevel = (100.0 - healthPercent).coerceAtLeast(0.0)

        val condition = when {
            healthPercent >= 90.0 -> "Sangat Baik"
            healthPercent >= 80.0 -> "Baik"
            healthPercent >= 70.0 -> "Perlu Perhatian"
            else -> "Disarankan Ganti"
        }

        val accuracy = (50 + (sessions.size * 5)).coerceAtMost(95)

        BatteryHealthReport(
            designCapacityMah = designCapacityMah,
            estimatedCapacityMah = estimatedCapacity,
            healthPercent = healthPercent,
            cycleCount = cycleCount,
            wearLevelPercent = wearLevel,
            condition = condition,
            totalSessionsLearned = sessions.size,
            accuracyScorePercent = accuracy,
            hasSufficientData = true,
            methodLabel = "Metode: Estimasi Sesi Charger"
        )
    }

    suspend fun getLearnedDrainRates(): Pair<Double, Double> = withContext(Dispatchers.IO) {
        val dischargeSessions = getAllSessionsInternal().filter {
            it.sessionType == BatterySessionType.DISCHARGING && it.durationMinutes >= 15 && it.levelDelta > 0
        }

        if (dischargeSessions.isEmpty()) {
            return@withContext Pair(13.5, 0.8) // Default reference rates
        }

        var totalActiveRate = 0.0
        var activeCount = 0
        var totalIdleRate = 0.0
        var idleCount = 0

        for (s in dischargeSessions) {
            val ratePerHour = (s.levelDelta.toDouble() / s.durationMinutes.toDouble()) * 60.0
            if (ratePerHour > 5.0) {
                totalActiveRate += ratePerHour
                activeCount++
            } else if (ratePerHour in 0.2..4.0) {
                totalIdleRate += ratePerHour
                idleCount++
            }
        }

        val finalActive = if (activeCount > 0) totalActiveRate / activeCount else 13.5
        val finalIdle = if (idleCount > 0) totalIdleRate / idleCount else 0.8

        Pair(finalActive, finalIdle)
    }

    private fun getAllSessionsInternal(): List<BatterySessionRecord> {
        val jsonStr = prefs.getString(KEY_SESSIONS_DATA, null) ?: return emptyList()
        val list = mutableListOf<BatterySessionRecord>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val rec = BatterySessionRecord(
                    id = obj.optString("id", "session-$i"),
                    sessionType = BatterySessionType.valueOf(obj.optString("sessionType", "CHARGING")),
                    startTime = obj.optLong("startTime", 0L),
                    endTime = obj.optLong("endTime", 0L),
                    durationMinutes = obj.optInt("durationMinutes", 0),
                    startLevelPercent = obj.optInt("startLevelPercent", 0),
                    endLevelPercent = obj.optInt("endLevelPercent", 0),
                    energyMah = obj.optDouble("energyMah", 0.0),
                    avgCurrentMa = if (obj.has("avgCurrentMa")) obj.optInt("avgCurrentMa") else null,
                    peakTemperatureC = if (obj.has("peakTemperatureC")) obj.optDouble("peakTemperatureC") else null,
                    chargerType = obj.optString("chargerType", null)
                )
                list.add(rec)
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveSessionsInternal(sessions: List<BatterySessionRecord>) {
        try {
            val jsonArray = JSONArray()
            for (s in sessions) {
                val obj = JSONObject().apply {
                    put("id", s.id)
                    put("sessionType", s.sessionType.name)
                    put("startTime", s.startTime)
                    put("endTime", s.endTime)
                    put("durationMinutes", s.durationMinutes)
                    put("startLevelPercent", s.startLevelPercent)
                    put("endLevelPercent", s.endLevelPercent)
                    put("energyMah", s.energyMah)
                    s.avgCurrentMa?.let { put("avgCurrentMa", it) }
                    s.peakTemperatureC?.let { put("peakTemperatureC", it) }
                    s.chargerType?.let { put("chargerType", it) }
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString(KEY_SESSIONS_DATA, jsonArray.toString()).apply()
        } catch (_: Exception) {}
    }
}
