package com.example.rammanager

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.RamOverview
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private var isRequestPermissionListenerRegistered = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        updateShizukuStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            isShizukuActiveState.value = false
            hasPermissionState.value = false
        }
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuCommandRunner.SHIZUKU_PERMISSION_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                runOnUiThread {
                    hasPermissionState.value = granted
                }
                Toast.makeText(
                    this,
                    if (granted) "Izin Shizuku diberikan!" else "Izin Shizuku ditolak.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    private val isShizukuActiveState = mutableStateOf(false)
    private val hasPermissionState = mutableStateOf(false)

    private fun updateShizukuStatus() {
        try {
            val isAvail = ShizukuCommandRunner.isShizukuAvailable()
            val hasPerm = if (isAvail) ShizukuCommandRunner.hasPermission() else false
            runOnUiThread {
                isShizukuActiveState.value = isAvail
                hasPermissionState.value = hasPerm
                if (isAvail && !isRequestPermissionListenerRegistered) {
                    try {
                        Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
                        isRequestPermissionListenerRegistered = true
                    } catch (_: Throwable) {}
                }
            }
        } catch (_: Throwable) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Crash logger: catat traceback ke SharedPreferences jika terjadi unhandled exception
        try {
            val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                try {
                    val sw = java.io.StringWriter()
                    throwable.printStackTrace(java.io.PrintWriter(sw))
                    getSharedPreferences("device_monitor_crash", android.content.Context.MODE_PRIVATE)
                        .edit()
                        .putString("last_crash_log", sw.toString())
                        .commit()
                } catch (_: Throwable) {}
                defaultHandler?.uncaughtException(thread, throwable)
            }
        } catch (_: Throwable) {}

        // Daftarkan listener Shizuku secara aman
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            if (ShizukuCommandRunner.isShizukuAvailable()) {
                Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
                isRequestPermissionListenerRegistered = true
            }
        } catch (e: Throwable) {
            android.util.Log.e("MainActivity", "Catatan inisialisasi Shizuku", e)
        }

        updateShizukuStatus()

        setContent {
            val customDarkColorScheme = darkColorScheme(
                primary = Color(0xFF0284C7),
                onPrimary = Color.White,
                primaryContainer = Color(0xFF0C4A6E),
                onPrimaryContainer = Color(0xFFE0F2FE),
                secondary = Color(0xFF38BDF8),
                onSecondary = Color(0xFF0F172A),
                background = Color(0xFF0B101B),
                onBackground = Color(0xFFF1F5F9),
                surface = Color(0xFF141B27),
                onSurface = Color.White,
                surfaceVariant = Color(0xFF1E293B),
                onSurfaceVariant = Color(0xFFCBD5E1),
                outline = Color(0xFF334155),
                error = Color(0xFFEF4444)
            )

            val prefs = remember { getSharedPreferences("device_monitor_crash", android.content.Context.MODE_PRIVATE) }
            var crashLog by remember { mutableStateOf(prefs.getString("last_crash_log", null)) }

            MaterialTheme(colorScheme = customDarkColorScheme) {
                if (crashLog != null) {
                    AlertDialog(
                        onDismissRequest = {
                            prefs.edit().remove("last_crash_log").apply()
                            crashLog = null
                        },
                        title = {
                            Text("Log Kesalahan", color = Color(0xFFEF4444), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        },
                        text = {
                            Column {
                                Text("Aplikasi mendeteksi error pada sesi sebelumnya:", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 180.dp)
                                        .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
                                        .padding(8.dp)
                                ) {
                                    Text(crashLog ?: "", color = Color(0xFFFCA5A5), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                    cm?.setPrimaryClip(android.content.ClipData.newPlainText("Crash Log", crashLog))
                                    Toast.makeText(this@MainActivity, "Log error disalin!", Toast.LENGTH_SHORT).show()
                                    prefs.edit().remove("last_crash_log").apply()
                                    crashLog = null
                                }
                            ) {
                                Text("Salin & Tutup")
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = {
                                    prefs.edit().remove("last_crash_log").apply()
                                    crashLog = null
                                }
                            ) {
                                Text("Tutup", color = Color(0xFF94A3B8))
                            }
                        }
                    )
                }

                DeviceMonitorMainApp(
                    isShizukuActive = isShizukuActiveState.value,
                    hasShizukuPermission = hasPermissionState.value,
                    onRequestPermission = { ShizukuCommandRunner.requestPermission() },
                    onKeepScreenOn = { keepOn ->
                        if (keepOn) {
                            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        } else {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
        } catch (_: Throwable) {}
        try {
            Shizuku.removeBinderDeadListener(binderDeadListener)
        } catch (_: Throwable) {}
        try {
            if (isRequestPermissionListenerRegistered) {
                Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
            }
        } catch (_: Throwable) {}
    }
}

enum class NavigationTab(val labelRes: Int) {
    RAM(R.string.tab_ram),
    BATTERY(R.string.tab_battery),
    BENCHMARK(R.string.tab_benchmark),
    DEVICE(R.string.tab_device_info),
    MORE(R.string.tab_more)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceMonitorMainApp(
    isShizukuActive: Boolean,
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit,
    onKeepScreenOn: (Boolean) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var currentTab by remember { mutableStateOf(NavigationTab.RAM) }
    var ramOverview by remember { mutableStateOf<RamOverview?>(null) }
    var processes by remember { mutableStateOf<List<AppProcessInfo>>(emptyList()) }
    var isLoadingRam by remember { mutableStateOf(false) }

    fun refreshRam() {
        scope.launch {
            isLoadingRam = true
            try {
                val pair = ShizukuCommandRunner.fetchMemoryInfo(context)
                ramOverview = pair.first
                processes = pair.second
            } catch (_: Exception) {}
            isLoadingRam = false
        }
    }

    LaunchedEffect(hasShizukuPermission) {
        refreshRam()
    }

    val deviceTitle = remember {
        "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = deviceTitle,
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                },
                actions = {
                    if (currentTab == NavigationTab.RAM) {
                        IconButton(onClick = { refreshRam() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color(0xFF38BDF8))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F172A),
                tonalElevation = 6.dp
            ) {
                NavigationTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            val icon = when (tab) {
                                NavigationTab.RAM -> if (isSelected) Icons.Filled.Memory else Icons.Outlined.Memory
                                NavigationTab.BATTERY -> if (isSelected) Icons.Filled.BatteryChargingFull else Icons.Outlined.BatteryChargingFull
                                NavigationTab.BENCHMARK -> if (isSelected) Icons.Filled.Speed else Icons.Outlined.Speed
                                NavigationTab.DEVICE -> if (isSelected) Icons.Filled.PhoneAndroid else Icons.Outlined.PhoneAndroid
                                NavigationTab.MORE -> if (isSelected) Icons.Filled.MoreHoriz else Icons.Outlined.MoreHoriz
                            }
                            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
                        },
                        label = {
                            Text(
                                text = stringResource(tab.labelRes),
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF38BDF8),
                            selectedTextColor = Color(0xFF38BDF8),
                            unselectedIconColor = Color(0xFF64748B),
                            unselectedTextColor = Color(0xFF64748B),
                            indicatorColor = Color(0xFF1E293B)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF0B101B)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                NavigationTab.RAM -> {
                    RamScreen(
                        isShizukuActive = isShizukuActive,
                        hasShizukuPermission = hasShizukuPermission,
                        onRequestPermission = onRequestPermission,
                        ramOverview = ramOverview,
                        processes = processes,
                        isLoading = isLoadingRam,
                        onRefresh = { refreshRam() }
                    )
                }
                NavigationTab.BATTERY -> {
                    BatteryScreen(
                        hasShizukuPermission = hasShizukuPermission,
                        onRefresh = { refreshRam() }
                    )
                }
                NavigationTab.BENCHMARK -> {
                    BenchmarkScreen(
                        onBenchmarkStateChange = { isRunning ->
                            onKeepScreenOn(isRunning)
                        }
                    )
                }
                NavigationTab.DEVICE -> {
                    DeviceInfoScreen(hasShizukuPermission = hasShizukuPermission)
                }
                NavigationTab.MORE -> {
                    MoreScreen(
                        hasShizukuPermission = hasShizukuPermission,
                        onRequestPermission = onRequestPermission
                    )
                }
            }
        }
    }
}
