package com.example.rammanager

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.RamOverview
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun attachBaseContext(newBase: Context) {
        val lang = try {
            newBase.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                .getString("app_language", "SYSTEM") ?: "SYSTEM"
        } catch (_: Throwable) {
            "SYSTEM"
        }
        if (lang == "id" || lang == "en") {
            val locale = Locale(lang)
            Locale.setDefault(locale)
            val config = Configuration(newBase.resources.configuration)
            config.setLocale(locale)
            super.attachBaseContext(newBase.createConfigurationContext(config))
        } else {
            super.attachBaseContext(newBase)
        }
    }

    private var isRequestPermissionListenerRegistered = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        updateShizukuStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            isShizukuActiveState.value = false
            hasPermissionState.value = false
        }
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuCommandRunner.SHIZUKU_PERMISSION_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                runOnUiThread {
                    hasPermissionState.value = granted
                    Toast.makeText(
                        this@MainActivity,
                        if (granted) "Izin Shizuku diberikan!" else "Izin Shizuku ditolak.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

    private val isShizukuActiveState = mutableStateOf(false)
    private val hasPermissionState = mutableStateOf(false)

    private fun updateShizukuStatus() {
        try {
            val isAvail = ShizukuCommandRunner.isShizukuAvailable()
            val hasPerm = if (isAvail) ShizukuCommandRunner.hasPermission() else false
            runOnUiThread {
                isShizukuActiveState.value = isAvail
                hasPermissionState.value = hasPerm
                if (isAvail && !isRequestPermissionListenerRegistered) {
                    try {
                        Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
                        isRequestPermissionListenerRegistered = true
                    } catch (_: Throwable) {}
                }
            }
        } catch (_: Throwable) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        // Daftarkan listener Shizuku secara aman
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            if (ShizukuCommandRunner.isShizukuAvailable()) {
                Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
                isRequestPermissionListenerRegistered = true
            }
        } catch (e: Throwable) {
            Log.e("MainActivity", "Catatan inisialisasi Shizuku", e)
        }

        updateShizukuStatus()

        setContent {
            val customDarkColorScheme = darkColorScheme(
                primary = Color(0xFF0284C7),
                onPrimary = Color.White,
                primaryContainer = Color(0xFF0C4A6E),
                onPrimaryContainer = Color(0xFFE0F2FE),
                secondary = Color(0xFF38BDF8),
                onSecondary = Color(0xFF0F172A),
                background = Color(0xFF0B101B),
                onBackground = Color(0xFFF1F5F9),
                surface = Color(0xFF141B27),
                onSurface = Color.White,
                surfaceVariant = Color(0xFF1E293B),
                onSurfaceVariant = Color(0xFFCBD5E1),
                outline = Color(0xFF334155),
                error = Color(0xFFEF4444)
            )

            var themeMode by remember {
                mutableStateOf(
                    try {
                        getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                            .getString("theme_mode", "SYSTEM") ?: "SYSTEM"
                    } catch (_: Throwable) {
                        "SYSTEM"
                    }
                )
            }

            var crashLog by remember {
                mutableStateOf(
                    if (DeviceMonitorApp.hasUnseenCrash(this@MainActivity)) {
                        DeviceMonitorApp.readCrashLog(this@MainActivity)
                    } else {
                        null
                    }
                )
            }

            MaterialTheme(colorScheme = customDarkColorScheme) {
                if (crashLog != null) {
                    AlertDialog(
                        onDismissRequest = {
                            DeviceMonitorApp.markCrashSeen(this@MainActivity)
                            crashLog = null
                        },
                        title = {
                            Text("Log Kesalahan", color = Color(0xFFEF4444), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        },
                        text = {
                            Column {
                                Text("Aplikasi mendeteksi error pada sesi sebelumnya:", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 180.dp)
                                        .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
                                        .padding(8.dp)
                                ) {
                                    Text(crashLog ?: "", color = Color(0xFFFCA5A5), fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    cm?.setPrimaryClip(ClipData.newPlainText("Crash Log", crashLog))
                                    Toast.makeText(this@MainActivity, "Log error disalin!", Toast.LENGTH_SHORT).show()
                                    DeviceMonitorApp.markCrashSeen(this@MainActivity)
                                    crashLog = null
                                }
                            ) {
                                Text("Salin & Tutup")
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = {
                                    DeviceMonitorApp.markCrashSeen(this@MainActivity)
                                    crashLog = null
                                }
                            ) {
                                Text("Tutup", color = Color(0xFF94A3B8))
                            }
                        }
                    )
                }

                DeviceMonitorMainApp(
                    isShizukuActive = isShizukuActiveState.value,
                    hasShizukuPermission = hasPermissionState.value,
                    themeMode = themeMode,
                    onThemeModeChange = { newMode -> themeMode = newMode },
                    onRequestPermission = { ShizukuCommandRunner.requestPermission() },
                    onKeepScreenOn = { keepOn ->
                        if (keepOn) {
                            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        } else {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
        } catch (_: Throwable) {}
        try {
            Shizuku.removeBinderDeadListener(binderDeadListener)
        } catch (_: Throwable) {}
        try {
            if (isRequestPermissionListenerRegistered) {
                Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
            }
        } catch (_: Throwable) {}
    }
}

enum class NavigationTab(val labelRes: Int) {
    RAM(R.string.tab_ram),
    BATTERY(R.string.tab_battery),
    BENCHMARK(R.string.tab_benchmark),
    DEVICE(R.string.tab_device_info),
    MORE(R.string.tab_more)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceMonitorMainApp(
    isShizukuActive: Boolean,
    hasShizukuPermission: Boolean,
    themeMode: String = "SYSTEM",
    onThemeModeChange: (String) -> Unit = {},
    onRequestPermission: () -> Unit,
    onKeepScreenOn: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var currentTab by remember { mutableStateOf(NavigationTab.RAM) }
    var ramOverview by remember { mutableStateOf<RamOverview?>(null) }
    var processes by remember { mutableStateOf<List<AppProcessInfo>>(emptyList()) }
    var isLoadingRam by remember { mutableStateOf(false) }

    var pollingIntervalSec by remember {
        mutableStateOf(
            try {
                context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                    .getInt("polling_interval_seconds", 5)
                    .coerceAtLeast(5)
            } catch (_: Throwable) {
                5
            }
        )
    }

    suspend fun refreshRamSuspend() {
        if (isLoadingRam) return
        isLoadingRam = true
        try {
            val pair = ShizukuCommandRunner.fetchMemoryInfo(context)
            ramOverview = pair.first
            processes = pair.second

            val prefs = context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
            if (prefs.getBoolean("auto_clean_enabled", false) && hasShizukuPermission) {
                val overview = pair.first
                if (overview.totalRamMb > 0L) {
                    val freePct = ((overview.freeRamMb * 100L) / overview.totalRamMb).toInt()
                    val thresholdPct = prefs.getInt("auto_clean_threshold_pct", 15)
                    val nowMs = System.currentTimeMillis()
                    val lastRunMs = prefs.getLong("auto_clean_last_run_ms", 0L)
                    if (freePct < thresholdPct && (nowMs - lastRunMs >= 10 * 60 * 1000L)) {
                        prefs.edit().putLong("auto_clean_last_run_ms", nowMs).apply()
                        val cleanRes = ShizukuCommandRunner.runQuickClean(context)
                        if (cleanRes.stoppedCount > 0) {
                            val updated = ShizukuCommandRunner.fetchMemoryInfo(context)
                            ramOverview = updated.first
                            processes = updated.second
                        }
                    }
                }
            }
        } catch (_: Throwable) {}
        isLoadingRam = false
    }

    fun refreshRam() {
        scope.launch {
            refreshRamSuspend()
        }
    }

    LaunchedEffect(currentTab, hasShizukuPermission, pollingIntervalSec, lifecycleOwner) {
        if (currentTab == NavigationTab.RAM) {
            lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    refreshRamSuspend()
                    delay(pollingIntervalSec * 1000L)
                }
            }
        }
    }

    val deviceTitle = remember {
        "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = deviceTitle,
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                },
                actions = {
                    if (currentTab == NavigationTab.RAM) {
                        IconButton(onClick = { refreshRam() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color(0xFF38BDF8))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F172A),
                tonalElevation = 6.dp
            ) {
                NavigationTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            val icon = when (tab) {
                                NavigationTab.RAM -> if (isSelected) Icons.Filled.Memory else Icons.Outlined.Memory
                                NavigationTab.BATTERY -> if (isSelected) Icons.Filled.BatteryChargingFull else Icons.Outlined.BatteryChargingFull
                                NavigationTab.BENCHMARK -> if (isSelected) Icons.Filled.Speed else Icons.Outlined.Speed
                                NavigationTab.DEVICE -> if (isSelected) Icons.Filled.PhoneAndroid else Icons.Outlined.PhoneAndroid
                                NavigationTab.MORE -> if (isSelected) Icons.Filled.MoreHoriz else Icons.Outlined.MoreHoriz
                            }
                            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
                        },
                        label = {
                            Text(
                                text = stringResource(tab.labelRes),
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF38BDF8),
                            selectedTextColor = Color(0xFF38BDF8),
                            unselectedIconColor = Color(0xFF64748B),
                            unselectedTextColor = Color(0xFF64748B),
                            indicatorColor = Color(0xFF1E293B)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF0B101B)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentTab, label = "TabCrossfade") { tab ->
                when (tab) {
                    NavigationTab.RAM -> {
                        RamScreen(
                            isShizukuActive = isShizukuActive,
                            hasShizukuPermission = hasShizukuPermission,
                            onRequestPermission = onRequestPermission,
                            ramOverview = ramOverview,
                            processes = processes,
                            isLoading = isLoadingRam,
                            onRefresh = { refreshRam() }
                        )
                    }
                    NavigationTab.BATTERY -> {
                        BatteryScreen(
                            hasShizukuPermission = hasShizukuPermission,
                            pollingIntervalSec = pollingIntervalSec,
                            onRefresh = { refreshRam() }
                        )
                    }
                    NavigationTab.BENCHMARK -> {
                        BenchmarkScreen(
                            onBenchmarkStateChange = { isRunning ->
                                onKeepScreenOn(isRunning)
                            }
                        )
                    }
                    NavigationTab.DEVICE -> {
                        DeviceInfoScreen(hasShizukuPermission = hasShizukuPermission)
                    }
                    NavigationTab.MORE -> {
                        MoreScreen(
                            hasShizukuPermission = hasShizukuPermission,
                            pollingIntervalSec = pollingIntervalSec,
                            onPollingIntervalChange = { newSec -> pollingIntervalSec = newSec },
                            themeMode = themeMode,
                            onThemeModeChange = onThemeModeChange,
                            onRequestPermission = onRequestPermission
                        )
                    }
                }
            }
        }
    }
}
