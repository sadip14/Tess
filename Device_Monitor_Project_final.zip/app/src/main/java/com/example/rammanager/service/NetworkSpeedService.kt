package com.example.rammanager.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.rammanager.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Lightweight, battery-efficient Foreground Service.
 * Tracks real-time network traffic via Android TrafficStats and displays
 * current download & upload speeds in the notification bar.
 */
class NetworkSpeedService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var lastRxBytes: Long = -1L
    private var lastTxBytes: Long = -1L

    companion object {
        const val CHANNEL_ID = "channel_network_speed_meter"
        const val NOTIFICATION_ID = 3001

        const val ACTION_START_SERVICE = "com.example.rammanager.action.START_NETWORK_SPEED"
        const val ACTION_STOP_SERVICE = "com.example.rammanager.action.STOP_NETWORK_SPEED"

        const val PREFS_NETWORK_SPEED = "device_monitor_network_speed_prefs"
        const val KEY_SPEED_METER_ENABLED = "key_network_speed_meter_enabled"

        fun startService(context: Context) {
            context.getSharedPreferences(PREFS_NETWORK_SPEED, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_SPEED_METER_ENABLED, true).apply()

            val intent = Intent(context, NetworkSpeedService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            context.getSharedPreferences(PREFS_NETWORK_SPEED, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_SPEED_METER_ENABLED, false).apply()

            val intent = Intent(context, NetworkSpeedService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.stopService(intent)
        }

        fun isServiceEnabled(context: Context): Boolean {
            return context.getSharedPreferences(PREFS_NETWORK_SPEED, Context.MODE_PRIVATE)
                .getBoolean(KEY_SPEED_METER_ENABLED, false)
        }
    }

    private var lastNotifiedText: String = ""
    private var powerManager: android.os.PowerManager? = null

    override fun onCreate() {
        super.onCreate()
        powerManager = getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        createNotificationChannel()
        val initialText = "↓ 0 KB/s   ↑ 0 KB/s"
        startForeground(NOTIFICATION_ID, buildSpeedNotification(initialText))
        lastNotifiedText = initialText
        startSpeedMonitoring()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startSpeedMonitoring() {
        serviceScope.launch {
            lastRxBytes = TrafficStats.getTotalRxBytes()
            lastTxBytes = TrafficStats.getTotalTxBytes()

            while (isActive) {
                delay(1000L)

                val currentRx = TrafficStats.getTotalRxBytes()
                val currentTx = TrafficStats.getTotalTxBytes()

                if (lastRxBytes >= 0 && lastTxBytes >= 0) {
                    val rxDelta = if (currentRx >= lastRxBytes) currentRx - lastRxBytes else 0L
                    val txDelta = if (currentTx >= lastTxBytes) currentTx - lastTxBytes else 0L

                    val rxSpeed = formatSpeed(rxDelta)
                    val txSpeed = formatSpeed(txDelta)
                    val speedText = "↓ $rxSpeed   ↑ $txSpeed"

                    // Only update notification when screen is on (interactive) and text has changed
                    val isScreenOn = powerManager?.isInteractive ?: true
                    if (isScreenOn && speedText != lastNotifiedText) {
                        updateNotification(speedText)
                        lastNotifiedText = speedText
                    }
                }

                lastRxBytes = currentRx
                lastTxBytes = currentTx
            }
        }
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        return when {
            bytesPerSec >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytesPerSec / (1024.0 * 1024.0))
            bytesPerSec >= 1024 -> String.format(Locale.US, "%.1f KB/s", bytesPerSec / 1024.0)
            else -> "$bytesPerSec B/s"
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Kecepatan Jaringan Real-Time",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menampilkan kecepatan unduh dan unggah jaringan di status bar"
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(speedText: String) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildSpeedNotification(speedText))
        } catch (_: Throwable) {}
    }

    private fun buildSpeedNotification(speedText: String): Notification {
        val tapIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(speedText)
            .setContentText("Device Monitor • Kecepatan Internet Real-Time")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }
}
