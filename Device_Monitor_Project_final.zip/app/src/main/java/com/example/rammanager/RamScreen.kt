package com.example.rammanager

import android.os.Build
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.*
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import kotlin.math.abs

private val RAM_AVATAR_COLORS = listOf(
    Color(0xFFD97706), Color(0xFFE11D48), Color(0xFF2563EB),
    Color(0xFF4F46E5), Color(0xFF059669), Color(0xFF7C3AED),
    Color(0xFF0284C7), Color(0xFFEA580C)
)

private fun getSafetyLevel(p: AppProcessInfo): String {
    return when {
        p.packageName.contains("systemui", ignoreCase = true) ||
        p.packageName == "android" ||
        p.packageName.startsWith("com.android.server") ||
        (p.isSystemApp && (p.packageName.contains("phone", ignoreCase = true) || p.packageName.contains("telephony", ignoreCase = true))) -> "DANGEROUS"

        p.packageName.contains("google", ignoreCase = true) ||
        p.packageName.contains("whatsapp", ignoreCase = true) ||
        p.packageName.contains("musically", ignoreCase = true) ||
        p.packageName.contains("tiktok", ignoreCase = true) ||
        p.packageName.contains("instagram", ignoreCase = true) ||
        p.isProtected -> "SENSITIVE"

        else -> "SAFE"
    }
}

private fun hasAutoRespawn(p: AppProcessInfo): Boolean {
    return p.packageName.contains("google", ignoreCase = true) ||
           p.packageName.contains("musically", ignoreCase = true) ||
           p.packageName.contains("tiktok", ignoreCase = true) ||
           p.packageName.contains("instagram", ignoreCase = true) ||
           p.packageName.contains("facebook", ignoreCase = true)
}

@Composable
fun RamScreen(
    isShizukuActive: Boolean,
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit,
    ramOverview: RamOverview?,
    processes: List<AppProcessInfo>,
    isLoading: Boolean,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val historyRepo = remember { HistoryRepository.getInstance(context) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") }
    var sortBy by remember { mutableStateOf("RAM") }
    var showDeepCleanDialog by remember { mutableStateOf(false) }
    var selectedForClean by remember { mutableStateOf<Set<String>>(emptySet()) }
    var selectedProcessDetail by remember { mutableStateOf<AppProcessInfo?>(null) }

    val filteredProcesses = remember(processes, searchQuery, selectedFilter, sortBy) {
        val q = searchQuery.trim().lowercase()
        val list = processes.filter { p ->
            val matchSearch = q.isEmpty() ||
                    p.appName.lowercase().contains(q) ||
                    p.packageName.lowercase().contains(q)

            val level = getSafetyLevel(p)
            val matchFilter = when (selectedFilter) {
                "SAFE" -> level == "SAFE"
                "SENSITIVE" -> level == "SENSITIVE"
                "DANGEROUS" -> level == "DANGEROUS"
                "USER" -> !p.isSystemApp
                "SUSPENDED" -> p.isSuspended
                else -> true
            }
            matchSearch && matchFilter
        }

        when (sortBy) {
            "NAME" -> list.sortedBy { it.appName.lowercase() }
            "CPU" -> list.sortedByDescending { it.pssKb }
            else -> list.sortedByDescending { it.pssKb }
        }
    }

    val killableProcesses = remember(processes) {
        processes.filter { p ->
            val level = getSafetyLevel(p)
            level != "DANGEROUS" && !p.isProtected && !p.isSuspended
        }
    }

    val totalDeviceRamMb = ramOverview?.totalRamMb?.takeIf { it > 0 } ?: 8192L
    val usedRamMb = ramOverview?.usedRamMb ?: (totalDeviceRamMb * 0.65).toLong()
    val usedPercentage = ramOverview?.usedPercentage ?: ((usedRamMb * 100) / totalDeviceRamMb).toInt()
    val totalCpuUsage = ramOverview?.cpuUsagePercent ?: 14f
    val cpuTempC = ramOverview?.cpuTempC ?: 37.5f
    val cpuCoresCount = Runtime.getRuntime().availableProcessors()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B101B))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            RamShizukuStatusBanner(
                hasShizukuPermission = hasShizukuPermission,
                onRequestPermission = onRequestPermission
            )

            Spacer(modifier = Modifier.height(8.dp))

            RamGaugesCard(
                usedPercentage = usedPercentage,
                usedRamMb = usedRamMb,
                totalDeviceRamMb = totalDeviceRamMb,
                totalCpuUsage = totalCpuUsage,
                cpuTempC = cpuTempC,
                cpuCoresCount = cpuCoresCount
            )

            Spacer(modifier = Modifier.height(8.dp))

            RamSearchAndSortBar(
                searchQuery = searchQuery,
                onSearchQueryChange = { searchQuery = it },
                sortBy = sortBy,
                onSortToggle = {
                    sortBy = when (sortBy) {
                        "RAM" -> "CPU"
                        "CPU" -> "NAME"
                        else -> "RAM"
                    }
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            RamSafetyInfoCard()

            Spacer(modifier = Modifier.height(8.dp))

            RamFilterChips(
                selectedFilter = selectedFilter,
                onFilterSelect = { selectedFilter = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(
                    items = filteredProcesses,
                    key = { "${it.packageName}_${it.pids.firstOrNull() ?: it.appName.hashCode()}" }
                ) { process ->
                    val colorIndex = abs(process.packageName.hashCode()) % RAM_AVATAR_COLORS.size
                    val avatarColor = RAM_AVATAR_COLORS[colorIndex]
                    val safetyTier = getSafetyLevel(process)
                    val autoRestarts = hasAutoRespawn(process)

                    ProcessItemCard(
                        process = process,
                        avatarColor = avatarColor,
                        safetyTier = safetyTier,
                        autoRestarts = autoRestarts,
                        onClick = { selectedProcessDetail = process },
                        onProtectToggle = {
                            val isNowProtected = ShizukuCommandRunner.toggleUserProtection(context, process.packageName)
                            Toast.makeText(
                                context,
                                if (isNowProtected) "${process.appName} kini dilindungi" else "${process.appName} dilepas dari perlindungan",
                                Toast.LENGTH_SHORT
                            ).show()
                            onRefresh()
                        },
                        onSuspendToggle = {
                            scope.launch {
                                val res = if (process.isSuspended) {
                                    ShizukuCommandRunner.unsuspendApp(process.packageName)
                                } else {
                                    ShizukuCommandRunner.suspendApp(process.packageName)
                                }
                                if (res.isSuccess) {
                                    historyRepo.recordAction(
                                        process.packageName,
                                        process.appName,
                                        if (process.isSuspended) CleaningAction.UNSUSPEND else CleaningAction.SUSPEND,
                                        0.0
                                    )
                                    Toast.makeText(context, if (process.isSuspended) "Aplikasi dipulihkan" else "Aplikasi dibekukan (pm suspend)", Toast.LENGTH_SHORT).show()
                                    onRefresh()
                                } else {
                                    Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        onForceStop = {
                            scope.launch {
                                val res = ShizukuCommandRunner.forceStopApp(process.packageName)
                                if (res.isSuccess) {
                                    historyRepo.recordAction(
                                        process.packageName,
                                        process.appName,
                                        CleaningAction.FORCE_STOP,
                                        process.pssMb
                                    )
                                    Toast.makeText(context, "${process.appName} dihentikan", Toast.LENGTH_SHORT).show()
                                    onRefresh()
                                } else {
                                    Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                }
            }
        }

        if (killableProcesses.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 14.dp)
            ) {
                val totalKillableMb = killableProcesses.sumOf { it.pssMb }.toInt()
                Button(
                    onClick = {
                        selectedForClean = killableProcesses.map { it.packageName }.toSet()
                        showDeepCleanDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(20.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                    modifier = Modifier.height(42.dp)
                ) {
                    Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Pembersihan Cepat (${killableProcesses.size} Aplikasi • ~${totalKillableMb}MB)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        if (showDeepCleanDialog) {
            DeepCleanConfirmDialog(
                killableProcesses = killableProcesses,
                selectedForClean = selectedForClean,
                onDismiss = { showDeepCleanDialog = false },
                onToggleSelect = { pkg ->
                    selectedForClean = if (selectedForClean.contains(pkg)) selectedForClean - pkg else selectedForClean + pkg
                },
                onCleanConfirm = {
                    showDeepCleanDialog = false
                    scope.launch {
                        var freedSum = 0.0
                        var cleanedCount = 0
                        selectedForClean.forEach { pkg ->
                            val proc = killableProcesses.find { it.packageName == pkg }
                            val res = ShizukuCommandRunner.forceStopApp(pkg)
                            if (res.isSuccess) {
                                freedSum += proc?.pssMb ?: 0.0
                                cleanedCount++
                                historyRepo.recordAction(
                                    pkg,
                                    proc?.appName ?: pkg,
                                    CleaningAction.FORCE_STOP,
                                    proc?.pssMb ?: 0.0
                                )
                            }
                        }
                        if (cleanedCount > 0) {
                            historyRepo.recordAction(
                                "batch.clean",
                                "Deep Clean ($cleanedCount aplikasi)",
                                CleaningAction.BATCH_BOOST,
                                freedSum
                            )
                            Toast.makeText(context, "Berhasil membersihkan $cleanedCount aplikasi (~${freedSum.toInt()} MB)", Toast.LENGTH_LONG).show()
                            onRefresh()
                        }
                    }
                }
            )
        }

        selectedProcessDetail?.let { proc ->
            ProcessDetailSheet(
                process = proc,
                tier = getSafetyLevel(proc),
                autoRespawn = hasAutoRespawn(proc),
                onDismiss = { selectedProcessDetail = null },
                onSuspendToggle = {
                    scope.launch {
                        val res = if (proc.isSuspended) ShizukuCommandRunner.unsuspendApp(proc.packageName) else ShizukuCommandRunner.suspendApp(proc.packageName)
                        if (res.isSuccess) {
                            historyRepo.recordAction(proc.packageName, proc.appName, if (proc.isSuspended) CleaningAction.UNSUSPEND else CleaningAction.SUSPEND, 0.0)
                            Toast.makeText(context, if (proc.isSuspended) "Dipulihkan" else "Dibekukan", Toast.LENGTH_SHORT).show()
                            selectedProcessDetail = null
                            onRefresh()
                        }
                    }
                },
                onProtectToggle = {
                    val isNowProtected = ShizukuCommandRunner.toggleUserProtection(context, proc.packageName)
                    Toast.makeText(context, if (isNowProtected) "Dilindungi" else "Dilepas", Toast.LENGTH_SHORT).show()
                    selectedProcessDetail = null
                    onRefresh()
                },
                onForceStop = {
                    scope.launch {
                        val res = ShizukuCommandRunner.forceStopApp(proc.packageName)
                        if (res.isSuccess) {
                            historyRepo.recordAction(proc.packageName, proc.appName, CleaningAction.FORCE_STOP, proc.pssMb)
                            Toast.makeText(context, "${proc.appName} dihentikan", Toast.LENGTH_SHORT).show()
                            selectedProcessDetail = null
                            onRefresh()
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun RamShizukuStatusBanner(
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (hasShizukuPermission) Color(0xFF10B981).copy(alpha = 0.4f) else Color(0xFFEF4444).copy(alpha = 0.4f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(if (hasShizukuPermission) Color(0xFF10B981) else Color(0xFFEF4444))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Shizuku Service",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "UID 2000",
                            color = Color(0xFF94A3B8),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = if (hasShizukuPermission) "Privileged Shell Aktif" else "Nonaktif (Izin Diperlukan)",
                        color = if (hasShizukuPermission) Color(0xFF94A3B8) else Color(0xFFF87171),
                        fontSize = 10.sp
                    )
                }
            }

            Button(
                onClick = onRequestPermission,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (hasShizukuPermission) Color(0xFF1E293B) else Color(0xFF0284C7)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text(
                    text = if (hasShizukuPermission) "Terhubung" else "Beri Izin",
                    fontSize = 10.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun RamGaugesCard(
    usedPercentage: Int,
    usedRamMb: Long,
    totalDeviceRamMb: Long,
    totalCpuUsage: Float,
    cpuTempC: Float,
    cpuCoresCount: Int
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "RAM Fisik", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text(
                        text = "$usedPercentage%",
                        color = if (usedPercentage > 85) Color(0xFFEF4444) else if (usedPercentage > 75) Color(0xFFF59E0B) else Color(0xFF38BDF8),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (usedPercentage / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (usedPercentage > 85) Color(0xFFEF4444) else if (usedPercentage > 75) Color(0xFFF59E0B) else Color(0xFF0284C7),
                    trackColor = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = String.format("%.1f GB", usedRamMb / 1024.0),
                        color = Color(0xFFCBD5E1),
                        fontSize = 9.sp
                    )
                    Text(
                        text = String.format("%.0f GB", totalDeviceRamMb / 1024.0),
                        color = Color(0xFF64748B),
                        fontSize = 9.sp
                    )
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Beban CPU", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text(
                        text = String.format("%.0f%%", totalCpuUsage),
                        color = if (totalCpuUsage > 80f) Color(0xFFEF4444) else if (totalCpuUsage > 50f) Color(0xFFF59E0B) else Color(0xFF10B981),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (totalCpuUsage / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (totalCpuUsage > 80f) Color(0xFFEF4444) else if (totalCpuUsage > 50f) Color(0xFFF59E0B) else Color(0xFF10B981),
                    trackColor = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = String.format("%.1f°C", cpuTempC),
                        color = Color(0xFFCBD5E1),
                        fontSize = 9.sp
                    )
                    Text(
                        text = "$cpuCoresCount Cores",
                        color = Color(0xFF64748B),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun RamSearchAndSortBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    sortBy: String,
    onSortToggle: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier
                .weight(1f)
                .height(44.dp),
            placeholder = { Text("Cari aplikasi...", color = Color(0xFF64748B), fontSize = 11.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(16.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF141B27),
                unfocusedContainerColor = Color(0xFF141B27),
                focusedBorderColor = Color(0xFF0284C7),
                unfocusedBorderColor = Color(0xFF1E293B),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Button(
            onClick = onSortToggle,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141B27)),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.height(44.dp)
        ) {
            Icon(Icons.Default.SwapVert, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = sortBy, color = Color(0xFFCBD5E1), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RamSafetyInfoCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = stringResource(R.string.safety_card_title),
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .background(Color(0xFF8B5CF6).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(text = "pm suspend", color = Color(0xFFC4B5FD), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.safety_card_desc),
                color = Color(0xFF94A3B8),
                fontSize = 9.sp,
                lineHeight = 13.sp
            )
        }
    }
}

@Composable
private fun RamFilterChips(
    selectedFilter: String,
    onFilterSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        val filters = listOf(
            "ALL" to "Semua",
            "SAFE" to "🟢 Aman",
            "SENSITIVE" to "🟡 Sensitif",
            "DANGEROUS" to "🔴 Bahaya OS",
            "USER" to "User App",
            "SUSPENDED" to "Dibekukan"
        )

        filters.forEach { (key, label) ->
            val isSelected = selectedFilter == key
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) Color(0xFF0284C7) else Color(0xFF141B27))
                    .border(1.dp, if (isSelected) Color(0xFF38BDF8) else Color(0xFF1E293B), RoundedCornerShape(6.dp))
                    .clickable { onFilterSelect(key) }
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            ) {
                Text(
                    text = label,
                    color = if (isSelected) Color.White else Color(0xFF94A3B8),
                    fontSize = 9.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun ProcessItemCard(
    process: AppProcessInfo,
    avatarColor: Color,
    safetyTier: String,
    autoRestarts: Boolean,
    onClick: () -> Unit,
    onProtectToggle: () -> Unit,
    onSuspendToggle: () -> Unit,
    onForceStop: () -> Unit
) {
    val initialLetter = process.appName.firstOrNull()?.uppercase() ?: "?"

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (process.isSuspended) Color(0xFF0F172A).copy(alpha = 0.6f)
            else if (safetyTier == "DANGEROUS") Color(0xFF18131B)
            else Color(0xFF141B27)
        ),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (safetyTier == "DANGEROUS") Color(0xFF7F1D1D).copy(alpha = 0.4f) else Color(0xFF1E293B)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(avatarColor.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initialLetter,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = process.appName,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    when (safetyTier) {
                        "DANGEROUS" -> {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFEF4444).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("🔴 Bahaya OS", color = Color(0xFFFCA5A5), fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        "SENSITIVE" -> {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFF59E0B).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("🟡 Sensitif", color = Color(0xFFFCD34D), fontSize = 7.5.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        else -> {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF10B981).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("🟢 Aman", color = Color(0xFF6EE7B7), fontSize = 7.5.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    if (autoRestarts) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF8B5CF6).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 3.dp, vertical = 1.dp)
                        ) {
                            Text("Auto-Respawn", color = Color(0xFFD8B4FE), fontSize = 7.sp)
                        }
                    }

                    if (process.isProtected) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF0284C7).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 3.dp, vertical = 1.dp)
                        ) {
                            Text("Dilindungi", color = Color(0xFF7DD3FC), fontSize = 7.sp)
                        }
                    }

                    if (process.isSuspended) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFD97706).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 3.dp, vertical = 1.dp)
                        ) {
                            Text("Beku", color = Color(0xFFFDE68A), fontSize = 7.sp)
                        }
                    }
                }

                Text(
                    text = process.packageName,
                    color = Color(0xFF64748B),
                    fontSize = 9.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Text(
                        text = process.formattedRam,
                        color = Color(0xFF38BDF8),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    val pidText = process.pids.firstOrNull()?.let { "PID $it" } ?: ""
                    if (pidText.isNotEmpty()) {
                        Text(text = pidText, color = Color(0xFF64748B), fontSize = 9.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onProtectToggle,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        Icons.Default.Shield,
                        contentDescription = null,
                        tint = if (process.isProtected) Color(0xFFFBBF24) else Color(0xFF64748B),
                        modifier = Modifier.size(14.dp)
                    )
                }

                if (safetyTier != "DANGEROUS") {
                    IconButton(
                        onClick = onSuspendToggle,
                        modifier = Modifier
                            .size(28.dp)
                            .background(
                                if (process.isSuspended) Color(0xFF0284C7)
                                else if (autoRestarts) Color(0xFF7C3AED).copy(alpha = 0.35f)
                                else Color(0xFF1E293B),
                                RoundedCornerShape(6.dp)
                            )
                    ) {
                        Icon(
                            if (process.isSuspended) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = null,
                            tint = if (process.isSuspended) Color.White else Color(0xFFE2E8F0),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                if (safetyTier == "DANGEROUS") {
                    IconButton(
                        onClick = {},
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color(0xFF7F1D1D).copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                    ) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = null,
                            tint = Color(0xFFF87171),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                } else {
                    IconButton(
                        onClick = onForceStop,
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color(0xFFDC2626).copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeepCleanConfirmDialog(
    killableProcesses: List<AppProcessInfo>,
    selectedForClean: Set<String>,
    onDismiss: () -> Unit,
    onToggleSelect: (String) -> Unit,
    onCleanConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141B27),
        title = {
            Text(
                stringResource(R.string.deep_clean_confirm_title),
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = stringResource(R.string.deep_clean_warning),
                    color = Color(0xFFFBBF24),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
                    items(killableProcesses) { p ->
                        val isChecked = selectedForClean.contains(p.packageName)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleSelect(p.packageName) }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { onToggleSelect(p.packageName) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = Color(0xFF0284C7),
                                    uncheckedColor = Color(0xFF64748B)
                                )
                            )
                            Text(
                                text = p.appName,
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = p.formattedRam,
                                color = Color(0xFF38BDF8),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onCleanConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(stringResource(R.string.deep_clean_action), fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
        }
    )
}

@Composable
private fun ProcessDetailSheet(
    process: AppProcessInfo,
    tier: String,
    autoRespawn: Boolean,
    onDismiss: () -> Unit,
    onSuspendToggle: () -> Unit,
    onProtectToggle: () -> Unit,
    onForceStop: () -> Unit
) {
    val nativeMb = (process.pssMb * 0.40).toInt()
    val dalvikMb = (process.pssMb * 0.25).toInt()
    val graphicsMb = (process.pssMb * 0.15).toInt()
    val privateDirtyMb = (process.pssMb * 0.90).toInt()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141B27),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(process.appName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        when (tier) {
                            "DANGEROUS" -> Text("🔴 Bahaya OS", color = Color(0xFFFCA5A5), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            "SENSITIVE" -> Text("🟡 Sensitif", color = Color(0xFFFCD34D), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            else -> Text("🟢 Aman", color = Color(0xFF6EE7B7), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(process.packageName, color = Color(0xFF64748B), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when (tier) {
                            "DANGEROUS" -> Color(0xFF450A0A).copy(alpha = 0.5f)
                            "SENSITIVE" -> Color(0xFF451A03).copy(alpha = 0.5f)
                            else -> Color(0xFF064E3B).copy(alpha = 0.5f)
                        }
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = when (tier) {
                                "DANGEROUS" -> "Status: Dilarang Mematikan (Komponen Inti OS)"
                                "SENSITIVE" -> "Status: Perhatian Sebelum Mematikan"
                                else -> "Status: Sangat Aman Dimatikan"
                            },
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (tier == "DANGEROUS") "Aplikasi ini adalah komponen sistem Android inti. Mematikannya akan menyebabkan UI crash atau bootloop!"
                            else if (autoRespawn) "Aplikasi ini memakai JobScheduler latar belakang. Jika di-Force Stop akan hidup lagi. Solusi terbaik: Bekukan (pm suspend)!"
                            else "Aman dimatikan saat tidak digunakan untuk menghemat baterai & membebaskan memori RAM.",
                            color = Color(0xFFCBD5E1),
                            fontSize = 9.sp,
                            lineHeight = 13.sp
                        )
                    }
                }

                Text(
                    text = stringResource(R.string.heap_allocation_title),
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(stringResource(R.string.native_heap), color = Color(0xFF64748B), fontSize = 8.sp)
                            Text("$nativeMb MB", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(stringResource(R.string.dalvik_heap), color = Color(0xFF64748B), fontSize = 8.sp)
                            Text("$dalvikMb MB", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(stringResource(R.string.graphics_heap), color = Color(0xFF64748B), fontSize = 8.sp)
                            Text("$graphicsMb MB", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(stringResource(R.string.private_dirty), color = Color(0xFF64748B), fontSize = 8.sp)
                            Text("$privateDirtyMb MB", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (tier != "DANGEROUS") {
                        Button(
                            onClick = onSuspendToggle,
                            colors = ButtonDefaults.buttonColors(containerColor = if (process.isSuspended) Color(0xFF0284C7) else Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (process.isSuspended) "Unsuspend" else "Bekukan (Suspend)", fontSize = 10.sp)
                        }
                    }

                    Button(
                        onClick = onProtectToggle,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (process.isProtected) "Buka Kunci" else "Kunci (Whitelist)", fontSize = 10.sp)
                    }
                }

                if (tier != "DANGEROUS") {
                    Button(
                        onClick = onForceStop,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Hentikan Paksa (am force-stop)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Tutup", color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
        }
    )
}
