package com.example.rammanager

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.RamOverview
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs

private val RAM_AVATAR_COLORS = listOf(
    Color(0xFFD97706), Color(0xFFE11D48), Color(0xFF2563EB),
    Color(0xFF4F46E5), Color(0xFF059669), Color(0xFF7C3AED),
    Color(0xFF0284C7), Color(0xFFEA580C)
)

private fun getSafetyLevel(p: AppProcessInfo): String {
    return when {
        p.packageName.contains("systemui", ignoreCase = true) ||
        p.packageName == "android" ||
        p.packageName.startsWith("com.android.server") ||
        (p.isSystemApp && (p.packageName.contains("phone", ignoreCase = true) || p.packageName.contains("telephony", ignoreCase = true))) -> "DANGEROUS"

        p.packageName.contains("google", ignoreCase = true) ||
        p.packageName.contains("whatsapp", ignoreCase = true) ||
        p.packageName.contains("musically", ignoreCase = true) ||
        p.packageName.contains("tiktok", ignoreCase = true) ||
        p.packageName.contains("instagram", ignoreCase = true) ||
        p.isProtected -> "SENSITIVE"

        else -> "SAFE"
    }
}

private fun hasAutoRespawn(p: AppProcessInfo): Boolean {
    return p.packageName.contains("google", ignoreCase = true) ||
           p.packageName.contains("musically", ignoreCase = true) ||
           p.packageName.contains("tiktok", ignoreCase = true) ||
           p.packageName.contains("instagram", ignoreCase = true) ||
           p.packageName.contains("facebook", ignoreCase = true)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RamScreen(
    isShizukuActive: Boolean,
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit,
    ramOverview: RamOverview?,
    processes: List<AppProcessInfo>,
    isLoading: Boolean,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val historyRepo = remember { HistoryRepository.getInstance(context) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") }
    var sortBy by remember { mutableStateOf("RAM") }
    var showDeepCleanDialog by remember { mutableStateOf(false) }
    var selectedForClean by remember { mutableStateOf<Set<String>>(emptySet()) }
    var selectedProcessDetail by remember { mutableStateOf<AppProcessInfo?>(null) }
    var pendingSuspendProcess by remember { mutableStateOf<AppProcessInfo?>(null) }
    var pendingStopProcess by remember { mutableStateOf<AppProcessInfo?>(null) }
    var isUnsuspendingAll by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val undoLabel = stringResource(R.string.undo)
    val reopenLabel = stringResource(R.string.reopen_app)

    fun executeSuspend(proc: AppProcessInfo) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        scope.launch {
            val res = ShizukuCommandRunner.suspendApp(context, proc.packageName)
            if (res.isSuccess) {
                historyRepo.recordAction(proc.packageName, proc.appName, CleaningAction.SUSPEND, 0.0)
                onRefresh()
                snackbarHostState.currentSnackbarData?.dismiss()
                scope.launch {
                    val dismissJob = launch {
                        delay(9000L)
                        snackbarHostState.currentSnackbarData?.dismiss()
                    }
                    val snackRes = snackbarHostState.showSnackbar(
                        message = "${proc.appName} dibekukan",
                        actionLabel = undoLabel,
                        duration = SnackbarDuration.Indefinite
                    )
                    dismissJob.cancel()
                    if (snackRes == SnackbarResult.ActionPerformed) {
                        val undoRes = ShizukuCommandRunner.unsuspendApp(proc.packageName)
                        if (undoRes.isSuccess) {
                            historyRepo.recordAction(proc.packageName, proc.appName, CleaningAction.UNSUSPEND, 0.0)
                            Toast.makeText(context, "${proc.appName} dipulihkan", Toast.LENGTH_SHORT).show()
                            onRefresh()
                        } else {
                            Toast.makeText(context, "Gagal memulihkan: ${undoRes.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun executeUnsuspend(proc: AppProcessInfo) {
        scope.launch {
            val res = ShizukuCommandRunner.unsuspendApp(proc.packageName)
            if (res.isSuccess) {
                historyRepo.recordAction(proc.packageName, proc.appName, CleaningAction.UNSUSPEND, 0.0)
                Toast.makeText(context, "${proc.appName} dipulihkan", Toast.LENGTH_SHORT).show()
                onRefresh()
            } else {
                Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun executeForceStop(proc: AppProcessInfo) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        scope.launch {
            val res = ShizukuCommandRunner.forceStopApp(context, proc.packageName)
            if (res.isSuccess) {
                historyRepo.recordAction(proc.packageName, proc.appName, CleaningAction.FORCE_STOP, 0.0)
                onRefresh()
                snackbarHostState.currentSnackbarData?.dismiss()
                scope.launch {
                    val dismissJob = launch {
                        delay(9000L)
                        snackbarHostState.currentSnackbarData?.dismiss()
                    }
                    val snackRes = snackbarHostState.showSnackbar(
                        message = "${proc.appName} dihentikan",
                        actionLabel = reopenLabel,
                        duration = SnackbarDuration.Indefinite
                    )
                    dismissJob.cancel()
                    if (snackRes == SnackbarResult.ActionPerformed) {
                        try {
                            val launchIntent = context.packageManager.getLaunchIntentForPackage(proc.packageName)
                            if (launchIntent != null) {
                                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(launchIntent)
                            } else if (ShizukuCommandRunner.isValidPackageName(proc.packageName)) {
                                ShizukuCommandRunner.executeCommand("monkey -p ${proc.packageName} -c android.intent.category.LAUNCHER 1")
                            }
                            onRefresh()
                        } catch (_: Throwable) {}
                    }
                }
            } else {
                Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val suspendedProcesses = remember(processes) {
        processes.filter { it.isSuspended }
    }

    val filteredProcesses = remember(processes, searchQuery, selectedFilter, sortBy) {
        val q = searchQuery.trim().lowercase()
        val list = processes.filter { p ->
            val matchSearch = q.isEmpty() ||
                    p.appName.lowercase().contains(q) ||
                    p.packageName.lowercase().contains(q)

            val level = getSafetyLevel(p)
            val matchFilter = when (selectedFilter) {
                "SAFE" -> level == "SAFE"
                "SENSITIVE" -> level == "SENSITIVE"
                "DANGEROUS" -> level == "DANGEROUS"
                "USER" -> !p.isSystemApp
                "SUSPENDED" -> p.isSuspended
                else -> true
            }
            matchSearch && matchFilter
        }

        when (sortBy) {
            "NAME" -> list.sortedBy { it.appName.lowercase() }
            else -> list.sortedByDescending { it.pssKb }
        }
    }

    val killableProcesses = remember(processes) {
        processes.filter { p ->
            val level = getSafetyLevel(p)
            level != "DANGEROUS" &&
                !p.isProtected &&
                !p.isSystemApp &&
                !p.isSuspended &&
                ShizukuCommandRunner.isSafeQuickCleanCategory(p.oomCategory)
        }
    }

    val totalDeviceRamMb = ramOverview?.totalRamMb?.takeIf { it > 0 }
    val usedRamMb = ramOverview?.usedRamMb
    val usedPercentage = ramOverview?.usedPercentage
    val totalCpuUsage = ramOverview?.cpuUsagePercent
    val cpuTempC = ramOverview?.cpuTempC
    val cpuCoresCount = Runtime.getRuntime().availableProcessors()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B101B))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            RamShizukuStatusBanner(
                hasShizukuPermission = hasShizukuPermission,
                onRequestPermission = onRequestPermission
            )

            if (!isShizukuActive) {
                Spacer(modifier = Modifier.height(8.dp))
                ShizukuOnboardingCard()
            }

            if (suspendedProcesses.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                SuspendedAppsBanner(
                    count = suspendedProcesses.size,
                    isUnsuspendingAll = isUnsuspendingAll,
                    onViewSuspended = { selectedFilter = "SUSPENDED" },
                    onUnsuspendAll = {
                        if (!isUnsuspendingAll) {
                            isUnsuspendingAll = true
                            scope.launch {
                                var okCount = 0
                                for (p in suspendedProcesses) {
                                    val r = ShizukuCommandRunner.unsuspendApp(p.packageName)
                                    if (r.isSuccess) {
                                        okCount++
                                        historyRepo.recordAction(p.packageName, p.appName, CleaningAction.UNSUSPEND, 0.0)
                                    }
                                }
                                isUnsuspendingAll = false
                                Toast.makeText(context, "$okCount/${suspendedProcesses.size} app diaktifkan kembali", Toast.LENGTH_SHORT).show()
                                onRefresh()
                            }
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            RamGaugesCard(
                usedPercentage = usedPercentage,
                usedRamMb = usedRamMb,
                totalDeviceRamMb = totalDeviceRamMb,
                totalCpuUsage = totalCpuUsage,
                cpuTempC = cpuTempC,
                cpuCoresCount = cpuCoresCount
            )

            Spacer(modifier = Modifier.height(8.dp))

            RamSearchAndSortBar(
                searchQuery = searchQuery,
                onSearchQueryChange = { searchQuery = it },
                sortBy = sortBy,
                onSortToggle = {
                    sortBy = if (sortBy == "RAM") "NAME" else "RAM"
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            RamSafetyInfoCard()

            Spacer(modifier = Modifier.height(8.dp))

            RamFilterChips(
                selectedFilter = selectedFilter,
                onFilterSelect = { selectedFilter = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            PullToRefreshBox(
                isRefreshing = isLoading,
                onRefresh = onRefresh,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (filteredProcesses.isEmpty()) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = null,
                                        tint = Color(0xFF64748B),
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = stringResource(R.string.empty_processes_title),
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = stringResource(R.string.empty_processes_desc),
                                        color = Color(0xFF94A3B8),
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    } else {
                        items(
                            items = filteredProcesses,
                            key = { "${it.packageName}_${it.pids.firstOrNull() ?: it.appName.hashCode()}" }
                        ) { process ->
                    val colorIndex = abs(process.packageName.hashCode()) % RAM_AVATAR_COLORS.size
                    val avatarColor = RAM_AVATAR_COLORS[colorIndex]
                    val safetyTier = getSafetyLevel(process)
                    val autoRestarts = hasAutoRespawn(process)

                    ProcessItemCard(
                        process = process,
                        avatarColor = avatarColor,
                        safetyTier = safetyTier,
                        autoRestarts = autoRestarts,
                        onClick = { selectedProcessDetail = process },
                        onProtectToggle = {
                            val builtIn = ShizukuCommandRunner.getBuiltInProtectedReason(context, process.packageName)
                            if (builtIn != null) {
                                Toast.makeText(context, "Dilindungi bawaan: $builtIn", Toast.LENGTH_SHORT).show()
                            } else {
                                val isNowProtected = ShizukuCommandRunner.toggleUserProtection(context, process.packageName)
                                Toast.makeText(
                                    context,
                                    if (isNowProtected) "${process.appName} kini dilindungi" else "${process.appName} dilepas dari perlindungan",
                                    Toast.LENGTH_SHORT
                                ).show()
                                onRefresh()
                            }
                        },
                        onSuspendToggle = {
                            if (process.isProtected) {
                                Toast.makeText(
                                    context,
                                    process.protectionReason.ifEmpty { "Aplikasi dilindungi" },
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else if (process.isSuspended) {
                                executeUnsuspend(process)
                            } else {
                                pendingSuspendProcess = process
                            }
                        },
                        onForceStop = {
                            if (process.isProtected) {
                                Toast.makeText(
                                    context,
                                    process.protectionReason.ifEmpty { "Aplikasi dilindungi" },
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                pendingStopProcess = process
                            }
                        }
                    )
                }
            }
            }
            }
        }

        if (killableProcesses.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 14.dp)
            ) {
                Button(
                    onClick = {
                        selectedForClean = killableProcesses.map { it.packageName }.toSet()
                        showDeepCleanDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(20.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                    modifier = Modifier.height(42.dp)
                ) {
                    Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Pembersihan Cepat (${killableProcesses.size} Aplikasi)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        if (showDeepCleanDialog) {
            DeepCleanConfirmDialog(
                killableProcesses = killableProcesses,
                selectedForClean = selectedForClean,
                onDismiss = { showDeepCleanDialog = false },
                onToggleSelect = { pkg ->
                    selectedForClean = if (selectedForClean.contains(pkg)) selectedForClean - pkg else selectedForClean + pkg
                },
                onCleanConfirm = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    showDeepCleanDialog = false
                    scope.launch {
                        val am = try {
                            context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                        } catch (_: Throwable) {
                            null
                        }
                        val freeBeforeMb = try {
                            val memBefore = ActivityManager.MemoryInfo()
                            am?.getMemoryInfo(memBefore)
                            memBefore.availMem / (1024 * 1024)
                        } catch (_: Throwable) {
                            0L
                        }

                        var cleanedCount = 0
                        val protectedSet = ShizukuCommandRunner.getProtectedPackages(context)
                        selectedForClean.forEach { pkg ->
                            if (protectedSet.contains(pkg)) return@forEach
                            val proc = killableProcesses.find { it.packageName == pkg }
                            if (proc?.isProtected == true) return@forEach
                            val res = ShizukuCommandRunner.forceStopApp(context, pkg)
                            if (res.isSuccess) {
                                cleanedCount++
                            }
                        }

                        // Tunggu ~2 detik untuk pengukuran nyata
                        delay(2000L)

                        val freeAfterMb = try {
                            val memAfter = ActivityManager.MemoryInfo()
                            am?.getMemoryInfo(memAfter)
                            memAfter.availMem / (1024 * 1024)
                        } catch (_: Throwable) {
                            0L
                        }
                        val realDiffMb = (freeAfterMb - freeBeforeMb).coerceAtLeast(0L)

                        if (cleanedCount > 0) {
                            historyRepo.recordAction(
                                "batch.clean",
                                "Pembersihan Cepat ($cleanedCount aplikasi)",
                                CleaningAction.BATCH_BOOST,
                                realDiffMb.toDouble()
                            )
                            Toast.makeText(
                                context,
                                "Selesai: $cleanedCount aplikasi dibersihkan. RAM bebas bertambah ~$realDiffMb MB (perkiraan, bisa naik lagi)",
                                Toast.LENGTH_LONG
                            ).show()
                            onRefresh()
                        } else {
                            Toast.makeText(context, "Tidak ada aplikasi yang dapat dimatikan", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }

        selectedProcessDetail?.let { proc ->
            val builtInReason = remember(proc.packageName) {
                ShizukuCommandRunner.getBuiltInProtectedReason(context, proc.packageName)
            }
            ProcessDetailSheet(
                process = proc,
                tier = getSafetyLevel(proc),
                autoRespawn = hasAutoRespawn(proc),
                isBuiltInProtected = builtInReason != null,
                onDismiss = { selectedProcessDetail = null },
                onSuspendToggle = {
                    selectedProcessDetail = null
                    if (proc.isProtected) {
                        Toast.makeText(context, proc.protectionReason.ifEmpty { "Dilindungi" }, Toast.LENGTH_SHORT).show()
                    } else if (proc.isSuspended) {
                        executeUnsuspend(proc)
                    } else {
                        pendingSuspendProcess = proc
                    }
                },
                onProtectToggle = {
                    if (builtInReason != null) {
                        Toast.makeText(context, "Dilindungi bawaan: $builtInReason", Toast.LENGTH_SHORT).show()
                    } else {
                        val isNowProtected = ShizukuCommandRunner.toggleUserProtection(context, proc.packageName)
                        Toast.makeText(context, if (isNowProtected) "Dilindungi" else "Dilepas", Toast.LENGTH_SHORT).show()
                        selectedProcessDetail = null
                        onRefresh()
                    }
                },
                onForceStop = {
                    selectedProcessDetail = null
                    if (proc.isProtected) {
                        Toast.makeText(context, proc.protectionReason.ifEmpty { "Dilindungi" }, Toast.LENGTH_SHORT).show()
                    } else {
                        pendingStopProcess = proc
                    }
                }
            )
        }

        pendingSuspendProcess?.let { proc ->
            AlertDialog(
                onDismissRequest = { pendingSuspendProcess = null },
                containerColor = Color(0xFF141B27),
                title = {
                    Text(
                        text = stringResource(R.string.confirm_suspend_title),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = stringResource(R.string.confirm_suspend_msg, proc.appName, proc.packageName),
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val target = proc
                            pendingSuspendProcess = null
                            executeSuspend(target)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(stringResource(R.string.suspend), fontSize = 11.sp)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingSuspendProcess = null }) {
                        Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 11.sp)
                    }
                }
            )
        }

        pendingStopProcess?.let { proc ->
            AlertDialog(
                onDismissRequest = { pendingStopProcess = null },
                containerColor = Color(0xFF141B27),
                title = {
                    Text(
                        text = stringResource(R.string.confirm_stop_title),
                        color = Color(0xFFF87171),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = stringResource(R.string.confirm_stop_system_msg, proc.appName, proc.packageName),
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val target = proc
                            pendingStopProcess = null
                            executeForceStop(target)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(stringResource(R.string.force_stop), fontSize = 11.sp)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingStopProcess = null }) {
                        Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 11.sp)
                    }
                }
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 64.dp, start = 12.dp, end = 12.dp)
        )
    }
}

@Composable
private fun ShizukuOnboardingCard() {
    val context = LocalContext.current
    val isShizukuInstalled = remember {
        try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (_: Throwable) {
            false
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFF0284C7).copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = stringResource(R.string.shizuku_onboarding_title),
                color = Color(0xFF38BDF8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(stringResource(R.string.shizuku_step_1), color = Color(0xFFCBD5E1), fontSize = 9.5.sp, lineHeight = 13.sp)
            Text(stringResource(R.string.shizuku_step_2), color = Color(0xFFCBD5E1), fontSize = 9.5.sp, lineHeight = 13.sp)
            Text(stringResource(R.string.shizuku_step_3), color = Color(0xFFCBD5E1), fontSize = 9.5.sp, lineHeight = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        try {
                            val devIntent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(devIntent)
                        } catch (_: Throwable) {
                            try {
                                context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (_: Throwable) {}
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 36.dp)
                ) {
                    Text(stringResource(R.string.open_developer_options), fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                }

                if (isShizukuInstalled) {
                    OutlinedButton(
                        onClick = {
                            try {
                                val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                                if (launchIntent != null) {
                                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(launchIntent)
                                }
                            } catch (_: Throwable) {}
                        },
                        border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 36.dp)
                    ) {
                        Text(stringResource(R.string.open_shizuku), color = Color(0xFF38BDF8), fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SuspendedAppsBanner(
    count: Int,
    isUnsuspendingAll: Boolean,
    onViewSuspended: () -> Unit,
    onUnsuspendAll: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B2E)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    Icons.Default.PauseCircle,
                    contentDescription = null,
                    tint = Color(0xFFC4B5FD),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.suspended_banner_count, count),
                    color = Color.White,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = onViewSuspended,
                    border = BorderStroke(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.heightIn(min = 32.dp)
                ) {
                    Text(stringResource(R.string.view), color = Color(0xFFD8B4FE), fontSize = 10.sp)
                }

                Button(
                    onClick = onUnsuspendAll,
                    enabled = !isUnsuspendingAll,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.heightIn(min = 32.dp)
                ) {
                    Text(
                        text = if (isUnsuspendingAll) "..." else stringResource(R.string.unsuspend_all),
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun RamShizukuStatusBanner(
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (hasShizukuPermission) Color(0xFF10B981).copy(alpha = 0.4f) else Color(0xFFEF4444).copy(alpha = 0.4f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(if (hasShizukuPermission) Color(0xFF10B981) else Color(0xFFEF4444))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Shizuku Service",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "UID 2000",
                            color = Color(0xFF94A3B8),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = if (hasShizukuPermission) "Privileged Shell Aktif" else "Nonaktif (Izin Diperlukan)",
                        color = if (hasShizukuPermission) Color(0xFF94A3B8) else Color(0xFFF87171),
                        fontSize = 10.sp
                    )
                }
            }

            Button(
                onClick = onRequestPermission,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (hasShizukuPermission) Color(0xFF1E293B) else Color(0xFF0284C7)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text(
                    text = if (hasShizukuPermission) "Terhubung" else "Beri Izin",
                    fontSize = 10.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun RamGaugesCard(
    usedPercentage: Int?,
    usedRamMb: Long?,
    totalDeviceRamMb: Long?,
    totalCpuUsage: Float?,
    cpuTempC: Float?,
    cpuCoresCount: Int
) {
    val notAvailableText = stringResource(R.string.not_available)
    val ramPctVal = usedPercentage ?: 0
    val cpuPctVal = totalCpuUsage ?: 0f

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = stringResource(R.string.ram_physical), color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text(
                        text = if (usedPercentage != null) "$usedPercentage%" else notAvailableText,
                        color = if (usedPercentage == null) Color(0xFF94A3B8) else if (ramPctVal > 85) Color(0xFFEF4444) else if (ramPctVal > 75) Color(0xFFF59E0B) else Color(0xFF38BDF8),
                        fontSize = if (usedPercentage != null) 12.sp else 9.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (ramPctVal / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (ramPctVal > 85) Color(0xFFEF4444) else if (ramPctVal > 75) Color(0xFFF59E0B) else Color(0xFF0284C7),
                    trackColor = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (usedRamMb != null) String.format(Locale.US, "%.1f GB", usedRamMb / 1024.0) else notAvailableText,
                        color = Color(0xFFCBD5E1),
                        fontSize = 9.sp
                    )
                    Text(
                        text = if (totalDeviceRamMb != null) String.format(Locale.US, "%.0f GB", totalDeviceRamMb / 1024.0) else "",
                        color = Color(0xFF64748B),
                        fontSize = 9.sp
                    )
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = stringResource(R.string.cpu_load), color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text(
                        text = if (totalCpuUsage != null) String.format(Locale.US, "%.0f%%", totalCpuUsage) else notAvailableText,
                        color = if (totalCpuUsage == null) Color(0xFF94A3B8) else if (cpuPctVal > 80f) Color(0xFFEF4444) else if (cpuPctVal > 50f) Color(0xFFF59E0B) else Color(0xFF10B981),
                        fontSize = if (totalCpuUsage != null) 12.sp else 9.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (cpuPctVal / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (cpuPctVal > 80f) Color(0xFFEF4444) else if (cpuPctVal > 50f) Color(0xFFF59E0B) else Color(0xFF10B981),
                    trackColor = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (cpuTempC != null) String.format(Locale.US, "Suhu: %.1f°C", cpuTempC) else "Suhu: Siaga",
                        color = Color(0xFFCBD5E1),
                        fontSize = 9.sp
                    )
                    Text(
                        text = "$cpuCoresCount Cores Aktif",
                        color = Color(0xFF64748B),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun RamSearchAndSortBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    sortBy: String,
    onSortToggle: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 50.dp),
            placeholder = { Text("Cari aplikasi...", color = Color(0xFF64748B), fontSize = 11.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(16.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF141B27),
                unfocusedContainerColor = Color(0xFF141B27),
                focusedBorderColor = Color(0xFF0284C7),
                unfocusedBorderColor = Color(0xFF1E293B),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Button(
            onClick = onSortToggle,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141B27)),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.height(44.dp)
        ) {
            Icon(Icons.Default.SwapVert, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = sortBy, color = Color(0xFFCBD5E1), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RamSafetyInfoCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = stringResource(R.string.safety_card_title),
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .background(Color(0xFF8B5CF6).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(text = "pm suspend", color = Color(0xFFC4B5FD), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.safety_card_desc),
                color = Color(0xFF94A3B8),
                fontSize = 9.sp,
                lineHeight = 13.sp
            )
        }
    }
}

@Composable
private fun RamFilterChips(
    selectedFilter: String,
    onFilterSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        val filters = listOf(
            "ALL" to "Semua",
            "SAFE" to "🟢 Aman",
            "SENSITIVE" to "🟡 Sensitif",
            "DANGEROUS" to "🔴 Bahaya OS",
            "USER" to "User App",
            "SUSPENDED" to "Dibekukan"
        )

        filters.forEach { (key, label) ->
            val isSelected = selectedFilter == key
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) Color(0xFF0284C7) else Color(0xFF141B27))
                    .border(1.dp, if (isSelected) Color(0xFF38BDF8) else Color(0xFF1E293B), RoundedCornerShape(6.dp))
                    .clickable { onFilterSelect(key) }
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            ) {
                Text(
                    text = label,
                    color = if (isSelected) Color.White else Color(0xFF94A3B8),
                    fontSize = 9.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun ProcessItemCard(
    process: AppProcessInfo,
    avatarColor: Color,
    safetyTier: String,
    autoRestarts: Boolean,
    onClick: () -> Unit,
    onProtectToggle: () -> Unit,
    onSuspendToggle: () -> Unit,
    onForceStop: () -> Unit
) {
    val initialLetter = process.appName.firstOrNull()?.uppercase() ?: "?"

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (process.isSuspended) Color(0xFF0F172A).copy(alpha = 0.6f)
            else if (safetyTier == "DANGEROUS") Color(0xFF18131B)
            else Color(0xFF141B27)
        ),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (safetyTier == "DANGEROUS") Color(0xFF7F1D1D).copy(alpha = 0.4f) else Color(0xFF1E293B)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(avatarColor.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initialLetter,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = process.appName,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    when (safetyTier) {
                        "DANGEROUS" -> {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFEF4444).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("🔴 Bahaya OS", color = Color(0xFFFCA5A5), fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        "SENSITIVE" -> {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFF59E0B).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("🟡 Sensitif", color = Color(0xFFFCD34D), fontSize = 7.5.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        else -> {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF10B981).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("🟢 Aman", color = Color(0xFF6EE7B7), fontSize = 7.5.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    if (autoRestarts) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF8B5CF6).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 3.dp, vertical = 1.dp)
                        ) {
                            Text("Auto-Respawn", color = Color(0xFFD8B4FE), fontSize = 7.sp)
                        }
                    }

                    if (process.isProtected) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF0284C7).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 3.dp, vertical = 1.dp)
                        ) {
                            Text("Dilindungi", color = Color(0xFF7DD3FC), fontSize = 7.sp)
                        }
                    }

                    if (process.isSuspended) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFD97706).copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 3.dp, vertical = 1.dp)
                        ) {
                            Text("Beku", color = Color(0xFFFDE68A), fontSize = 7.sp)
                        }
                    }
                }

                Text(
                    text = process.packageName,
                    color = Color(0xFF64748B),
                    fontSize = 9.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Text(
                        text = process.formattedRam,
                        color = Color(0xFF38BDF8),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    val pidText = process.pids.firstOrNull()?.let { "PID $it" } ?: ""
                    if (pidText.isNotEmpty()) {
                        Text(text = pidText, color = Color(0xFF64748B), fontSize = 9.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val isLocked = process.isProtected || safetyTier == "DANGEROUS"

                if (isLocked) {
                    IconButton(
                        onClick = onProtectToggle,
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color(0xFF1E293B).copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = null,
                            tint = Color(0xFFFBBF24),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    IconButton(
                        onClick = onSuspendToggle,
                        modifier = Modifier
                            .size(48.dp)
                            .background(
                                if (process.isSuspended) Color(0xFF0284C7)
                                else if (autoRestarts) Color(0xFF7C3AED).copy(alpha = 0.35f)
                                else Color(0xFF1E293B),
                                RoundedCornerShape(8.dp)
                            )
                    ) {
                        Icon(
                            if (process.isSuspended) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = null,
                            tint = if (process.isSuspended) Color.White else Color(0xFFE2E8F0),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onForceStop,
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color(0xFFDC2626).copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeepCleanConfirmDialog(
    killableProcesses: List<AppProcessInfo>,
    selectedForClean: Set<String>,
    onDismiss: () -> Unit,
    onToggleSelect: (String) -> Unit,
    onCleanConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141B27),
        title = {
            Text(
                stringResource(R.string.deep_clean_confirm_title),
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = stringResource(R.string.deep_clean_warning),
                    color = Color(0xFFFBBF24),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
                    items(killableProcesses) { p ->
                        val isChecked = selectedForClean.contains(p.packageName)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleSelect(p.packageName) }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { onToggleSelect(p.packageName) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = Color(0xFF0284C7),
                                    uncheckedColor = Color(0xFF64748B)
                                )
                            )
                            Text(
                                text = p.appName,
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = p.formattedRam,
                                color = Color(0xFF38BDF8),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onCleanConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(stringResource(R.string.deep_clean_action), fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
        }
    )
}

@Composable
private fun ProcessDetailSheet(
    process: AppProcessInfo,
    tier: String,
    autoRespawn: Boolean,
    isBuiltInProtected: Boolean,
    onDismiss: () -> Unit,
    onSuspendToggle: () -> Unit,
    onProtectToggle: () -> Unit,
    onForceStop: () -> Unit
) {
    var heapInfo by remember(process.packageName) { mutableStateOf<ShizukuCommandRunner.ProcessHeapInfo?>(null) }
    LaunchedEffect(process.packageName) {
        heapInfo = ShizukuCommandRunner.fetchProcessHeapInfo(process.packageName)
    }
    val naText = stringResource(R.string.not_available)
    val nativeStr = heapInfo?.nativeMb?.let { "$it MB" } ?: naText
    val dalvikStr = heapInfo?.dalvikMb?.let { "$it MB" } ?: naText
    val graphicsStr = heapInfo?.graphicsMb?.let { "$it MB" } ?: naText
    val privateDirtyStr = heapInfo?.privateDirtyMb?.let { "$it MB" } ?: naText
    val isLocked = process.isProtected || tier == "DANGEROUS"

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141B27),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(process.appName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        when {
                            isLocked -> Text("🔒 Dilindungi", color = Color(0xFFFBBF24), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            tier == "DANGEROUS" -> Text("🔴 Bahaya OS", color = Color(0xFFFCA5A5), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            tier == "SENSITIVE" -> Text("🟡 Sensitif", color = Color(0xFFFCD34D), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            else -> Text("🟢 Aman", color = Color(0xFF6EE7B7), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(process.packageName, color = Color(0xFF64748B), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            isLocked -> Color(0xFF451A03).copy(alpha = 0.55f)
                            tier == "DANGEROUS" -> Color(0xFF450A0A).copy(alpha = 0.5f)
                            tier == "SENSITIVE" -> Color(0xFF451A03).copy(alpha = 0.5f)
                            else -> Color(0xFF064E3B).copy(alpha = 0.5f)
                        }
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = when {
                                isLocked -> "Status: Terkunci (${process.protectionReason.ifEmpty { "Dilindungi" }})"
                                tier == "DANGEROUS" -> "Status: Dilarang Mematikan (Komponen Inti OS)"
                                tier == "SENSITIVE" -> "Status: Perhatian Sebelum Mematikan"
                                else -> "Status: Sangat Aman Dimatikan"
                            },
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = when {
                                isLocked -> "Tombol Stop dan Suspend dinonaktifkan untuk mencegah gangguan sistem atau layanan penting."
                                tier == "DANGEROUS" -> "Aplikasi ini adalah komponen sistem Android inti. Mematikannya akan menyebabkan UI crash atau bootloop!"
                                autoRespawn -> "Indikasi heuristik: aplikasi ini sering aktif kembali di latar belakang. Jika di-Force Stop dapat hidup lagi; pertimbangkan Bekukan (pm suspend)."
                                else -> "Aman dimatikan saat tidak digunakan untuk menghemat baterai & membebaskan memori RAM."
                            },
                            color = Color(0xFFCBD5E1),
                            fontSize = 9.sp,
                            lineHeight = 13.sp
                        )
                    }
                }

                Text(
                    text = stringResource(R.string.heap_allocation_title),
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(stringResource(R.string.native_heap), color = Color(0xFF64748B), fontSize = 8.sp)
                            Text(nativeStr, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(stringResource(R.string.dalvik_heap), color = Color(0xFF64748B), fontSize = 8.sp)
                            Text(dalvikStr, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(stringResource(R.string.graphics_heap), color = Color(0xFF64748B), fontSize = 8.sp)
                            Text(graphicsStr, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(stringResource(R.string.private_dirty), color = Color(0xFF64748B), fontSize = 8.sp)
                            Text(privateDirtyStr, color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!isLocked) {
                        Button(
                            onClick = onSuspendToggle,
                            colors = ButtonDefaults.buttonColors(containerColor = if (process.isSuspended) Color(0xFF0284C7) else Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (process.isSuspended) stringResource(R.string.resume) else "Bekukan (Suspend)", fontSize = 10.sp)
                        }
                    }

                    if (!isBuiltInProtected) {
                        Button(
                            onClick = onProtectToggle,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (process.isProtected) "Buka Kunci" else "Kunci (Whitelist)", fontSize = 10.sp)
                        }
                    }
                }

                if (!isLocked && !process.isSystemApp) {
                    Button(
                        onClick = onForceStop,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Hentikan Paksa (am force-stop)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Tutup", color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
        }
    )
}
