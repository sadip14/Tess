package com.example.rammanager.data

import android.content.Context
import android.content.SharedPreferences
import com.example.rammanager.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class BenchmarkHistoryRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "device_monitor_benchmark_history"
        private const val KEY_HISTORY = "key_benchmark_runs"
        private const val MAX_RUNS = 50

        @Volatile
        private var instance: BenchmarkHistoryRepository? = null

        fun getInstance(context: Context): BenchmarkHistoryRepository {
            return instance ?: synchronized(this) {
                instance ?: BenchmarkHistoryRepository(context).also { instance = it }
            }
        }
    }

    suspend fun saveResult(record: BenchmarkResultRecord) = withContext(Dispatchers.IO) {
        val list = getAllResultsInternal().toMutableList()
        list.add(0, record)
        if (list.size > MAX_RUNS) {
            list.subList(MAX_RUNS, list.size).clear()
        }
        saveResultsInternal(list)
    }

    suspend fun getAllResults(): List<BenchmarkResultRecord> = withContext(Dispatchers.IO) {
        getAllResultsInternal()
    }

    suspend fun getAverageScore(mode: BenchmarkMode): Int = withContext(Dispatchers.IO) {
        val matches = getAllResultsInternal().filter { it.mode == mode }
        if (matches.isEmpty()) 0 else matches.map { it.totalScore }.average().toInt()
    }

    suspend fun getPreviousResult(mode: BenchmarkMode): BenchmarkResultRecord? = withContext(Dispatchers.IO) {
        getAllResultsInternal().firstOrNull { it.mode == mode }
    }

    fun parseAndValidateImport(text: String): Result<ImportedBenchmarkComparison> {
        return try {
            val map = mutableMapOf<String, String>()
            text.lines().forEach { line ->
                val trimmed = line.trim()
                if (trimmed.contains("=")) {
                    val k = trimmed.substringBefore("=").trim()
                    val v = trimmed.substringAfter("=").trim()
                    map[k] = v
                }
            }

            val version = map["versi_format"] ?: return Result.failure(IllegalArgumentException("Field versi_format tidak ada"))
            if (version != "1") return Result.failure(IllegalArgumentException("Versi format $version tidak didukung"))

            val modeStr = map["mode"] ?: return Result.failure(IllegalArgumentException("Field mode tidak ada"))
            val mode = try { BenchmarkMode.valueOf(modeStr) } catch (_: Exception) {
                return Result.failure(IllegalArgumentException("Mode $modeStr tidak dikenal"))
            }

            val single = map["skor_single"]?.toIntOrNull() ?: return Result.failure(IllegalArgumentException("skor_single tidak valid"))
            val multi = map["skor_multi"]?.toIntOrNull() ?: return Result.failure(IllegalArgumentException("skor_multi tidak valid"))
            val ram = map["ram"]?.toIntOrNull() ?: return Result.failure(IllegalArgumentException("ram tidak valid"))
            val storage = map["storage"]?.toIntOrNull() ?: return Result.failure(IllegalArgumentException("storage tidak valid"))
            val temp = map["suhu"]?.toFloatOrNull() ?: return Result.failure(IllegalArgumentException("suhu tidak valid"))
            val model = map["model"]?.ifBlank { null } ?: return Result.failure(IllegalArgumentException("model tidak valid"))

            val total = single + multi + ram + storage

            Result.success(
                ImportedBenchmarkComparison(
                    deviceModel = model,
                    mode = mode,
                    totalScore = total,
                    singleScore = single,
                    multiScore = multi,
                    ramScore = ram,
                    storageScore = storage,
                    tempC = temp
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun getAllResultsInternal(): List<BenchmarkResultRecord> {
        val jsonStr = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        val list = mutableListOf<BenchmarkResultRecord>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val record = BenchmarkResultRecord(
                    id = obj.optString("id", "run-$i"),
                    timestamp = obj.optLong("timestamp", 0L),
                    mode = BenchmarkMode.valueOf(obj.optString("mode", "FAST")),
                    deviceModel = obj.optString("deviceModel", "Unknown"),
                    totalScore = obj.optInt("totalScore", 0),
                    singleCoreScore = obj.optInt("singleCoreScore", 0),
                    multiCoreScore = obj.optInt("multiCoreScore", 0),
                    ramScore = obj.optInt("ramScore", 0),
                    storageScore = obj.optInt("storageScore", 0),
                    singleCoreOpsSec = parseVariation(obj.optJSONObject("singleOps")),
                    multiCoreOpsSec = parseVariation(obj.optJSONObject("multiOps")),
                    ramThroughputMbSec = parseVariation(obj.optJSONObject("ramThroughput")),
                    storageThroughputMbSec = parseVariation(obj.optJSONObject("storageThroughput")),
                    tempBeforeC = if (obj.has("tempBeforeC")) obj.optDouble("tempBeforeC").toFloat() else null,
                    tempAfterC = if (obj.has("tempAfterC")) obj.optDouble("tempAfterC").toFloat() else null,
                    batteryBeforePct = obj.optInt("batteryBeforePct", 0),
                    batteryAfterPct = obj.optInt("batteryAfterPct", 0),
                    throttlingDropPct = if (obj.has("throttlingDropPct")) obj.optDouble("throttlingDropPct").toFloat() else null,
                    stressCurve = parseStressCurve(obj.optJSONArray("stressCurve"))
                )
                list.add(record)
            }
        } catch (_: Exception) {}
        return list
    }

    private fun parseVariation(obj: JSONObject?): MetricVariation {
        if (obj == null) return MetricVariation(0.0, 0.0, 0.0, 0.0)
        return MetricVariation(
            median = obj.optDouble("median", 0.0),
            min = obj.optDouble("min", 0.0),
            max = obj.optDouble("max", 0.0),
            avg = obj.optDouble("avg", 0.0)
        )
    }

    private fun parseStressCurve(arr: JSONArray?): List<StressDataPoint> {
        if (arr == null) return emptyList()
        val list = mutableListOf<StressDataPoint>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                StressDataPoint(
                    second = obj.optInt("second", 0),
                    score = obj.optInt("score", 0),
                    tempC = if (obj.has("tempC")) obj.optDouble("tempC").toFloat() else null
                )
            )
        }
        return list
    }

    private fun saveResultsInternal(list: List<BenchmarkResultRecord>) {
        try {
            val arr = JSONArray()
            for (r in list) {
                val obj = JSONObject().apply {
                    put("id", r.id)
                    put("timestamp", r.timestamp)
                    put("mode", r.mode.name)
                    put("deviceModel", r.deviceModel)
                    put("totalScore", r.totalScore)
                    put("singleCoreScore", r.singleCoreScore)
                    put("multiCoreScore", r.multiCoreScore)
                    put("ramScore", r.ramScore)
                    put("storageScore", r.storageScore)

                    put("singleOps", JSONObject().apply {
                        put("median", r.singleCoreOpsSec.median)
                        put("min", r.singleCoreOpsSec.min)
                        put("max", r.singleCoreOpsSec.max)
                        put("avg", r.singleCoreOpsSec.avg)
                    })

                    put("multiOps", JSONObject().apply {
                        put("median", r.multiCoreOpsSec.median)
                        put("min", r.multiCoreOpsSec.min)
                        put("max", r.multiCoreOpsSec.max)
                        put("avg", r.multiCoreOpsSec.avg)
                    })

                    put("ramThroughput", JSONObject().apply {
                        put("median", r.ramThroughputMbSec.median)
                        put("min", r.ramThroughputMbSec.min)
                        put("max", r.ramThroughputMbSec.max)
                        put("avg", r.ramThroughputMbSec.avg)
                    })

                    put("storageThroughput", JSONObject().apply {
                        put("median", r.storageThroughputMbSec.median)
                        put("min", r.storageThroughputMbSec.min)
                        put("max", r.storageThroughputMbSec.max)
                        put("avg", r.storageThroughputMbSec.avg)
                    })

                    r.tempBeforeC?.let { put("tempBeforeC", it.toDouble()) }
                    r.tempAfterC?.let { put("tempAfterC", it.toDouble()) }
                    put("batteryBeforePct", r.batteryBeforePct)
                    put("batteryAfterPct", r.batteryAfterPct)
                    r.throttlingDropPct?.let { put("throttlingDropPct", it.toDouble()) }

                    val curveArr = JSONArray()
                    for (p in r.stressCurve) {
                        curveArr.put(JSONObject().apply {
                            put("second", p.second)
                            put("score", p.score)
                            p.tempC?.let { put("tempC", it.toDouble()) }
                        })
                    }
                    put("stressCurve", curveArr)
                }
                arr.put(obj)
            }
            prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
        } catch (_: Exception) {}
    }
}
