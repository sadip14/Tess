package com.example.rammanager.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.rammanager.service.BatteryMonitorForegroundService
import com.example.rammanager.service.NetworkSpeedService

/**
 * Receiver on phone boot.
 * Only starts services if user explicitly enabled them previously.
 */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            if (BatteryMonitorForegroundService.isServiceEnabled(context)) {
                BatteryMonitorForegroundService.startService(context)
            }
            if (NetworkSpeedService.isServiceEnabled(context)) {
                NetworkSpeedService.startService(context)
            }
        }
    }
}
