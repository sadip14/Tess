package com.example.rammanager

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.util.Log
import rikka.shizuku.ShizukuProvider
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeviceMonitorApp : Application() {

    companion object {
        private const val CRASH_FILE_NAME = "crash_log.txt"
        private const val CRASH_PREFS_NAME = "device_monitor_crash"
        private const val KEY_LAST_CRASH = "last_crash_log"
        private const val KEY_HAS_UNSEEN_CRASH = "has_unseen_crash"

        fun getCrashLogFile(context: Context): File {
            return File(context.filesDir, CRASH_FILE_NAME)
        }

        fun saveCrashLog(context: Context, throwable: Throwable): String {
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val header = "Time: $timestamp\nDevice: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})\n\n"
            val crashReport = header + sw.toString()

            try {
                getCrashLogFile(context).writeText(crashReport)
            } catch (_: Throwable) {}

            try {
                context.getSharedPreferences(CRASH_PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_LAST_CRASH, crashReport)
                    .putBoolean(KEY_HAS_UNSEEN_CRASH, true)
                    .commit()
            } catch (_: Throwable) {}

            return crashReport
        }

        fun readCrashLog(context: Context): String? {
            try {
                val file = getCrashLogFile(context)
                if (file.exists() && file.canRead()) {
                    val content = file.readText()
                    if (content.isNotBlank()) return content
                }
            } catch (_: Throwable) {}

            return try {
                context.getSharedPreferences(CRASH_PREFS_NAME, Context.MODE_PRIVATE)
                    .getString(KEY_LAST_CRASH, null)
            } catch (_: Throwable) {
                null
            }
        }

        fun hasUnseenCrash(context: Context): Boolean {
            return try {
                context.getSharedPreferences(CRASH_PREFS_NAME, Context.MODE_PRIVATE)
                    .getBoolean(KEY_HAS_UNSEEN_CRASH, false)
            } catch (_: Throwable) {
                false
            }
        }

        fun markCrashSeen(context: Context) {
            try {
                context.getSharedPreferences(CRASH_PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_HAS_UNSEEN_CRASH, false)
                    .apply()
            } catch (_: Throwable) {}
        }

        fun clearCrashLog(context: Context) {
            try {
                val file = getCrashLogFile(context)
                if (file.exists()) {
                    file.delete()
                }
            } catch (_: Throwable) {}

            try {
                context.getSharedPreferences(CRASH_PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .remove(KEY_LAST_CRASH)
                    .putBoolean(KEY_HAS_UNSEEN_CRASH, false)
                    .apply()
            } catch (_: Throwable) {}
        }
    }

    override fun onCreate() {
        super.onCreate()

        try {
            ShizukuProvider.disableAutomaticSuiInitialization()
        } catch (_: Throwable) {}

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                Log.e("DeviceMonitor", "Fatal Uncaught Exception", throwable)
                val crashReport = saveCrashLog(this, throwable)

                val intent = Intent(this, CrashReportActivity::class.java).apply {
                    putExtra("crash_log", crashReport)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                startActivity(intent)

                Process.killProcess(Process.myPid())
                System.exit(10)
            } catch (_: Throwable) {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }
}
