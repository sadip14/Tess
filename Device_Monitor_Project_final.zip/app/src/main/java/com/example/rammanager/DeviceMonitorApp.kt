package com.example.rammanager

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Process
import android.util.Log
import java.io.PrintWriter
import java.io.StringWriter

class DeviceMonitorApp : Application() {

    override fun onCreate() {
        super.onCreate()

        try {
            rikka.shizuku.ShizukuProvider.disableAutomaticSuiInitialization()
        } catch (_: Throwable) {}

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                Log.e("DeviceMonitor", "Fatal Uncaught Exception", throwable)
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val crashReport = sw.toString()

                val prefs = getSharedPreferences("device_monitor_crash", Context.MODE_PRIVATE)
                prefs.edit().putString("last_crash_log", crashReport).commit()

                val intent = Intent(this, CrashReportActivity::class.java).apply {
                    putExtra("crash_log", crashReport)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                startActivity(intent)

                Process.killProcess(Process.myPid())
                System.exit(10)
            } catch (t: Throwable) {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }
}
