# Device Monitor - Universal Android System & Battery Optimizer (Shizuku + Jetpack Compose)

A lightweight, production-ready Android application that works across all modern Android devices (Samsung, Xiaomi, Pixel, Oppo, Vivo, Motorola, Realme, Asus, Sony, etc.).

### Key Features
1. **RAM & Process Manager**: Queries real device RAM and PSS memory allocations per background process via Shizuku shell `dumpsys meminfo`.
2. **Protected App Safeguards**: Protects system apps, default launcher, keyboard, dialer, SMS, Shizuku, and user-selected favorites from being terminated.
3. **Deep Clean with Confirmation**: Confirmation dialog with selective checkboxes to avoid accidental notification drop on messaging apps.
4. **AccuBattery-style Electric Monitor**: Real-time electric current (mA), power (W), voltage (mV), and kernel thermals.
5. **Real Battery Health %**: Evaluates capacity from cumulative charge counter differences (`BATTERY_PROPERTY_CHARGE_COUNTER`). Shows "Belum cukup data" until valid charging sessions exist.
6. **Persistent Background Service**: Ultra-lightweight Foreground Service (`specialUse` subtype `battery_monitoring`) with 80% charge level protection alarm.
7. **Hardware Benchmark**: Time-based (ops/sec) single-core and multi-core (utilizing all available CPU threads), RAM throughput, storage I/O, thermal stress test, share `key=value` results, and import friend comparison.
8. **Device Hardware Inspector**: Inspects SoC, CPU cores, display resolution, refresh rate, and GPU renderer without hardcoded device assumptions.
9. **Interactive Shizuku Shell & Logs**: Run any privileged shell command directly from the app.

### How to Build APK
1. Open this folder in Android Studio (Ladybug, Koala, Iguana, or newer).
2. Connect an Android device (Android 8.0 - 15+) or start an emulator.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. You can also push to GitHub; `.github/workflows/build.yml` will compile `app-debug.apk` automatically!
